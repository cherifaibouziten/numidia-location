# NUMIDIA Cars & Immo — v2.0

Application complète de gestion de location de véhicules (React Native / Expo + Node.js / Express + MongoDB), entièrement reconstruite avec un design **mode clair**, des **icônes SVG**, des **rôles (Admin / Utilisateur)**, la **vérification email**, un **module de contrat** générant le contrat officiel en `.docx` et `.pdf`, et de nombreuses fonctionnalités pro.

---

## Sommaire

- [Nouveautés v2](#nouveautés-v2)
- [Architecture](#architecture)
- [Prérequis](#prérequis)
- [Installation — Backend](#installation--backend)
- [Installation — Mobile](#installation--mobile)
- [Identifiants par défaut](#identifiants-par-défaut)
- [Module de contrat](#module-de-contrat)
- [Rôles & permissions](#rôles--permissions)
- [Build APK](#build-apk-android)
- [Dépannage](#dépannage)

---

## Nouveautés v2

**Design**
- Mode clair uniquement (fonds blancs/gris clair, ombres douces, typographie soignée)
- Toutes les emojis remplacées par des **icônes SVG** style Lucide (40+ icônes dans `components/Icons.js`)
- Palette pro : accent bleu/indigo, gris neutres, cartes blanches
- Barre d'onglets SVG tactile, transitions fluides

**Réservations**
- Upload de **photo de véhicule** (galerie + caméra, aperçu avant confirmation)
- Validation du **téléphone** au format algérien (`+213XXXXXXXXX` ou `0XXXXXXXXX`)
- **Calendrier** pour les dates au format `JJ/MM/AAAA` (aucune saisie libre)

**Authentification & rôles**
- **Vérification email** à la création de compte (activation avant connexion)
- Deux rôles : **ADMIN** et **USER**
- USER : parcourir / réserver / voir ses réservations ; **pas d'accès au dashboard** ; peut **demander le rôle admin**
- ADMIN : privilèges complets ; **dashboard sur un écran séparé** ; approuve/rejette les demandes admin

**Module de contrat**
- Charge le modèle officiel (français) et rend tous les **champs variables éditables** via une UI à onglets
- Export **.docx** ET **PDF** prêt à imprimer, en conservant la mise en forme et les conditions générales

**Fonctionnalités pro**
- Skeleton loaders, pull-to-refresh, toasts (succès/erreur), illustrations d'état vide
- Modales de confirmation avant suppression, avatars à initiales
- Recherche + filtres sur les véhicules, badges de statut, modales en overlay sombre
- Retour haptique sur les actions clés

---

## Architecture

```
numidia_v2/
├── backend/                  # API Node.js / Express / MongoDB
│   ├── src/
│   │   ├── index.js          # Point d'entrée (Express + Socket.IO)
│   │   ├── models/           # Schémas Mongoose (Admin, Vehicule, Client, Reservation, …)
│   │   ├── routes/           # Routes API (auth, vehicules, reservations, contract, …)
│   │   ├── middleware/       # auth.js (JWT, requireAdmin, requireVerified)
│   │   └── utils/            # email.js, upload.js, contractBuilder.js
│   ├── uploads/              # Photos véhicules + contrats générés
│   ├── seed.js               # Données initiales (admin + véhicules)
│   └── package.json
│
└── mobile/                   # Application Expo / React Native
    ├── App.js                # Providers (Auth, Socket, Toast) + navigation
    ├── src/
    │   ├── screens/          # Écrans par domaine (auth, dashboard, vehicles, …)
    │   ├── components/       # Icons.js (SVG), UI.js, DatePicker.js
    │   ├── context/          # AuthContext, SocketContext, ToastContext
    │   ├── navigation/       # AppNavigator (routage selon le rôle)
    │   ├── services/         # api.js, theme.js
    │   └── utils/            # haptics.js
    ├── app.json
    └── package.json
```

---

## Prérequis

- **Node.js** ≥ 18
- **MongoDB** (Atlas ou local) — l'URI est dans `backend/.env`
- **Expo CLI** : `npm install -g expo-cli` (ou utiliser `npx expo`)
- **LibreOffice** sur le serveur backend pour l'export PDF des contrats (commande `soffice`)
  - Ubuntu/Debian : `sudo apt install libreoffice`
  - macOS : `brew install --cask libreoffice`
  - Sans LibreOffice, l'export `.docx` fonctionne ; le PDF retombe automatiquement sur le `.docx`.

---

## Installation — Backend

```bash
cd backend
npm install

# Configurer l'environnement (déjà pré-rempli dans .env)
#   MONGO_URI   -> votre base MongoDB
#   JWT_SECRET  -> clé secrète
#   EMAIL_*     -> SMTP pour les emails de vérification (optionnel en dev)

# Créer l'admin par défaut + véhicules d'exemple
npm run seed

# Démarrer
npm run dev      # avec rechargement (nodemon)
# ou
npm start        # production
```

Le serveur démarre sur `http://localhost:5000`.

> **Emails en développement** : si `EMAIL_USER` n'est pas configuré, le token de vérification est **affiché dans la console** du serveur (au lieu d'être envoyé par email). Pratique pour tester sans SMTP.

---

## Installation — Mobile

```bash
cd mobile
npm install
```

**Important — configurer l'adresse du serveur :**

Ouvrez `mobile/src/services/api.js` et remplacez l'IP par celle de votre machine sur le réseau local (pas `localhost`, car le téléphone doit y accéder) :

```js
export const BASE_URL = 'http://192.168.1.100:5000'; // ← votre IP locale
```

> Trouvez votre IP : `ipconfig` (Windows) ou `ifconfig` / `ip addr` (macOS/Linux). Le téléphone et l'ordinateur doivent être sur le **même réseau Wi-Fi**.

Puis lancez :

```bash
npm start
```

Scannez le QR code avec l'app **Expo Go** (Android/iOS), ou pressez `a` pour un émulateur Android, `i` pour iOS.

---

## Identifiants par défaut

Après `npm run seed` :

| Champ | Valeur |
|-------|--------|
| Email | `admin@numidia.dz` |
| Mot de passe | `numidia2025` |
| Rôle | **Administrateur principal** (vérifié, actif) |

L'administrateur principal est créé par le seed et ne passe jamais par l'inscription.

### Les 3 rôles (Phase 1)

- **Administrateur principal** — créé par seed ; tous les droits ; peut promouvoir un employé en admin et gérer les permissions.
- **Employé** — s'inscrit, vérifie son email, **puis doit être activé par un admin** avant de pouvoir se connecter.
- **Client** — s'inscrit, vérifie son email, accès immédiat ensuite.

**Vérification email obligatoire pour toute inscription.** En dev (sans SMTP), le lien/token s'affiche dans la console du backend.

**Tester le flux employé :**
1. Inscrivez-vous en choisissant « Employé ».
2. Récupérez le token dans la console → `GET /api/auth/verify-email/<token>` (ou via le lien email).
3. Connectez-vous en admin (`admin@numidia.dz`) → *Paramètres → Gérer les utilisateurs → À activer* → **Activer**.
4. L'employé peut maintenant se connecter.

Endpoints clés ajoutés : `/auth/forgot-password`, `/auth/reset-password/:token`, `/auth/sessions` (historique connexions), `/users/*` (gestion employés, activation, promotion, permissions), `/audit` (journal d'activité).

---

## Module de contrat

Le modèle de contrat fourni est en **français** (contrat de location bilingue, tribunal de Bejaïa).

**Champs variables identifiés** (tous éditables dans l'écran Contrat, regroupés en 4 onglets) :

- **Chauffeur 1 / Chauffeur 2** : nom et prénom(s), adresse, séjour, n° téléphone, date de naissance, n° permis, date d'expiration, APC
- **Voiture** : marque/modèle, immatriculation, n° châssis, couleur, énergie, assurance, contrôle technique, vidange
- **Termes** : prix/jour, nombre de jours, total, versement, reste, km départ/retour, dates départ/retour, remarque
- **Accessoires** : 10 cases à cocher (lavage, roue de secours, cric, triangle, poste, salon, longe-leveur, klaxon, carburant, barres)

**Génération** : le backend (`utils/contractBuilder.js`) reconstruit le contrat avec la librairie `docx`, en conservant la structure (tableaux d'information, checklist, signatures) et **l'intégralité des conditions générales** en page 2. L'export PDF passe par LibreOffice.

Depuis une réservation → bouton **« Générer le contrat »** → les champs se pré-remplissent automatiquement → **Exporter** en `.docx` ou `.pdf`.

---

## Rôles & permissions

| Action | USER | ADMIN |
|--------|:----:|:-----:|
| Parcourir les véhicules | ✅ | ✅ |
| Voir le dashboard | ❌ | ✅ |
| Gérer véhicules / réservations / clients | ❌ | ✅ |
| Gérer les utilisateurs | ❌ | ✅ |
| Approuver les demandes admin | ❌ | ✅ |
| Demander le rôle admin | ✅ | — |

**Promotion** : un USER fait une demande depuis *Paramètres → Devenir administrateur*. La demande passe en statut `pending`. Un ADMIN l'approuve/rejette depuis *Paramètres → Gérer les utilisateurs → onglet Demandes*.

---

## Build APK (Android)

Avec **EAS Build** (compte Expo requis) :

```bash
cd mobile
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

Le profil `preview` (dans `eas.json`) produit un **APK** installable directement. Téléchargez-le depuis le lien fourni à la fin du build.

> Pensez à mettre `BASE_URL` sur une adresse accessible publiquement (serveur déployé) avant un build de production, sinon l'app ne joindra pas le backend hors du réseau local.

---

## Dépannage

**L'app n'atteint pas le serveur**
- Vérifiez `BASE_URL` dans `api.js` (IP locale, pas `localhost`)
- Téléphone et PC sur le même Wi-Fi
- Pare-feu autorisant le port 5000

**« Veuillez vérifier votre email »**
- En dev, récupérez le token dans la console backend, ou configurez le SMTP dans `.env`
- Endpoint de vérification : `GET /api/auth/verify-email/:token`

**Export PDF échoue**
- Installez LibreOffice (`soffice` doit être dans le PATH). À défaut, le `.docx` est renvoyé.

**Erreurs de dépendances à l'install mobile**
- Le fichier `.npmrc` active `legacy-peer-deps`. Sinon : `npm install --legacy-peer-deps`

---

## Stack technique

**Backend** : Express · Mongoose · JWT · bcryptjs · Multer (upload) · Nodemailer · Socket.IO · docx
**Mobile** : Expo 51 · React Native 0.74 · React Navigation 6 · react-native-svg · expo-image-picker · expo-haptics · AsyncStorage · socket.io-client

---

© 2026 NUMIDIA Cars & Immo — v2.0
