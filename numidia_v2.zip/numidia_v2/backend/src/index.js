require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Attach socket.io to every request
app.use((req, _, next) => { req.io = io; next(); });

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/vehicules', require('./routes/vehicules'));
app.use('/api/clients', require('./routes/clients'));
app.use('/api/reservations', require('./routes/reservations'));
app.use('/api/finance', require('./routes/finance'));
app.use('/api/maintenance', require('./routes/maintenance'));
app.use('/api/stats', require('./routes/stats'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/users', require('./routes/users'));
app.use('/api/admin', require('./routes/admin')); // alias de compatibilité
app.use('/api/audit', require('./routes/audit'));
app.use('/api/contract', require('./routes/contract'));

// Socket.IO
io.on('connection', socket => {
  console.log('Client connected:', socket.id);
  socket.on('join_room', room => socket.join(room));
  socket.on('disconnect', () => console.log('Disconnected:', socket.id));
});

app.get('/', (_, res) => res.json({ app: 'NUMIDIA CARS & IMMO API v2', status: 'OK' }));

mongoose.connect(process.env.MONGO_URI)
  .then(() => server.listen(process.env.PORT || 5000, () =>
    console.log(`NUMIDIA API v2 running on port ${process.env.PORT || 5000}`)
  ))
  .catch(err => console.error('MongoDB Error:', err));
