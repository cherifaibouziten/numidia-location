/**
 * audit.js — helpers pour journaliser les actions et les connexions.
 * Tolérant aux erreurs : une panne de log ne doit jamais bloquer une requête.
 */
const { Activity, LoginHistory } = require('../models/Audit');

function getIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim()
    || req.socket?.remoteAddress || '';
}

async function logActivity(req, action, entite = '', entiteId = null, details = null) {
  try {
    await Activity.create({
      acteur: req.user?._id,
      acteurNom: req.user ? `${req.user.nom} ${req.user.prenom || ''}`.trim() : 'Système',
      action, entite, entiteId, details, ip: getIp(req),
    });
  } catch (_) { /* noop */ }
}

async function logLogin(req, email, user, succes) {
  try {
    await LoginHistory.create({
      user: user?._id,
      email,
      succes,
      ip: getIp(req),
      userAgent: req.headers['user-agent'] || '',
    });
  } catch (_) { /* noop */ }
}

module.exports = { logActivity, logLogin, getIp };
