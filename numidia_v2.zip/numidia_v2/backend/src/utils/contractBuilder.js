/**
 * contractBuilder.js
 * Generates the Numidia rental contract as a .docx using the `docx` library.
 * Reproduces the official template's two-column info tables, accessory checklist,
 * and the full "Conditions Générales" legal text on page 2 — exactly as in the
 * provided template — while injecting the variable field values.
 */
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, BorderStyle, WidthType, ShadingType, HeadingLevel
} = require('docx');

const BORDER = { style: BorderStyle.SINGLE, size: 4, color: '999999' };
const BORDERS = { top: BORDER, bottom: BORDER, left: BORDER, right: BORDER };
const NOBORDER = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const NOBORDERS = { top: NOBORDER, bottom: NOBORDER, left: NOBORDER, right: NOBORDER };

// A labelled cell + value cell pair
function labelValueRow(label, value, opts = {}) {
  return new TableRow({
    children: [
      new TableCell({
        borders: BORDERS,
        width: { size: 2400, type: WidthType.DXA },
        margins: { top: 40, bottom: 40, left: 100, right: 80 },
        shading: { fill: 'F1F5F9', type: ShadingType.CLEAR },
        children: [new Paragraph({ children: [new TextRun({ text: label, size: 18, bold: true })] })],
      }),
      new TableCell({
        borders: BORDERS,
        width: { size: 2280, type: WidthType.DXA },
        margins: { top: 40, bottom: 40, left: 100, right: 80 },
        children: [new Paragraph({ children: [new TextRun({ text: value || '', size: 18 })] })],
      }),
    ],
  });
}

// Section title bar
function sectionTitle(text) {
  return new Paragraph({
    spacing: { before: 160, after: 80 },
    shading: { fill: '2563EB', type: ShadingType.CLEAR },
    children: [new TextRun({ text: `  ${text}`, bold: true, color: 'FFFFFF', size: 20 })],
  });
}

// Heading for the legal conditions
function legalHeading(text) {
  return new Paragraph({
    spacing: { before: 140, after: 40 },
    children: [new TextRun({ text, bold: true, size: 19, color: '1D4ED8' })],
  });
}

function legalPara(text) {
  return new Paragraph({
    spacing: { after: 80 },
    alignment: AlignmentType.JUSTIFIED,
    children: [new TextRun({ text, size: 16 })],
  });
}

function bullet(text) {
  return new Paragraph({
    numbering: { reference: 'conds', level: 0 },
    spacing: { after: 40 },
    children: [new TextRun({ text, size: 16 })],
  });
}

async function buildContractDocx(f, outPath) {
  const accessories = [
    ['Lavage / entretien', f.lavageEntretient], ['Roue de secours', f.roueSecours],
    ['Cric', f.crick], ['Triangle de panne', f.trianglePanne],
    ['Poste', f.poste], ['Salon', f.salon],
    ['Longe-leveur', f.longeLeveur], ['Klaxon', f.klaxon],
    ['Carburant', f.carburant], ['Barres', f.barres],
  ];

  // Accessory checklist as a 2-col grid of checkboxes
  const accessoryRows = [];
  for (let i = 0; i < accessories.length; i += 2) {
    const left = accessories[i];
    const right = accessories[i + 1];
    accessoryRows.push(new TableRow({
      children: [
        new TableCell({
          borders: BORDERS, width: { size: 2340, type: WidthType.DXA },
          margins: { top: 30, bottom: 30, left: 80, right: 60 },
          children: [new Paragraph({ children: [new TextRun({ text: `${left[1] ? '☑' : '☐'} ${left[0]}`, size: 16 })] })],
        }),
        new TableCell({
          borders: BORDERS, width: { size: 2340, type: WidthType.DXA },
          margins: { top: 30, bottom: 30, left: 80, right: 60 },
          children: right
            ? [new Paragraph({ children: [new TextRun({ text: `${right[1] ? '☑' : '☐'} ${right[0]}`, size: 16 })] })]
            : [new Paragraph({ children: [new TextRun({ text: '', size: 16 })] })],
        }),
      ],
    }));
  }

  const doc = new Document({
    numbering: {
      config: [{
        reference: 'conds',
        levels: [{ level: 0, format: 'bullet', text: '–', alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 460, hanging: 240 } } } }],
      }],
    },
    styles: {
      default: { document: { run: { font: 'Arial', size: 18 } } },
    },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 }, // A4
          margin: { top: 720, right: 720, bottom: 720, left: 720 },
        },
      },
      children: [
        // ─── Title ───
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 60 },
          children: [new TextRun({ text: 'NUMIDIA CARS & IMMO', bold: true, size: 32, color: '2563EB' })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER, spacing: { after: 120 },
          children: [new TextRun({ text: 'Location de véhicules — Bejaïa, Algérie', size: 16, color: '64748B' })],
        }),
        new Paragraph({
          spacing: { after: 120 },
          children: [new TextRun({ text: `Contrat de location N° : ${f.contratNumero || ''}`, bold: true, size: 22 })],
        }),

        // ─── Driver 1 + Car (two info tables side by side via single table) ───
        sectionTitle('Informations sur le premier chauffeur'),
        new Table({
          width: { size: 4680, type: WidthType.DXA }, columnWidths: [2400, 2280],
          rows: [
            labelValueRow('Nom et prénom(s)', f.d1Nom),
            labelValueRow('Adresse', f.d1Adresse),
            labelValueRow('Séjour', f.d1Sejour),
            labelValueRow('N° de téléphone', f.d1Phone),
            labelValueRow('Né(e) le', f.d1Naissance),
            labelValueRow('N° permis', f.d1Permis),
            labelValueRow('Expire le', f.d1PermisExpire),
            labelValueRow('Délivré par APC', f.d1APC),
          ],
        }),

        sectionTitle('Informations sur la voiture'),
        new Table({
          width: { size: 4680, type: WidthType.DXA }, columnWidths: [2400, 2280],
          rows: [
            labelValueRow('Marque / Modèle', f.carMarque),
            labelValueRow('Immatriculation', f.carImmat),
            labelValueRow('N° châssis', f.carChassis),
            labelValueRow('Couleur', f.carCouleur),
            labelValueRow('Énergie', f.carEnergie),
            labelValueRow('Assurance', f.carAssurance),
            labelValueRow('Contrôle tech.', f.carControleTech),
            labelValueRow('Vidange', f.carVidange),
          ],
        }),

        // ─── Pricing line ───
        new Paragraph({
          spacing: { before: 140, after: 80 },
          shading: { fill: 'EFF6FF', type: ShadingType.CLEAR },
          children: [new TextRun({
            text: `  Prix/jour : ${f.prixJour || 0} DA    Nombre jours : ${f.nombreJours || 0}    Total : ${f.total || 0} DA    Versement : ${f.versement || 0} DA    Reste : ${f.reste || 0} DA`,
            size: 18, bold: true,
          })],
        }),
        new Paragraph({
          spacing: { after: 120 },
          children: [new TextRun({ text: `Km Départ : ${f.kmDepart || 0}     Km Retour : ${f.kmRetour || 0}`, size: 18 })],
        }),

        // ─── Driver 2 ───
        sectionTitle('Informations sur le deuxième chauffeur'),
        new Table({
          width: { size: 4680, type: WidthType.DXA }, columnWidths: [2400, 2280],
          rows: [
            labelValueRow('Nom et prénom(s)', f.d2Nom),
            labelValueRow('Adresse', f.d2Adresse),
            labelValueRow('Séjour', f.d2Sejour),
            labelValueRow('N° de téléphone', f.d2Phone),
            labelValueRow('Né(e) le', f.d2Naissance),
            labelValueRow('N° permis', f.d2Permis),
            labelValueRow('Expiré le', f.d2PermisExpire),
            labelValueRow('Délivré par APC', f.d2APC),
          ],
        }),

        // ─── Dates + Remarque ───
        new Table({
          width: { size: 9360, type: WidthType.DXA }, columnWidths: [4680, 4680],
          rows: [
            new TableRow({
              children: [
                new TableCell({
                  borders: BORDERS, width: { size: 4680, type: WidthType.DXA },
                  margins: { top: 40, bottom: 40, left: 100, right: 80 },
                  children: [
                    new Paragraph({ children: [new TextRun({ text: `Date départ : ${f.dateDepart || ''}`, size: 18 })] }),
                    new Paragraph({ children: [new TextRun({ text: `Date retour : ${f.dateRetour || ''}`, size: 18 })] }),
                  ],
                }),
                new TableCell({
                  borders: BORDERS, width: { size: 4680, type: WidthType.DXA },
                  margins: { top: 40, bottom: 40, left: 100, right: 80 },
                  children: [new Paragraph({ children: [new TextRun({ text: `Remarque : ${f.remarques || '* 300 Km par jour * 25 Da pour chaque Km'}`, size: 16 })] })],
                }),
              ],
            }),
          ],
        }),

        // ─── Accessories checklist ───
        sectionTitle('État des accessoires'),
        new Table({
          width: { size: 4680, type: WidthType.DXA }, columnWidths: [2340, 2340],
          rows: accessoryRows,
        }),

        // ─── Signature acceptance ───
        new Paragraph({
          spacing: { before: 160, after: 120 },
          children: [new TextRun({ text: "J'ai lu et j'accepte sans réserve les conditions stipulées ci-contre au verso du présent contrat de location.", size: 16, italics: true })],
        }),
        new Table({
          width: { size: 9360, type: WidthType.DXA }, columnWidths: [4680, 4680],
          rows: [new TableRow({
            children: [
              new TableCell({ borders: NOBORDERS, width: { size: 4680, type: WidthType.DXA },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 240 }, children: [new TextRun({ text: "Cachet et signature de l'établissement", size: 16 })] })] }),
              new TableCell({ borders: NOBORDERS, width: { size: 4680, type: WidthType.DXA },
                children: [new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 240 }, children: [new TextRun({ text: 'Signature du client', size: 16 })] })] }),
            ],
          })],
        }),

        // ─── PAGE 2: Conditions Générales ───
        new Paragraph({ pageBreakBefore: true, alignment: AlignmentType.CENTER, spacing: { after: 120 },
          children: [new TextRun({ text: 'CONDITIONS GÉNÉRALES', bold: true, size: 26, color: '2563EB' })] }),

        legalHeading('PRINCIPALE :'),
        legalPara("La prise en charge de nos véhicules par le locataire implique l'acceptation sans réserve de nos conditions générales."),

        legalHeading('CONDITIONS DE LOCATION :'),
        bullet("Âge requis : pour tous les véhicules, l'âge minimum du locataire est 25 ans."),
        bullet("Validité du permis de conduire : le locataire doit être en possession d'un permis de conduire en cours de validité délivré depuis au moins 2 ans."),
        bullet("Un passeport à votre nom en cours de validité."),
        bullet("Dépôt de garantie : une caution sera déposée lors de la signature du contrat de location, elle sera remboursée à la fin du contrat."),
        bullet("Paiement : toute location est payable à l'avance."),
        legalPara("En cas d'accident, le client paiera tous les frais d'acheminement du véhicule vers notre garage et 100% de son immobilisation et 100% des frais du tôlier, dans les deux cas (fautif ou non fautif). Le client est responsable en cas de vol et incendie."),

        legalHeading('ÉTAT DU VÉHICULE :'),
        legalPara("Le véhicule est livré au locataire en parfait état de marche, il fait l'objet au départ d'un descriptif signé par les deux parties, il devra être restitué dans le même état, à défaut, le locataire devra s'acquitter des frais de remise en état du véhicule."),

        legalHeading('UTILISATION DU VÉHICULE :'),
        legalPara('Le locataire s\'engage à :'),
        bullet("Utiliser le véhicule en bon père de famille."),
        bullet("Ne pas sous-louer ni transporter des personnes à titre onéreux."),
        bullet("Ne pas laisser des personnes autres que celles autorisées par l'agence conduire le véhicule."),
        bullet("Ne pas participer à des rallyes, courses ou autres compétitions."),
        bullet("Ne pas utiliser le véhicule à des fins illicites."),
        bullet("Ne pas atteler de remorques ou de véhicules similaires."),
        bullet("N'utiliser le véhicule que sur le territoire national."),

        legalHeading('DURÉE DE LOCATION :'),
        legalPara("La période minimale de la location est de 24 heures, la durée fixée au contrat est ferme et non révisable. En cas de restitution anticipée du véhicule, aucun remboursement ne sera effectué."),

        legalHeading('RESTITUTION DU VÉHICULE :'),
        legalPara("Le locataire est tenu de restituer le véhicule à la date et au lieu prévus au contrat. La restitution doit intervenir durant les heures d'ouverture de l'agence. En cas de non-restitution dans les délais impartis, le loueur se réserve le droit d'entreprendre toutes démarches nécessaires pour préserver ses intérêts."),

        legalHeading('PROROGATION DE LA DURÉE DE LOCATION :'),
        legalPara("La prorogation n'est possible qu'avec le consentement du loueur, et la demande doit être formulée 48 heures avant la fin du contrat en cours et après paiement des frais correspondant à la durée sollicitée."),

        legalHeading('RÉSERVATION / ANNULATION :'),
        legalPara("Pour toute réservation, un acompte de 30 % du coût de location est exigé. En cas d'annulation notifiée plus de 48 heures avant le départ, le montant de l'acompte sera remboursé déduction faite des frais de dossier. Passé ce délai, l'acompte ne sera pas restitué."),

        legalHeading('CARBURANT / LUBRIFIANT / KILOMÉTRAGE :'),
        legalPara("Le véhicule est livré avec le plein de carburant et doit être restitué avec le plein, tout manquement entraîne une facturation du carburant. Le locataire doit vérifier régulièrement le niveau d'huile et d'eau. Le kilométrage est limité à 300 km par jour ; au-delà, le loueur se réserve le droit de facturer 25 Da/km."),

        legalHeading('ASSURANCE :'),
        legalPara("Nos véhicules sont couverts par une assurance valable uniquement en Algérie. L'assurance ne couvre pas les sinistres en état d'ivresse. Tout sinistre non déclaré par l'assuré sera facturé au locataire. Seuls les conducteurs autorisés par l'agence peuvent se prévaloir de la qualité d'assurés."),
        legalPara("Sous peine d'être déchu du bénéfice de l'assurance, le locataire s'engage à déclarer dans les 24 heures à l'agence et aux autorités de police tout accident, incident, vol ou incendie, même partiel."),

        legalHeading('RESPONSABILITÉ :'),
        legalPara("Le locataire demeure seul responsable des amendes, contraventions et procès-verbaux établis contre lui. La responsabilité du loueur ne peut être engagée au-delà de la couverture fournie par l'assurance."),

        legalHeading('BLOCAGE DE LA CAUTION :'),
        legalPara("L'agence se réserve le droit de bloquer la caution en cas d'accident, de vol ou de détérioration ; elle pourra être utilisée pour le paiement des frais non couverts par l'assurance."),

        legalHeading('DROIT APPLICABLE / JURIDICTION :'),
        legalPara("Le présent contrat est régi par le droit algérien ; la juridiction compétente est le tribunal de commerce de Bejaïa. Pour chaque retard d'une heure, le locataire devra payer 400 Da."),

        new Paragraph({
          spacing: { before: 200 },
          children: [new TextRun({ text: 'Signature du client (avec la mention « lu et approuvé »).', size: 16, italics: true })],
        }),
      ],
    }],
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outPath, buffer);
  return outPath;
}

module.exports = { buildContractDocx };
