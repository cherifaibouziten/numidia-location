const nodemailer = require('nodemailer');

const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT || '587'),
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
    tls: { rejectUnauthorized: false },
  });
};

exports.sendVerificationEmail = async (email, name, token) => {
  // In dev mode, just log the token
  if (!process.env.EMAIL_USER || process.env.EMAIL_USER === 'your_email@gmail.com') {
    console.log(`[DEV] Verification token for ${email}: ${token}`);
    return true;
  }
  try {
    const transporter = createTransporter();
    const verifyUrl = `${process.env.CLIENT_URL}/verify-email?token=${token}`;
    await transporter.sendMail({
      from: `"NUMIDIA Cars & Immo" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Vérification de votre compte NUMIDIA',
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px">
          <h2 style="color:#2563EB">NUMIDIA Cars & Immo</h2>
          <p>Bonjour ${name},</p>
          <p>Merci de vous être inscrit. Veuillez vérifier votre email en cliquant sur le bouton ci-dessous :</p>
          <a href="${verifyUrl}" style="display:inline-block;padding:12px 24px;background:#2563EB;color:white;text-decoration:none;border-radius:8px;margin:16px 0">
            Vérifier mon email
          </a>
          <p style="color:#666;font-size:14px">Ce lien expire dans 24 heures.</p>
          <p style="color:#666;font-size:12px">Si vous n'avez pas créé de compte, ignorez cet email.</p>
        </div>
      `
    });
    return true;
  } catch (err) {
    console.error('Email send error:', err.message);
    return false;
  }
};

exports.sendAdminRequestEmail = async (adminEmail, requesterName) => {
  if (!process.env.EMAIL_USER || process.env.EMAIL_USER === 'your_email@gmail.com') {
    console.log(`[DEV] Admin request from ${requesterName} — needs approval`);
    return;
  }
  try {
    const transporter = createTransporter();
    await transporter.sendMail({
      from: `"NUMIDIA Cars & Immo" <${process.env.EMAIL_USER}>`,
      to: adminEmail,
      subject: 'Demande de promotion administrateur',
      html: `<p><b>${requesterName}</b> a demandé à devenir administrateur. Connectez-vous pour approuver ou rejeter.</p>`
    });
  } catch (err) {
    console.error('Email error:', err.message);
  }
};

exports.sendResetPasswordEmail = async (email, name, token) => {
  if (!process.env.EMAIL_USER || process.env.EMAIL_USER === 'your_email@gmail.com') {
    console.log(`[DEV] Password reset token for ${email}: ${token}`);
    return true;
  }
  try {
    const transporter = createTransporter();
    const resetUrl = `${process.env.CLIENT_URL}/reset-password?token=${token}`;
    await transporter.sendMail({
      from: `"NUMIDIA Cars & Immo" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Réinitialisation de votre mot de passe',
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px">
          <h2 style="color:#2563EB">NUMIDIA Cars & Immo</h2>
          <p>Bonjour ${name},</p>
          <p>Vous avez demandé à réinitialiser votre mot de passe. Cliquez ci-dessous :</p>
          <a href="${resetUrl}" style="display:inline-block;padding:12px 24px;background:#2563EB;color:white;text-decoration:none;border-radius:8px;margin:16px 0">
            Réinitialiser mon mot de passe
          </a>
          <p style="color:#666;font-size:14px">Ce lien expire dans 1 heure. Si vous n'êtes pas à l'origine de cette demande, ignorez cet email.</p>
        </div>
      `
    });
    return true;
  } catch (err) {
    console.error('Email send error:', err.message);
    return false;
  }
};
