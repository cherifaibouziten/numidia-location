/**
 * permissions.js — RBAC granulaire.
 * Le rôle fixe un jeu de permissions par défaut ; l'admin principal peut
 * ensuite ajouter/retirer des permissions à un utilisateur individuellement.
 */
const PERMISSIONS = {
  DASHBOARD_EXEC: 'dashboard.view_exec',
  EMPLOYES_MANAGE: 'employes.manage',
  ADMINS_MANAGE: 'admins.manage',
  AGENCES_MANAGE: 'agences.manage',
  VEHICULES_CRUD: 'vehicules.crud',
  RESERVATIONS_VALIDATE: 'reservations.validate',
  CLIENTS_MANAGE: 'clients.manage',
  CONTRATS_GENERATE: 'contrats.generate',
  PAIEMENTS_MANAGE: 'paiements.manage',
  PROMOTIONS_MANAGE: 'promotions.manage',
  SIGNALEMENTS_HANDLE: 'signalements.handle',
  MAINTENANCE_MANAGE: 'maintenance.manage',
  RAPPORTS_EXPORT: 'rapports.export',
  AUDIT_VIEW: 'audit.view',
  PARAMETRES_MANAGE: 'parametres.manage',
};

const ALL_PERMISSIONS = Object.values(PERMISSIONS);

const P = PERMISSIONS;

// Jeux de permissions par défaut selon le rôle
const DEFAULT_PERMISSIONS = {
  admin_principal: ALL_PERMISSIONS,
  admin: [
    P.DASHBOARD_EXEC, P.EMPLOYES_MANAGE, P.VEHICULES_CRUD, P.RESERVATIONS_VALIDATE,
    P.CLIENTS_MANAGE, P.CONTRATS_GENERATE, P.PAIEMENTS_MANAGE, P.PROMOTIONS_MANAGE,
    P.SIGNALEMENTS_HANDLE, P.MAINTENANCE_MANAGE, P.RAPPORTS_EXPORT,
  ],
  employe: [
    P.VEHICULES_CRUD, P.RESERVATIONS_VALIDATE, P.CLIENTS_MANAGE,
    P.CONTRATS_GENERATE, P.SIGNALEMENTS_HANDLE, P.MAINTENANCE_MANAGE,
  ],
  client: [],
};

/** L'utilisateur a-t-il la permission ? (l'admin principal a tout) */
function hasPermission(user, perm) {
  if (!user) return false;
  if (user.role === 'admin_principal') return true;
  return Array.isArray(user.permissions) && user.permissions.includes(perm);
}

module.exports = { PERMISSIONS, ALL_PERMISSIONS, DEFAULT_PERMISSIONS, hasPermission };
