/**
 * availability.js
 * Date-interval based availability for vehicles.
 *
 * Why: a vehicle is NOT "rented forever" the moment a reservation exists.
 * It is only unavailable during the [dateDebut, dateFin] interval of an
 * ACTIVE reservation. Two reservations may coexist on the same car as long
 * as their date intervals do not overlap.
 */
const Reservation = require('../models/Reservation');

// Reservation statuses that actually block the car during their interval.
// 'terminée' and 'annulée' never block.
const BLOCKING = ['confirmée', 'en_cours', 'en_retard'];

/**
 * Find a blocking reservation that overlaps [start, end] for a given vehicle.
 * Two intervals [a1,a2] and [b1,b2] overlap when: a1 <= b2 AND b1 <= a2.
 * @param excludeId  reservation id to ignore (used when editing)
 * @returns the overlapping reservation document, or null.
 */
async function findOverlap(vehiculeId, start, end, excludeId = null) {
  const query = {
    vehicule: vehiculeId,
    statut: { $in: BLOCKING },
    dateDebut: { $lte: new Date(end) },
    dateFin: { $gte: new Date(start) },
  };
  if (excludeId) query._id = { $ne: excludeId };
  return Reservation.findOne(query);
}

/**
 * Recompute the *display* status of a set of already-fetched vehicle docs,
 * based on whether a blocking reservation covers "now".
 * - Manual states ('maintenance', 'hors_service') are left untouched.
 * - 'louée' if a blocking reservation is active right now.
 * - 'disponible' otherwise (even if FUTURE reservations exist — the car is
 *   free today and bookable for any non-overlapping interval).
 * Persists only the vehicles whose status actually changed (bulkWrite),
 * and mutates the in-memory docs so the caller can return them directly.
 */
async function syncMany(Vehicule, vehicules) {
  if (!vehicules || vehicules.length === 0) return;
  const ids = vehicules.map(v => v._id);
  const now = new Date();

  const actives = await Reservation.find({
    vehicule: { $in: ids },
    statut: { $in: BLOCKING },
    dateDebut: { $lte: now },
    dateFin: { $gte: now },
  }).select('vehicule');

  const activeSet = new Set(actives.map(r => String(r.vehicule)));
  const ops = [];

  for (const v of vehicules) {
    if (v.statut === 'maintenance' || v.statut === 'hors_service') continue;
    const target = activeSet.has(String(v._id)) ? 'louée' : 'disponible';
    if (v.statut !== target) {
      v.statut = target; // mutate in-memory copy
      ops.push({ updateOne: { filter: { _id: v._id }, update: { statut: target } } });
    }
  }
  if (ops.length) await Vehicule.bulkWrite(ops);
}

/** Recompute status for a single vehicle id. */
async function syncOne(Vehicule, vehiculeId) {
  const v = await Vehicule.findById(vehiculeId);
  if (!v) return;
  await syncMany(Vehicule, [v]);
}

module.exports = { findOverlap, syncMany, syncOne, BLOCKING };
