const mongoose = require('mongoose');

const vehiculeSchema = new mongoose.Schema({
  marque: { type: String, required: true, trim: true },
  modele: { type: String, required: true, trim: true },
  immatriculation: { type: String, required: true, unique: true, uppercase: true, trim: true },
  annee: { type: Number, required: true },
  couleur: { type: String, default: '' },
  categorie: {
    type: String,
    enum: ['Citadine', 'Berline', 'SUV', 'Luxe', 'Utilitaire', '4x4', 'Cabriolet'],
    default: 'Berline'
  },
  carburant: {
    type: String,
    enum: ['Essence', 'Diesel', 'Électrique', 'Hybride', 'GPL'],
    default: 'Essence'
  },
  transmission: { type: String, enum: ['Manuelle', 'Automatique'], default: 'Manuelle' },
  kilometrage: { type: Number, default: 0 },
  prixParJour: { type: Number, required: true },
  statut: {
    type: String,
    enum: ['disponible', 'louée', 'maintenance', 'réservée', 'hors_service'],
    default: 'disponible'
  },
  photos: [{ type: String }],           // Array of image paths/URLs
  photo: { type: String, default: '' }, // Primary photo
  assuranceExpire: { type: Date },
  contrôleTechnique: { type: Date },
  prochainEntretien: { type: Number },
  numeroSerie: { type: String, default: '' }, // N° châssis
  assurance: { type: String, default: '' },   // Insurance company/number
  notes: { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Vehicule', vehiculeSchema);
