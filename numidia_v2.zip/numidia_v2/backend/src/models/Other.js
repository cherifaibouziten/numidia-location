const mongoose = require('mongoose');

const maintenanceSchema = new mongoose.Schema({
  vehicule: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicule', required: true },
  type: {
    type: String,
    enum: ['Vidange', 'Pneus', 'Freins', 'Révision', 'Carrosserie', 'Electricité', 'Autre'],
    required: true
  },
  description: { type: String, default: '' },
  cout: { type: Number, default: 0 },
  date: { type: Date, required: true },
  kmActuel: { type: Number, default: 0 },
  garage: { type: String, default: '' },
  statut: { type: String, enum: ['planifié', 'en_cours', 'terminé'], default: 'planifié' },
  notes: { type: String, default: '' },
}, { timestamps: true });

const notificationSchema = new mongoose.Schema({
  titre: { type: String, required: true },
  message: { type: String, required: true },
  type: { type: String, enum: ['info', 'warning', 'success', 'error'], default: 'info' },
  priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
  lu: { type: Boolean, default: false },
  destinataire: { type: mongoose.Schema.Types.ObjectId, ref: 'Admin' },
  lienType: { type: String, default: '' },
  lienId: { type: mongoose.Schema.Types.ObjectId },
}, { timestamps: true });

module.exports = {
  Maintenance: mongoose.model('Maintenance', maintenanceSchema),
  Notification: mongoose.model('Notification', notificationSchema),
};
