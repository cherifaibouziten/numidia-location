const mongoose = require('mongoose');

const reservationSchema = new mongoose.Schema({
  numero: { type: String, unique: true },
  client: { type: mongoose.Schema.Types.ObjectId, ref: 'Client', required: true },
  clientSecondaire: { type: mongoose.Schema.Types.ObjectId, ref: 'Client' }, // 2nd driver
  vehicule: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicule', required: true },
  admin: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  dateDebut: { type: Date, required: true },
  dateFin: { type: Date, required: true },
  dateRetourReel: { type: Date },
  prixParJour: { type: Number, required: true },
  nombreJours: { type: Number, required: true },
  prixTotal: { type: Number, required: true },
  caution: { type: Number, default: 0 },
  cautionRendue: { type: Boolean, default: false },
  versement: { type: Number, default: 0 },  // acompte versé
  reste: { type: Number, default: 0 },       // reste à payer
  methodePaiement: {
    type: String,
    enum: ['Espèces', 'Virement', 'Chèque', 'CCP'],
    default: 'Espèces'
  },
  statut: {
    type: String,
    enum: ['confirmée', 'en_cours', 'terminée', 'annulée', 'en_retard'],
    default: 'confirmée'
  },
  kmDepart: { type: Number, default: 0 },
  kmRetour: { type: Number, default: 0 },
  // Accessories checklist from contract
  accessoires: {
    lavageEntretient: { type: Boolean, default: false },
    roueSecours: { type: Boolean, default: false },
    crick: { type: Boolean, default: false },
    trianglePanne: { type: Boolean, default: false },
    poste: { type: Boolean, default: false },
    salon: { type: Boolean, default: false },
    longeLeveur: { type: Boolean, default: false },
    klaxon: { type: Boolean, default: false },
    carburant: { type: Boolean, default: false },
    barres: { type: Boolean, default: false },
  },
  remarques: { type: String, default: '300 Km par jour / 25 Da pour chaque Km' },
  notes: { type: String, default: '' },
  contratGenere: { type: Boolean, default: false },
}, { timestamps: true });

reservationSchema.pre('save', async function(next) {
  if (!this.numero) {
    const count = await mongoose.model('Reservation').countDocuments();
    this.numero = `RES-${String(count + 1).padStart(5, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Reservation', reservationSchema);
