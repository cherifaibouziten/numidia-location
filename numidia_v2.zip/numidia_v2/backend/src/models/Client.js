const mongoose = require('mongoose');

const clientSchema = new mongoose.Schema({
  nom: { type: String, required: true, trim: true },
  prenom: { type: String, required: true, trim: true },
  email: { type: String, default: '', lowercase: true, trim: true },
  telephone: { type: String, required: true },
  adresse: { type: String, default: '' },
  wilaya: { type: String, default: '' },
  dateNaissance: { type: Date },
  lieuNaissance: { type: String, default: '' },
  permisNumero: { type: String, default: '' },
  permisExpire: { type: Date },
  permisDelivreAPC: { type: String, default: '' },
  typePermis: { type: String, default: 'B' },
  nationalite: { type: String, default: 'Algérienne' },
  numeroCIN: { type: String, default: '' },
  numeroPasport: { type: String, default: '' },
  sejour: { type: String, default: '' },
  blacklist: { type: Boolean, default: false },
  blacklistRaison: { type: String, default: '' },
  notes: { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Client', clientSchema);
