/**
 * Audit — journal d'activité (toutes les actions sensibles) +
 * historique des connexions (sécurité).
 */
const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema({
  acteur: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  acteurNom: { type: String, default: '' },
  action: { type: String, required: true },     // ex: "promote_user", "create_vehicule"
  entite: { type: String, default: '' },          // ex: "User", "Vehicule"
  entiteId: { type: mongoose.Schema.Types.ObjectId },
  details: { type: mongoose.Schema.Types.Mixed },
  ip: { type: String, default: '' },
}, { timestamps: true });

const loginHistorySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  email: { type: String, default: '' },
  ip: { type: String, default: '' },
  appareil: { type: String, default: '' },
  userAgent: { type: String, default: '' },
  succes: { type: Boolean, default: false },
}, { timestamps: true });

module.exports = {
  Activity: mongoose.model('Activity', activitySchema),
  LoginHistory: mongoose.model('LoginHistory', loginHistorySchema),
};
