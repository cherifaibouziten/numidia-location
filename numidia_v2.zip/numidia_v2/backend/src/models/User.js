/**
 * User — modèle unifié pour TOUS les comptes :
 * admin_principal | admin | employe | client.
 * Remplace l'ancien modèle Admin (collection "users").
 */
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  role: {
    type: String,
    enum: ['admin_principal', 'admin', 'employe', 'client'],
    default: 'client',
  },
  nom: { type: String, required: true, trim: true },
  prenom: { type: String, default: '', trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  motDePasse: { type: String, required: true, minlength: 6 },
  telephone: { type: String, default: '' },
  avatar: { type: String, default: '' },

  // RBAC : permissions granulaires (en plus du rôle)
  permissions: { type: [String], default: [] },

  // Multi-agences (employés/admins) — null pour un client
  agence: { type: mongoose.Schema.Types.ObjectId, ref: 'Agence' },

  // Vérification email (obligatoire à chaque inscription)
  isVerified: { type: Boolean, default: false },
  verificationToken: { type: String },
  verificationExpires: { type: Date },

  // Réinitialisation du mot de passe
  resetPasswordToken: { type: String },
  resetPasswordExpires: { type: Date },

  // Cycle de vie du compte
  // - client  : 'actif' dès la vérification email
  // - employe : 'en_attente_activation' jusqu'à validation par un admin
  statut: {
    type: String,
    enum: ['actif', 'suspendu', 'en_attente_activation'],
    default: 'actif',
  },

  // Demande de promotion (employe -> admin)
  promotionStatus: {
    type: String,
    enum: ['none', 'pending', 'approved', 'rejected'],
    default: 'none',
  },
  promotionDate: { type: Date },

  derniereConnexion: { type: Date },
}, { timestamps: true });

userSchema.pre('save', async function (next) {
  if (!this.isModified('motDePasse')) return next();
  this.motDePasse = await bcrypt.hash(this.motDePasse, 12);
  next();
});

userSchema.methods.comparePassword = function (password) {
  return bcrypt.compare(password, this.motDePasse);
};

userSchema.methods.toSafeObject = function () {
  const o = this.toObject();
  delete o.motDePasse;
  delete o.verificationToken;
  delete o.resetPasswordToken;
  return o;
};

module.exports = mongoose.model('User', userSchema);
