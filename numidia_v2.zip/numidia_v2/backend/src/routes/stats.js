const { statsRouter } = require('./other');
module.exports = statsRouter;
