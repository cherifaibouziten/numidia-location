// ============ RESERVATIONS ============
const express = require('express');
const router = express.Router();
const Reservation = require('../models/Reservation');
const Vehicule = require('../models/Vehicule');
const { protect, requireStaff } = require('../middleware/auth');
const { findOverlap, syncOne, BLOCKING } = require('../utils/availability');

router.use(protect);

const fmt = (d) => new Date(d).toLocaleDateString('fr-DZ');

router.get('/', async (req, res) => {
  try {
    const { statut, vehicule, client, search } = req.query;
    const filter = {};
    if (statut) filter.statut = statut;
    if (vehicule) filter.vehicule = vehicule;
    if (client) filter.client = client;
    const reservations = await Reservation.find(filter)
      .populate('client', 'nom prenom telephone')
      .populate('vehicule', 'marque modele immatriculation photo')
      .populate('admin', 'nom')
      .sort('-createdAt');
    res.json(reservations);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const r = await Reservation.findById(req.params.id)
      .populate('client')
      .populate('clientSecondaire')
      .populate('vehicule')
      .populate('admin', 'nom prenom');
    if (!r) return res.status(404).json({ message: 'Réservation introuvable' });
    res.json(r);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/', requireStaff, async (req, res) => {
  try {
    const body = req.body;
    body.admin = req.user._id;

    // Reject double-booking: only if the chosen interval overlaps an
    // existing ACTIVE reservation on the same vehicle.
    const overlap = await findOverlap(body.vehicule, body.dateDebut, body.dateFin);
    if (overlap) {
      return res.status(409).json({
        message: `Ce véhicule est déjà réservé du ${fmt(overlap.dateDebut)} au ${fmt(overlap.dateFin)}. Choisissez d'autres dates.`,
      });
    }

    const created = await Reservation.create(body);
    // Set the car to 'louée' ONLY if this reservation is active right now;
    // a future booking leaves the car 'disponible' and bookable for other dates.
    await syncOne(Vehicule, body.vehicule);

    req.io?.emit('reservation_créée', created);
    const populated = await Reservation.findById(created._id)
      .populate('client', 'nom prenom telephone')
      .populate('vehicule', 'marque modele immatriculation photo');
    res.status(201).json(populated);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.put('/:id', requireStaff, async (req, res) => {
  try {
    const existing = await Reservation.findById(req.params.id);
    if (!existing) return res.status(404).json({ message: 'Réservation introuvable' });

    const vehiculeId = req.body.vehicule || existing.vehicule;
    const start = req.body.dateDebut || existing.dateDebut;
    const end = req.body.dateFin || existing.dateFin;
    const newStatut = req.body.statut || existing.statut;

    // Re-check overlap only if the reservation remains in a blocking status.
    if (BLOCKING.includes(newStatut)) {
      const overlap = await findOverlap(vehiculeId, start, end, existing._id);
      if (overlap) {
        return res.status(409).json({
          message: `Conflit : ce véhicule est déjà réservé du ${fmt(overlap.dateDebut)} au ${fmt(overlap.dateFin)}.`,
        });
      }
    }

    const r = await Reservation.findByIdAndUpdate(req.params.id, req.body, { new: true })
      .populate('client', 'nom prenom telephone')
      .populate('vehicule', 'marque modele immatriculation photo');

    // Recompute the (possibly two) affected vehicles' display status.
    await syncOne(Vehicule, vehiculeId);
    if (req.body.vehicule && String(req.body.vehicule) !== String(existing.vehicule)) {
      await syncOne(Vehicule, existing.vehicule);
    }

    req.io?.emit('reservation_modifiée', r);
    res.json(r);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.delete('/:id', requireStaff, async (req, res) => {
  try {
    const r = await Reservation.findByIdAndDelete(req.params.id);
    // Recompute status (don't blindly set 'disponible' — another active
    // reservation might still cover this car right now).
    if (r) await syncOne(Vehicule, r.vehicule);
    res.json({ message: 'Réservation supprimée' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
