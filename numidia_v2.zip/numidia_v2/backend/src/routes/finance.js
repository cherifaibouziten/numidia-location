const { financeRouter } = require('./other');
module.exports = financeRouter;
