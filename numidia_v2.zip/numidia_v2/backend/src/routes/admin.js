// Alias de compatibilité : /api/admin -> mêmes routes que /api/users
module.exports = require('./users');
