const { notifRouter } = require('./other');
module.exports = notifRouter;
