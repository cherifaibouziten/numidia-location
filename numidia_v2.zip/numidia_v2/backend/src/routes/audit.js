const express = require('express');
const router = express.Router();
const { Activity } = require('../models/Audit');
const { protect, requirePermission } = require('../middleware/auth');
const { PERMISSIONS } = require('../utils/permissions');

router.use(protect, requirePermission(PERMISSIONS.AUDIT_VIEW));

// Journal d'activité (audit complet)
router.get('/', async (req, res) => {
  try {
    const { entite, action, limit = 100 } = req.query;
    const filter = {};
    if (entite) filter.entite = entite;
    if (action) filter.action = action;
    const items = await Activity.find(filter)
      .populate('acteur', 'nom prenom role')
      .sort('-createdAt')
      .limit(parseInt(limit));
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
