const express = require('express');
const router = express.Router();
const Vehicule = require('../models/Vehicule');
const Reservation = require('../models/Reservation');
const { protect, requireStaff } = require('../middleware/auth');
const upload = require('../utils/upload');
const { syncMany, BLOCKING } = require('../utils/availability');
const path = require('path');

router.use(protect);

// Get all vehicles with search/filter
router.get('/', async (req, res) => {
  try {
    const { statut, categorie, search, page = 1, limit = 50 } = req.query;
    const filter = {};
    if (categorie) filter.categorie = categorie;
    if (search) {
      filter.$or = [
        { marque: { $regex: search, $options: 'i' } },
        { modele: { $regex: search, $options: 'i' } },
        { immatriculation: { $regex: search, $options: 'i' } },
      ];
    }
    let vehicles = await Vehicule.find(filter)
      .sort('-createdAt')
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    // Refresh display status from reservations active "now" (handles the
    // transition disponible -> louée when a rental's start date arrives).
    await syncMany(Vehicule, vehicles);
    // Apply the status filter AFTER syncing so it reflects reality.
    if (statut) vehicles = vehicles.filter(v => v.statut === statut);
    res.json({ vehicles, total: vehicles.length, page: parseInt(page) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get vehicles available for a specific date interval.
// Query: ?dateDebut=ISO&dateFin=ISO  → excludes cars with an overlapping
// active reservation (and cars in maintenance / hors_service).
// IMPORTANT: declared BEFORE '/:id' so Express doesn't treat "disponibles" as an id.
router.get('/disponibles', async (req, res) => {
  try {
    const { dateDebut, dateFin } = req.query;
    const pool = await Vehicule.find({ statut: { $nin: ['maintenance', 'hors_service'] } }).sort('-createdAt');

    if (!dateDebut || !dateFin) {
      return res.json({ vehicles: pool });
    }

    const start = new Date(dateDebut);
    const end = new Date(dateFin);
    const overlaps = await Reservation.find({
      statut: { $in: BLOCKING },
      dateDebut: { $lte: end },
      dateFin: { $gte: start },
    }).select('vehicule');

    const busy = new Set(overlaps.map(o => String(o.vehicule)));
    const available = pool.filter(v => !busy.has(String(v._id)));
    res.json({ vehicles: available });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get single vehicle
router.get('/:id', async (req, res) => {
  try {
    const v = await Vehicule.findById(req.params.id);
    if (!v) return res.status(404).json({ message: 'Véhicule introuvable' });
    res.json(v);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create vehicle (admin only)
router.post('/', requireStaff, upload.single('photo'), async (req, res) => {
  try {
    const data = { ...req.body };
    if (req.file) {
      data.photo = `/uploads/vehicles/${req.file.filename}`;
      data.photos = [data.photo];
    }
    const vehicule = await Vehicule.create(data);
    req.io?.emit('vehicule_créé', vehicule);
    res.status(201).json(vehicule);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update vehicle (admin only)
router.put('/:id', requireStaff, upload.single('photo'), async (req, res) => {
  try {
    const data = { ...req.body };
    if (req.file) {
      data.photo = `/uploads/vehicles/${req.file.filename}`;
    }
    const vehicule = await Vehicule.findByIdAndUpdate(req.params.id, data, { new: true });
    if (!vehicule) return res.status(404).json({ message: 'Véhicule introuvable' });
    req.io?.emit('vehicule_modifié', vehicule);
    res.json(vehicule);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete vehicle (admin only)
router.delete('/:id', requireStaff, async (req, res) => {
  try {
    await Vehicule.findByIdAndDelete(req.params.id);
    req.io?.emit('vehicule_supprimé', { id: req.params.id });
    res.json({ message: 'Véhicule supprimé' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
