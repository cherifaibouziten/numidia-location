/**
 * Gestion des utilisateurs (admin) : employés, clients, promotions, permissions.
 * Monté sur /api/users (et /api/admin en alias de compatibilité).
 */
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const User = require('../models/User');
const { protect, requireAdmin, requireRole, requirePermission } = require('../middleware/auth');
const { PERMISSIONS, ALL_PERMISSIONS, DEFAULT_PERMISSIONS } = require('../utils/permissions');
const { logActivity } = require('../utils/audit');
const { sendVerificationEmail } = require('../utils/email');

router.use(protect, requireAdmin);

// Liste des permissions disponibles (pour l'UI)
router.get('/permissions', (req, res) => {
  res.json({ permissions: ALL_PERMISSIONS, defaults: DEFAULT_PERMISSIONS });
});

// Liste des utilisateurs (filtres: role, statut, search)
router.get('/', async (req, res) => {
  try {
    const { role, statut, search } = req.query;
    const filter = {};
    if (role) filter.role = role;
    if (statut) filter.statut = statut;
    if (search) {
      filter.$or = [
        { nom: { $regex: search, $options: 'i' } },
        { prenom: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }
    const users = await User.find(filter).select('-motDePasse -verificationToken -resetPasswordToken').sort('-createdAt');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Employés en attente d'activation
router.get('/pending', async (req, res) => {
  try {
    const users = await User.find({ role: 'employe', statut: 'en_attente_activation' })
      .select('-motDePasse').sort('-createdAt');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Demandes de promotion (employé -> admin)
router.get('/promotion-requests', async (req, res) => {
  try {
    const users = await User.find({ promotionStatus: 'pending' })
      .select('-motDePasse').sort('-promotionDate');
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Créer un employé directement (par un admin) — email de vérification quand même envoyé
router.post('/employees', requirePermission(PERMISSIONS.EMPLOYES_MANAGE), async (req, res) => {
  try {
    const { nom, prenom, email, motDePasse, telephone } = req.body;
    if (!nom || !email || !motDePasse)
      return res.status(400).json({ message: 'Nom, email et mot de passe requis' });
    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ message: 'Email déjà utilisé' });

    const verificationToken = crypto.randomBytes(32).toString('hex');
    const user = await User.create({
      nom, prenom: prenom || '', email, motDePasse, telephone: telephone || '',
      role: 'employe',
      statut: 'actif', // créé par un admin => directement activable après vérif email
      permissions: DEFAULT_PERMISSIONS.employe,
      isVerified: false,
      verificationToken,
      verificationExpires: Date.now() + 24 * 60 * 60 * 1000,
    });
    await sendVerificationEmail(email, nom, verificationToken);
    await logActivity(req, 'create_employee', 'User', user._id);
    res.status(201).json(user.toSafeObject());
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Activer un employé (en_attente_activation -> actif)
router.put('/:id/activate', requirePermission(PERMISSIONS.EMPLOYES_MANAGE), async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { statut: 'actif' }, { new: true }).select('-motDePasse');
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    await logActivity(req, 'activate_user', 'User', user._id);
    req.io?.emit('user_activated', { userId: user._id });
    res.json({ message: 'Compte activé', user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Suspendre
router.put('/:id/suspend', requirePermission(PERMISSIONS.EMPLOYES_MANAGE), async (req, res) => {
  try {
    if (req.params.id === req.user._id.toString())
      return res.status(400).json({ message: 'Impossible de suspendre votre propre compte' });
    const target = await User.findById(req.params.id);
    if (!target) return res.status(404).json({ message: 'Utilisateur introuvable' });
    if (target.role === 'admin_principal')
      return res.status(403).json({ message: 'Impossible de suspendre l\'administrateur principal' });
    target.statut = 'suspendu';
    await target.save();
    await logActivity(req, 'suspend_user', 'User', target._id);
    res.json({ message: 'Compte suspendu', user: target.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Réactiver
router.put('/:id/reactivate', requirePermission(PERMISSIONS.EMPLOYES_MANAGE), async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { statut: 'actif' }, { new: true }).select('-motDePasse');
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    await logActivity(req, 'reactivate_user', 'User', user._id);
    res.json({ message: 'Compte réactivé', user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Promouvoir un employé en admin (admin principal seulement)
router.put('/:id/promote', requireRole('admin_principal'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    if (user.role !== 'employe')
      return res.status(400).json({ message: 'Seul un employé peut être promu administrateur' });

    user.role = 'admin';
    user.permissions = DEFAULT_PERMISSIONS.admin;
    user.promotionStatus = 'approved';
    await user.save();
    await logActivity(req, 'promote_user', 'User', user._id);
    req.io?.emit('user_promoted', { userId: user._id });
    res.json({ message: 'Employé promu administrateur', user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Rejeter une demande de promotion
router.put('/:id/reject-promotion', requireRole('admin_principal'), async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { promotionStatus: 'rejected' }, { new: true }).select('-motDePasse');
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    await logActivity(req, 'reject_promotion', 'User', user._id);
    res.json({ message: 'Demande rejetée', user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Mettre à jour les permissions d'un utilisateur (admin principal)
router.put('/:id/permissions', requireRole('admin_principal'), async (req, res) => {
  try {
    const { permissions } = req.body;
    if (!Array.isArray(permissions))
      return res.status(400).json({ message: 'permissions doit être un tableau' });
    const valid = permissions.filter(p => ALL_PERMISSIONS.includes(p));
    const user = await User.findByIdAndUpdate(req.params.id, { permissions: valid }, { new: true }).select('-motDePasse');
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    await logActivity(req, 'update_permissions', 'User', user._id, { permissions: valid });
    res.json({ message: 'Permissions mises à jour', user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Modifier infos de base
router.put('/:id', async (req, res) => {
  try {
    const { nom, prenom, telephone } = req.body;
    const user = await User.findByIdAndUpdate(req.params.id, { nom, prenom, telephone }, { new: true }).select('-motDePasse');
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    res.json(user.toSafeObject ? user.toSafeObject() : user);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Supprimer
router.delete('/:id', async (req, res) => {
  try {
    if (req.params.id === req.user._id.toString())
      return res.status(400).json({ message: 'Impossible de supprimer votre propre compte' });
    const target = await User.findById(req.params.id);
    if (!target) return res.status(404).json({ message: 'Utilisateur introuvable' });
    if (target.role === 'admin_principal')
      return res.status(403).json({ message: 'Impossible de supprimer l\'administrateur principal' });
    await User.findByIdAndDelete(req.params.id);
    await logActivity(req, 'delete_user', 'User', req.params.id);
    res.json({ message: 'Utilisateur supprimé' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
