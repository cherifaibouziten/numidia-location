// ============ STATS ============
const express = require('express');
const statsRouter = express.Router();
const Vehicule = require('../models/Vehicule');
const Reservation = require('../models/Reservation');
const Client = require('../models/Client');
const { Maintenance, Notification } = require('../models/Other');
const { protect, requireAdmin, requireStaff } = require('../middleware/auth');
const { syncMany } = require('../utils/availability');

statsRouter.use(protect, requireAdmin);

statsRouter.get('/', async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    // Refresh every vehicle's status from active reservations so the counts
    // below (disponibles / louées) reflect the current date, not stale flags.
    const allVehicules = await Vehicule.find();
    await syncMany(Vehicule, allVehicules);

    const [
      totalVehicules, disponibles, louées, maintenance, totalClients,
      reservationsActives, revenusMois, totalReservations
    ] = await Promise.all([
      Vehicule.countDocuments(),
      Vehicule.countDocuments({ statut: 'disponible' }),
      Vehicule.countDocuments({ statut: 'louée' }),
      Vehicule.countDocuments({ statut: 'maintenance' }),
      Client.countDocuments(),
      Reservation.countDocuments({ statut: { $in: ['confirmée', 'en_cours'] } }),
      Reservation.aggregate([
        { $match: { createdAt: { $gte: startOfMonth }, statut: { $ne: 'annulée' } } },
        { $group: { _id: null, total: { $sum: '$prixTotal' } } }
      ]),
      Reservation.countDocuments(),
    ]);
    const tauxOccupation = totalVehicules > 0
      ? Math.round((louées / totalVehicules) * 100)
      : 0;
    res.json({
      totalVehicules, disponibles, louées, maintenance,
      totalClients, reservationsActives, totalReservations,
      revenusMois: revenusMois[0]?.total || 0,
      tauxOccupation,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ============ FINANCE ============
const financeRouter = express.Router();
financeRouter.use(protect, requireAdmin);

financeRouter.get('/mensuel', async (req, res) => {
  try {
    const mois = await Reservation.aggregate([
      { $match: { statut: { $ne: 'annulée' }, createdAt: { $gte: new Date(new Date().getFullYear(), 0, 1) } } },
      { $group: { _id: { $month: '$createdAt' }, revenus: { $sum: '$prixTotal' }, reservations: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]);
    const MOIS = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
    const result = MOIS.map((label, i) => {
      const found = mois.find(m => m._id === i + 1);
      return { mois: label, revenus: found?.revenus || 0, reservations: found?.reservations || 0 };
    });
    res.json(result);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ============ MAINTENANCE ============
const maintenanceRouter = express.Router();
maintenanceRouter.use(protect, requireStaff);

maintenanceRouter.get('/', async (req, res) => {
  try {
    const items = await Maintenance.find().populate('vehicule', 'marque modele immatriculation').sort('-date');
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
maintenanceRouter.post('/', async (req, res) => {
  try {
    const m = await Maintenance.create(req.body);
    if (req.body.statut === 'en_cours') {
      await Vehicule.findByIdAndUpdate(req.body.vehicule, { statut: 'maintenance' });
    }
    res.status(201).json(m);
  } catch (err) { res.status(400).json({ message: err.message }); }
});
maintenanceRouter.put('/:id', async (req, res) => {
  try {
    const m = await Maintenance.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (req.body.statut === 'terminé') {
      await Vehicule.findByIdAndUpdate(m.vehicule, { statut: 'disponible' });
    }
    res.json(m);
  } catch (err) { res.status(400).json({ message: err.message }); }
});
maintenanceRouter.delete('/:id', async (req, res) => {
  try {
    await Maintenance.findByIdAndDelete(req.params.id);
    res.json({ message: 'Supprimé' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ============ NOTIFICATIONS ============
const notifRouter = express.Router();
notifRouter.use(protect);

notifRouter.get('/', async (req, res) => {
  try {
    const notifs = await Notification.find({ $or: [{ destinataire: req.user._id }, { destinataire: null }] }).sort('-createdAt').limit(50);
    res.json(notifs);
  } catch (err) { res.status(500).json({ message: err.message }); }
});
notifRouter.get('/count', async (req, res) => {
  try {
    const count = await Notification.countDocuments({ lu: false });
    res.json({ count });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
notifRouter.put('/:id/read', async (req, res) => {
  try {
    await Notification.findByIdAndUpdate(req.params.id, { lu: true });
    res.json({ message: 'Marqué comme lu' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});
notifRouter.put('/read-all', async (req, res) => {
  try {
    await Notification.updateMany({ lu: false }, { lu: true });
    res.json({ message: 'Toutes marquées comme lues' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

module.exports = { statsRouter, financeRouter, maintenanceRouter, notifRouter };
