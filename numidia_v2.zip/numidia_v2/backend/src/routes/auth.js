const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const User = require('../models/User');
const { LoginHistory } = require('../models/Audit');
const { protect } = require('../middleware/auth');
const { DEFAULT_PERMISSIONS } = require('../utils/permissions');
const { logActivity, logLogin } = require('../utils/audit');
const {
  sendVerificationEmail, sendResetPasswordEmail, sendAdminRequestEmail,
} = require('../utils/email');

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || '7d' });

const makeToken = () => crypto.randomBytes(32).toString('hex');

// ─── INSCRIPTION (client ou employé) ───────────────────────────────
// body: { nom, prenom, email, motDePasse, telephone, compte: 'client'|'employe' }
router.post('/register', async (req, res) => {
  try {
    const { nom, prenom, email, motDePasse, telephone, compte } = req.body;
    if (!nom || !email || !motDePasse)
      return res.status(400).json({ message: 'Nom, email et mot de passe sont requis' });
    if (String(motDePasse).length < 6)
      return res.status(400).json({ message: 'Le mot de passe doit faire au moins 6 caractères' });

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ message: 'Un compte existe déjà avec cet email' });

    // Seuls 'client' et 'employe' peuvent s'inscrire (jamais admin via inscription)
    const role = compte === 'employe' ? 'employe' : 'client';
    // Un employé doit être activé par un admin après vérification email
    const statut = role === 'employe' ? 'en_attente_activation' : 'actif';

    const verificationToken = makeToken();
    const user = await User.create({
      nom, prenom: prenom || '', email, motDePasse, telephone: telephone || '',
      role, statut,
      permissions: DEFAULT_PERMISSIONS[role] || [],
      isVerified: false,
      verificationToken,
      verificationExpires: Date.now() + 24 * 60 * 60 * 1000, // 24h
    });

    await sendVerificationEmail(email, nom, verificationToken);
    await logActivity(req, 'register', 'User', user._id, { role });

    res.status(201).json({
      message: role === 'employe'
        ? 'Compte employé créé. Vérifiez votre email, puis attendez l\'activation par un administrateur.'
        : 'Compte créé. Veuillez vérifier votre email pour activer votre compte.',
      userId: user._id,
      role,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── VÉRIFICATION EMAIL ────────────────────────────────────────────
router.get('/verify-email/:token', async (req, res) => {
  try {
    const user = await User.findOne({
      verificationToken: req.params.token,
      verificationExpires: { $gt: Date.now() },
    });
    if (!user) return res.status(400).json({ message: 'Token invalide ou expiré' });

    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationExpires = undefined;
    await user.save();
    await logActivity(req, 'verify_email', 'User', user._id);

    // Un employé reste en attente d'activation : pas de token de session ici
    if (user.role === 'employe' && user.statut === 'en_attente_activation') {
      return res.json({
        message: 'Email vérifié. Votre compte employé attend l\'activation par un administrateur.',
        pendingActivation: true,
        user: user.toSafeObject(),
      });
    }

    const token = signToken(user._id);
    res.json({ message: 'Email vérifié avec succès', token, user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── RENVOYER LA VÉRIFICATION ──────────────────────────────────────
router.post('/resend-verification', async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email: email?.toLowerCase() });
    if (!user) return res.status(404).json({ message: 'Compte introuvable' });
    if (user.isVerified) return res.status(400).json({ message: 'Email déjà vérifié' });

    user.verificationToken = makeToken();
    user.verificationExpires = Date.now() + 24 * 60 * 60 * 1000;
    await user.save();
    await sendVerificationEmail(email, user.nom, user.verificationToken);
    res.json({ message: 'Email de vérification renvoyé' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── CONNEXION ─────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, motDePasse } = req.body;
    if (!email || !motDePasse)
      return res.status(400).json({ message: 'Email et mot de passe requis' });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      await logLogin(req, email, null, false);
      return res.status(401).json({ message: 'Email ou mot de passe incorrect' });
    }

    const valid = await user.comparePassword(motDePasse);
    if (!valid) {
      await logLogin(req, email, user, false);
      return res.status(401).json({ message: 'Email ou mot de passe incorrect' });
    }

    // Vérification email obligatoire
    if (!user.isVerified) {
      await logLogin(req, email, user, false);
      return res.status(403).json({
        message: 'Veuillez vérifier votre email avant de vous connecter',
        needsVerification: true,
      });
    }

    if (user.statut === 'suspendu') {
      await logLogin(req, email, user, false);
      return res.status(403).json({ message: 'Votre compte a été suspendu' });
    }

    // Employé : doit être activé par un admin
    if (user.statut === 'en_attente_activation') {
      await logLogin(req, email, user, false);
      return res.status(403).json({
        message: 'Votre compte attend l\'activation par un administrateur',
        pendingActivation: true,
      });
    }

    user.derniereConnexion = new Date();
    await user.save();
    await logLogin(req, email, user, true);

    const token = signToken(user._id);
    res.json({ token, user: user.toSafeObject() });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── MOT DE PASSE OUBLIÉ ───────────────────────────────────────────
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email: email?.toLowerCase() });
    // Réponse identique que le compte existe ou non (anti-énumération)
    if (user) {
      user.resetPasswordToken = makeToken();
      user.resetPasswordExpires = Date.now() + 60 * 60 * 1000; // 1h
      await user.save();
      await sendResetPasswordEmail(user.email, user.nom, user.resetPasswordToken);
    }
    res.json({ message: 'Si un compte existe, un email de réinitialisation a été envoyé.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── RÉINITIALISATION ──────────────────────────────────────────────
router.post('/reset-password/:token', async (req, res) => {
  try {
    const { motDePasse } = req.body;
    if (!motDePasse || String(motDePasse).length < 6)
      return res.status(400).json({ message: 'Mot de passe trop court (min 6 caractères)' });

    const user = await User.findOne({
      resetPasswordToken: req.params.token,
      resetPasswordExpires: { $gt: Date.now() },
    });
    if (!user) return res.status(400).json({ message: 'Lien invalide ou expiré' });

    user.motDePasse = motDePasse; // hashé par le hook pre-save
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();
    await logActivity(req, 'reset_password', 'User', user._id);
    res.json({ message: 'Mot de passe réinitialisé. Vous pouvez vous connecter.' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── PROFIL COURANT ────────────────────────────────────────────────
router.get('/me', protect, async (req, res) => {
  res.json(req.user.toSafeObject ? req.user.toSafeObject() : req.user);
});

router.put('/profile', protect, async (req, res) => {
  try {
    const { nom, prenom, telephone } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user._id, { nom, prenom, telephone }, { new: true }
    );
    res.json(user.toSafeObject());
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── HISTORIQUE DE CONNEXIONS (sécurité) ───────────────────────────
router.get('/sessions', protect, async (req, res) => {
  try {
    const history = await LoginHistory.find({ user: req.user._id })
      .sort('-createdAt').limit(20);
    res.json(history);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── DEMANDE DE PROMOTION (employé -> admin) ───────────────────────
router.post('/request-admin', protect, async (req, res) => {
  try {
    if (req.user.role !== 'employe')
      return res.status(400).json({ message: 'Seuls les employés peuvent demander le rôle admin' });
    if (req.user.promotionStatus === 'pending')
      return res.status(400).json({ message: 'Demande déjà en cours' });

    await User.findByIdAndUpdate(req.user._id, {
      promotionStatus: 'pending', promotionDate: new Date(),
    });
    await logActivity(req, 'request_promotion', 'User', req.user._id);

    const admins = await User.find({ role: { $in: ['admin', 'admin_principal'] }, statut: 'actif' }).select('email');
    for (const a of admins) await sendAdminRequestEmail(a.email, `${req.user.nom} ${req.user.prenom}`);

    res.json({ message: 'Demande envoyée aux administrateurs' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ─── DÉCONNEXION (côté client : suppression du token) ──────────────
router.post('/logout', protect, async (req, res) => {
  await logActivity(req, 'logout', 'User', req.user._id);
  res.json({ message: 'Déconnecté' });
});

module.exports = router;
