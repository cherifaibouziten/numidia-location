/**
 * Contract generation route.
 * Builds a filled contract .docx from the official Numidia template fields,
 * preserving structure/formatting, and converts to PDF on demand.
 *
 * Strategy: we keep the canonical template (template.docx) in /templates and
 * fill its placeholder cells with the submitted values using docx-templater-style
 * token replacement on the unpacked XML — without altering layout, fonts, tables.
 */
const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');
const { protect, requireStaff } = require('../middleware/auth');
const { buildContractDocx } = require('../utils/contractBuilder');

const OUT_DIR = path.join(__dirname, '../../uploads/contracts');
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

router.use(protect, requireStaff);

/**
 * POST /api/contract/generate
 * body: { fields: {...}, format: 'docx' | 'pdf' }
 * Returns: download URL for the generated file.
 */
router.post('/generate', async (req, res) => {
  try {
    const { fields = {}, format = 'docx' } = req.body;
    const stamp = Date.now();
    const baseName = `contrat_${(fields.contratNumero || 'NUMIDIA').replace(/[^\w-]/g, '')}_${stamp}`;
    const docxPath = path.join(OUT_DIR, `${baseName}.docx`);

    // Build the docx (preserves the original contract structure)
    await buildContractDocx(fields, docxPath);

    if (format === 'pdf') {
      // Convert to PDF using LibreOffice (soffice)
      try {
        execSync(`soffice --headless --convert-to pdf --outdir "${OUT_DIR}" "${docxPath}"`, {
          timeout: 60000, stdio: 'ignore'
        });
        const pdfPath = path.join(OUT_DIR, `${baseName}.pdf`);
        if (fs.existsSync(pdfPath)) {
          return res.json({ url: `/uploads/contracts/${baseName}.pdf`, format: 'pdf' });
        }
      } catch (e) {
        console.warn('PDF conversion failed, returning docx:', e.message);
      }
    }

    res.json({ url: `/uploads/contracts/${baseName}.docx`, format: 'docx' });
  } catch (err) {
    console.error('Contract generation error:', err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
