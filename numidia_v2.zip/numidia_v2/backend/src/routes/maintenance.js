const { maintenanceRouter } = require('./other');
module.exports = maintenanceRouter;
