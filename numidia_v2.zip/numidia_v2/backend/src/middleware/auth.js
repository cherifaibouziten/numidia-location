/**
 * Middlewares d'authentification & d'autorisation (RBAC).
 */
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { hasPermission } = require('../utils/permissions');

// Vérifie le JWT et charge l'utilisateur
exports.protect = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.startsWith('Bearer ')
      ? req.headers.authorization.split(' ')[1]
      : null;
    if (!token) return res.status(401).json({ message: 'Non autorisé - Token manquant' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-motDePasse');
    if (!user) return res.status(401).json({ message: 'Utilisateur introuvable' });
    if (user.statut === 'suspendu') return res.status(403).json({ message: 'Compte suspendu' });

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Token invalide ou expiré' });
  }
};

// Restreint à une liste de rôles
exports.requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ message: 'Accès non autorisé pour votre rôle' });
  }
  next();
};

// Admin principal OU admin
exports.requireAdmin = (req, res, next) => {
  if (!req.user || !['admin_principal', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ message: 'Accès réservé aux administrateurs' });
  }
  next();
};

// Personnel de l'agence : admin principal, admin, employé
exports.requireStaff = (req, res, next) => {
  if (!req.user || !['admin_principal', 'admin', 'employe'].includes(req.user.role)) {
    return res.status(403).json({ message: 'Accès réservé au personnel de l\'agence' });
  }
  next();
};

// Exige une permission précise
exports.requirePermission = (perm) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ message: 'Non autorisé' });
  if (hasPermission(req.user, perm)) return next();
  return res.status(403).json({ message: 'Permission insuffisante' });
};

// Email vérifié obligatoire
exports.requireVerified = (req, res, next) => {
  if (!req.user.isVerified) {
    return res.status(403).json({ message: 'Veuillez vérifier votre email avant de continuer' });
  }
  next();
};

// Compte actif obligatoire
exports.requireActive = (req, res, next) => {
  if (req.user.statut !== 'actif') {
    return res.status(403).json({ message: 'Compte non actif' });
  }
  next();
};
