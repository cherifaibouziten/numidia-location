require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./src/models/User');
const Vehicule = require('./src/models/Vehicule');
const { DEFAULT_PERMISSIONS } = require('./src/utils/permissions');

async function seed() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Connected to MongoDB');

  // Administrateur principal (créé manuellement, jamais via inscription)
  const existing = await User.findOne({ email: 'admin@numidia.dz' });
  if (!existing) {
    await User.create({
      nom: 'Administrateur', prenom: 'Principal',
      email: 'admin@numidia.dz',
      motDePasse: 'numidia2025',
      role: 'admin_principal',
      permissions: DEFAULT_PERMISSIONS.admin_principal,
      isVerified: true,
      statut: 'actif',
      telephone: '+213550000000',
    });
    console.log('Admin principal créé : admin@numidia.dz / numidia2025');
  } else {
    // S'assurer que le compte existant est bien admin_principal
    existing.role = 'admin_principal';
    existing.permissions = DEFAULT_PERMISSIONS.admin_principal;
    existing.isVerified = true;
    existing.statut = 'actif';
    await existing.save();
    console.log('Admin principal déjà présent (mis à jour).');
  }

  // Véhicules d'exemple
  const vCount = await Vehicule.countDocuments();
  if (vCount === 0) {
    await Vehicule.insertMany([
      { marque: 'Dacia', modele: 'Logan', immatriculation: '1234-06-A', annee: 2022, couleur: 'Blanc', categorie: 'Citadine', carburant: 'Essence', prixParJour: 3500, statut: 'disponible', kilometrage: 45000 },
      { marque: 'Hyundai', modele: 'Tucson', immatriculation: '5678-06-B', annee: 2023, couleur: 'Gris', categorie: 'SUV', carburant: 'Diesel', prixParJour: 7000, statut: 'disponible', kilometrage: 20000 },
      { marque: 'Toyota', modele: 'Corolla', immatriculation: '9012-16-C', annee: 2021, couleur: 'Noir', categorie: 'Berline', carburant: 'Essence', prixParJour: 5000, statut: 'disponible', kilometrage: 70000 },
    ]);
    console.log('Véhicules d\'exemple créés');
  }

  await mongoose.disconnect();
  console.log('Seed terminé !');
}

seed().catch(console.error);
