import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../context/AuthContext';
import { colors, shadow } from '../services/theme';
import {
  HomeIcon, CarIcon, CalendarIcon, UsersIcon,
  BarChartIcon, SettingsIcon, BellIcon, WrenchIcon
} from '../components/Icons';

// Auth screens
import WelcomeScreen from '../screens/auth/WelcomeScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';
import VerifyEmailScreen from '../screens/auth/VerifyEmailScreen';
import ForgotPasswordScreen from '../screens/auth/ForgotPasswordScreen';

// Main screens
import DashboardScreen from '../screens/dashboard/DashboardScreen';
import VehiclesScreen from '../screens/vehicles/VehiclesScreen';
import VehicleDetailScreen from '../screens/vehicles/VehicleDetailScreen';
import VehicleFormScreen from '../screens/vehicles/VehicleFormScreen';
import ReservationsScreen from '../screens/reservations/ReservationsScreen';
import ReservationFormScreen from '../screens/reservations/ReservationFormScreen';
import ReservationDetailScreen from '../screens/reservations/ReservationDetailScreen';
import ContractScreen from '../screens/contract/ContractScreen';
import ClientsScreen from '../screens/clients/ClientsScreen';
import ClientFormScreen from '../screens/clients/ClientFormScreen';
import StatsScreen from '../screens/stats/StatsScreen';
import MaintenanceScreen from '../screens/maintenance/MaintenanceScreen';
import NotificationsScreen from '../screens/notifications/NotificationsScreen';
import SettingsScreen from '../screens/settings/SettingsScreen';
import ProfileScreen from '../screens/settings/ProfileScreen';
import AdminUsersScreen from '../screens/settings/AdminUsersScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function TabIcon({ Icon, focused, color }) {
  return (
    <View style={[styles.tabIcon, focused && { backgroundColor: colors.primaryLight }]}>
      <Icon size={22} color={color} />
    </View>
  );
}

function MainTabs() {
  const { isAdmin, isStaff, isClient } = useAuth();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarLabelStyle: styles.tabLabel,
        tabBarActiveTintColor: colors.tabActive,
        tabBarInactiveTintColor: colors.tabInactive,
      })}
    >
      {/* Tableau de bord exécutif : admins uniquement */}
      {isAdmin && (
        <Tab.Screen name="Dashboard" component={DashboardScreen}
          options={{ tabBarLabel: 'Accueil', tabBarIcon: ({ focused, color }) => <TabIcon Icon={HomeIcon} focused={focused} color={color} /> }}
        />
      )}
      {/* Catalogue véhicules : tous les rôles */}
      <Tab.Screen name="Véhicules" component={VehiclesScreen}
        options={{ tabBarIcon: ({ focused, color }) => <TabIcon Icon={CarIcon} focused={focused} color={color} /> }}
      />
      {/* Réservations & clients : personnel (admin + employé) */}
      {isStaff && (
        <Tab.Screen name="Réservations" component={ReservationsScreen}
          options={{ tabBarIcon: ({ focused, color }) => <TabIcon Icon={CalendarIcon} focused={focused} color={color} /> }}
        />
      )}
      {isStaff && (
        <Tab.Screen name="Clients" component={ClientsScreen}
          options={{ tabBarIcon: ({ focused, color }) => <TabIcon Icon={UsersIcon} focused={focused} color={color} /> }}
        />
      )}
      {/* Statistiques : admins uniquement */}
      {isAdmin && (
        <Tab.Screen name="Statistiques" component={StatsScreen}
          options={{ tabBarIcon: ({ focused, color }) => <TabIcon Icon={BarChartIcon} focused={focused} color={color} /> }}
        />
      )}
      <Tab.Screen name="Paramètres" component={SettingsScreen}
        options={{ tabBarIcon: ({ focused, color }) => <TabIcon Icon={SettingsIcon} focused={focused} color={color} /> }}
      />
    </Tab.Navigator>
  );
}

function AppStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MainTabs" component={MainTabs} />
      <Stack.Screen name="VehicleDetail" component={VehicleDetailScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="VehicleForm" component={VehicleFormScreen} options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="ReservationForm" component={ReservationFormScreen} options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="ReservationDetail" component={ReservationDetailScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="Contract" component={ContractScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="ClientForm" component={ClientFormScreen} options={{ animation: 'slide_from_bottom' }} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="Maintenance" component={MaintenanceScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="Profile" component={ProfileScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="AdminUsers" component={AdminUsersScreen} options={{ animation: 'slide_from_right' }} />
    </Stack.Navigator>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
      <Stack.Screen name="Login" component={LoginScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="Register" component={RegisterScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="VerifyEmail" component={VerifyEmailScreen} options={{ animation: 'slide_from_right' }} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} options={{ animation: 'slide_from_right' }} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <View style={styles.splash}>
        <Text style={styles.splashText}>NUMIDIA</Text>
        <Text style={styles.splashSub}>Cars & Immo</Text>
      </View>
    );
  }
  return (
    <NavigationContainer>
      {user ? <AppStack /> : <AuthStack />}
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: colors.tabBar,
    borderTopColor: colors.border,
    borderTopWidth: 1,
    height: 72,
    paddingBottom: 12,
    paddingTop: 8,
    ...shadow.sm,
  },
  tabLabel: { fontSize: 10, fontWeight: '600', letterSpacing: 0.2 },
  tabIcon: {
    width: 40, height: 32, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
  },
  splash: {
    flex: 1, backgroundColor: colors.white,
    alignItems: 'center', justifyContent: 'center',
  },
  splashText: { fontSize: 36, fontWeight: '800', color: colors.primary, letterSpacing: -1 },
  splashSub: { fontSize: 14, color: colors.textSub, marginTop: 4, letterSpacing: 2 },
});
