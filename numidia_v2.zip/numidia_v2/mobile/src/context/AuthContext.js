import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadUser = useCallback(async () => {
    try {
      const token = await AsyncStorage.getItem('numidia_token');
      if (token) {
        const me = await api.get('/auth/me');
        setUser(me);
      }
    } catch {
      await AsyncStorage.removeItem('numidia_token');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadUser(); }, [loadUser]);

  const login = async (email, motDePasse) => {
    const data = await api.post('/auth/login', { email, motDePasse });
    await AsyncStorage.setItem('numidia_token', data.token);
    setUser(data.user);
    return data.user;
  };

  const register = async (fields) => {
    return api.post('/auth/register', fields);
  };

  const logout = async () => {
    try { await api.post('/auth/logout', {}); } catch {}
    await AsyncStorage.removeItem('numidia_token');
    setUser(null);
  };

  const refreshUser = async () => {
    try {
      const me = await api.get('/auth/me');
      setUser(me);
    } catch {}
  };

  // ─── Rôles & permissions ───────────────────────────────
  const role = user?.role;
  const isAdminPrincipal = role === 'admin_principal';
  const isAdmin = role === 'admin' || role === 'admin_principal';
  const isStaff = isAdmin || role === 'employe';
  const isEmploye = role === 'employe';
  const isClient = role === 'client';
  const isVerified = user?.isVerified === true;
  const hasPermission = (perm) =>
    isAdminPrincipal || (Array.isArray(user?.permissions) && user.permissions.includes(perm));

  return (
    <AuthContext.Provider value={{
      user, loading, login, register, logout, refreshUser,
      role, isAdminPrincipal, isAdmin, isStaff, isEmploye, isClient,
      isVerified, hasPermission,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
