import React, { createContext, useContext, useState, useRef, useCallback } from 'react';
import { View, Text, StyleSheet, Animated, TouchableOpacity } from 'react-native';
import { colors, shadow, radius } from '../services/theme';
import { CheckCircleIcon, XCircleIcon, InfoIcon, AlertTriangleIcon } from '../components/Icons';
import { haptics } from '../utils/haptics';

const ToastContext = createContext(null);

const ICONS = {
  success: <CheckCircleIcon size={18} color={colors.success} />,
  error: <XCircleIcon size={18} color={colors.danger} />,
  info: <InfoIcon size={18} color={colors.primary} />,
  warning: <AlertTriangleIcon size={18} color={colors.warning} />,
};

const COLORS = {
  success: { bg: colors.successLight, border: colors.successBorder, text: '#065F46' },
  error: { bg: colors.dangerLight, border: colors.dangerBorder, text: '#991B1B' },
  info: { bg: colors.primaryLight, border: colors.primaryMid, text: '#1E40AF' },
  warning: { bg: colors.warningLight, border: colors.warningBorder, text: '#92400E' },
};

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const show = useCallback((message, type = 'info', duration = 3000) => {
    const id = Date.now();
    // Haptic feedback matched to toast type
    if (type === 'success') haptics.success();
    else if (type === 'error') haptics.error();
    else if (type === 'warning') haptics.warning();
    else haptics.light();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, duration);
  }, []);

  const hide = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ show }}>
      {children}
      <View style={styles.container} pointerEvents="box-none">
        {toasts.map(toast => (
          <ToastItem key={toast.id} toast={toast} onClose={() => hide(toast.id)} />
        ))}
      </View>
    </ToastContext.Provider>
  );
}

function ToastItem({ toast, onClose }) {
  const anim = useRef(new Animated.Value(0)).current;
  const c = COLORS[toast.type] || COLORS.info;

  React.useEffect(() => {
    Animated.spring(anim, { toValue: 1, useNativeDriver: true, tension: 80, friction: 8 }).start();
  }, []);

  return (
    <Animated.View style={[
      styles.toast,
      { backgroundColor: c.bg, borderColor: c.border },
      shadow.md,
      { opacity: anim, transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [-20, 0] }) }] }
    ]}>
      {ICONS[toast.type]}
      <Text style={[styles.msg, { color: c.text }]} numberOfLines={2}>{toast.message}</Text>
      <TouchableOpacity onPress={onClose} style={styles.close}>
        <Text style={{ color: c.text, fontSize: 14 }}>✕</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: { position: 'absolute', top: 56, left: 16, right: 16, zIndex: 9999 },
  toast: {
    flexDirection: 'row', alignItems: 'center', padding: 12,
    borderRadius: radius.md, borderWidth: 1, marginBottom: 8, gap: 10,
  },
  msg: { flex: 1, fontSize: 14, fontWeight: '500' },
  close: { padding: 2 },
});

export const useToast = () => {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
};
