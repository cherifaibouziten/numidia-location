/**
 * DatePicker — calendar modal UI, outputs DD/MM/YYYY.
 * No free text entry; user taps a day on the calendar grid.
 */
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Modal, Pressable
} from 'react-native';
import { colors, radius, spacing, typography, shadow } from '../services/theme';
import { CalendarIcon, ChevronLeftIcon, ChevronRightIcon } from './Icons';

const MOIS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const JOURS = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];

export function formatDate(date) {
  if (!date) return '';
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  return `${day}/${month}/${d.getFullYear()}`;
}

export function DatePicker({ label, value, onChange, minDate, required, error }) {
  const [open, setOpen] = useState(false);
  const [viewDate, setViewDate] = useState(value ? new Date(value) : new Date());

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();

  // First day offset (Monday-based)
  const firstDay = new Date(year, month, 1).getDay();
  const offset = firstDay === 0 ? 6 : firstDay - 1;
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const days = [];
  for (let i = 0; i < offset; i++) days.push(null);
  for (let d = 1; d <= daysInMonth; d++) days.push(d);

  const selectedDate = value ? new Date(value) : null;
  const isSameDay = (d) => selectedDate && d === selectedDate.getDate() && month === selectedDate.getMonth() && year === selectedDate.getFullYear();
  const isDisabled = (d) => {
    if (!minDate) return false;
    const dt = new Date(year, month, d);
    return dt < new Date(new Date(minDate).setHours(0, 0, 0, 0));
  };

  const selectDay = (d) => {
    if (isDisabled(d)) return;
    onChange(new Date(year, month, d));
    setOpen(false);
  };

  const prevMonth = () => setViewDate(new Date(year, month - 1, 1));
  const nextMonth = () => setViewDate(new Date(year, month + 1, 1));

  return (
    <View style={{ marginBottom: 16 }}>
      {label && (
        <View style={{ flexDirection: 'row', marginBottom: 6 }}>
          <Text style={{ fontSize: 13, fontWeight: '600', color: colors.textSub }}>{label}</Text>
          {required && <Text style={{ color: colors.danger, marginLeft: 2 }}>*</Text>}
        </View>
      )}
      <TouchableOpacity
        onPress={() => setOpen(true)}
        style={[styles.field, error && { borderColor: colors.danger }]}
        activeOpacity={0.7}
      >
        <CalendarIcon size={18} color={colors.textMuted} />
        <Text style={[styles.fieldText, { color: value ? colors.text : colors.textDisabled }]}>
          {value ? formatDate(value) : 'JJ/MM/AAAA'}
        </Text>
      </TouchableOpacity>
      {error && <Text style={{ color: colors.danger, fontSize: 12, marginTop: 4 }}>{error}</Text>}

      <Modal transparent visible={open} animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.overlay} onPress={() => setOpen(false)}>
          <Pressable style={styles.calendar} onPress={() => {}}>
            {/* Month navigation */}
            <View style={styles.calHeader}>
              <TouchableOpacity onPress={prevMonth} style={styles.navBtn}>
                <ChevronLeftIcon size={20} color={colors.text} />
              </TouchableOpacity>
              <Text style={typography.h4}>{MOIS[month]} {year}</Text>
              <TouchableOpacity onPress={nextMonth} style={styles.navBtn}>
                <ChevronRightIcon size={20} color={colors.text} />
              </TouchableOpacity>
            </View>

            {/* Weekday labels */}
            <View style={styles.weekRow}>
              {JOURS.map((j, i) => (
                <View key={i} style={styles.dayCell}>
                  <Text style={styles.weekLabel}>{j}</Text>
                </View>
              ))}
            </View>

            {/* Days grid */}
            <View style={styles.grid}>
              {days.map((d, i) => (
                <TouchableOpacity
                  key={i}
                  style={styles.dayCell}
                  disabled={!d || isDisabled(d)}
                  onPress={() => d && selectDay(d)}
                  activeOpacity={0.6}
                >
                  {d && (
                    <View style={[
                      styles.dayInner,
                      isSameDay(d) && { backgroundColor: colors.primary },
                    ]}>
                      <Text style={[
                        styles.dayText,
                        isSameDay(d) && { color: '#fff', fontWeight: '700' },
                        isDisabled(d) && { color: colors.textDisabled },
                      ]}>{d}</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={styles.todayBtn} onPress={() => { setViewDate(new Date()); }}>
              <Text style={{ color: colors.primary, fontWeight: '600' }}>Aujourd'hui</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  field: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    height: 48, backgroundColor: colors.white,
    borderWidth: 1.5, borderColor: colors.border, borderRadius: radius.md,
    paddingHorizontal: 14,
  },
  fieldText: { fontSize: 15 },
  overlay: { flex: 1, backgroundColor: 'rgba(15,23,42,0.5)', alignItems: 'center', justifyContent: 'center' },
  calendar: {
    backgroundColor: colors.white, borderRadius: radius.xl,
    padding: spacing.lg, width: '88%', ...shadow.lg,
  },
  calHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  navBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.bgSecondary, alignItems: 'center', justifyContent: 'center' },
  weekRow: { flexDirection: 'row', marginBottom: 8 },
  weekLabel: { fontSize: 12, color: colors.textMuted, fontWeight: '600' },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  dayCell: { width: `${100 / 7}%`, aspectRatio: 1, alignItems: 'center', justifyContent: 'center' },
  dayInner: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  dayText: { fontSize: 14, color: colors.text },
  todayBtn: { alignItems: 'center', marginTop: 12, padding: 8 },
});
