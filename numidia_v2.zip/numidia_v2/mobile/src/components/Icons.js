/**
 * NUMIDIA v2 — Clean SVG Icons
 * All icons use Lucide-style design (24px grid, 2px stroke)
 */
import React from 'react';
import Svg, { Path, Circle, Rect, Line, Polyline, Polygon } from 'react-native-svg';

const icon = (paths, viewBox = '0 0 24 24') => ({ size = 24, color = '#0F172A', style }) => (
  <Svg width={size} height={size} viewBox={viewBox} fill="none"
    stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {paths}
  </Svg>
);

export const HomeIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
    <Polyline points="9 22 9 12 15 12 15 22"/>
  </Svg>
);

export const CarIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v9a2 2 0 01-2 2h-2"/>
    <Circle cx="7" cy="17" r="2"/><Circle cx="17" cy="17" r="2"/>
    <Path d="M9 17h6"/>
  </Svg>
);

export const CalendarIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
    <Line x1="16" y1="2" x2="16" y2="6"/><Line x1="8" y1="2" x2="8" y2="6"/>
    <Line x1="3" y1="10" x2="21" y2="10"/>
  </Svg>
);

export const UsersIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
    <Circle cx="9" cy="7" r="4"/>
    <Path d="M23 21v-2a4 4 0 00-3-3.87"/><Path d="M16 3.13a4 4 0 010 7.75"/>
  </Svg>
);

export const BarChartIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Line x1="18" y1="20" x2="18" y2="10"/>
    <Line x1="12" y1="20" x2="12" y2="4"/>
    <Line x1="6" y1="20" x2="6" y2="14"/>
    <Line x1="2" y1="20" x2="22" y2="20"/>
  </Svg>
);

export const SettingsIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Circle cx="12" cy="12" r="3"/>
    <Path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>
  </Svg>
);

export const BellIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><Path d="M13.73 21a2 2 0 01-3.46 0"/>
  </Svg>
);

export const PlusIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Line x1="12" y1="5" x2="12" y2="19"/><Line x1="5" y1="12" x2="19" y2="12"/>
  </Svg>
);

export const SearchIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Circle cx="11" cy="11" r="8"/><Line x1="21" y1="21" x2="16.65" y2="16.65"/>
  </Svg>
);

export const FilterIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
  </Svg>
);

export const EditIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
    <Path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
  </Svg>
);

export const TrashIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Polyline points="3 6 5 6 21 6"/><Path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
    <Path d="M10 11v6"/><Path d="M14 11v6"/>
    <Path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
  </Svg>
);

export const ChevronRightIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Polyline points="9 18 15 12 9 6"/>
  </Svg>
);

export const ChevronLeftIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Polyline points="15 18 9 12 15 6"/>
  </Svg>
);

export const CheckCircleIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
    <Polyline points="22 4 12 14.01 9 11.01"/>
  </Svg>
);

export const XCircleIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Circle cx="12" cy="12" r="10"/>
    <Line x1="15" y1="9" x2="9" y2="15"/><Line x1="9" y1="9" x2="15" y2="15"/>
  </Svg>
);

export const InfoIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Circle cx="12" cy="12" r="10"/>
    <Line x1="12" y1="8" x2="12" y2="12"/><Line x1="12" y1="16" x2="12.01" y2="16"/>
  </Svg>
);

export const AlertTriangleIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
    <Line x1="12" y1="9" x2="12" y2="13"/><Line x1="12" y1="17" x2="12.01" y2="17"/>
  </Svg>
);

export const LogOutIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
    <Polyline points="16 17 21 12 16 7"/><Line x1="21" y1="12" x2="9" y2="12"/>
  </Svg>
);

export const MailIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
    <Polyline points="22 6 12 13 2 6"/>
  </Svg>
);

export const LockIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
    <Path d="M7 11V7a5 5 0 0110 0v4"/>
  </Svg>
);

export const EyeIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
    <Circle cx="12" cy="12" r="3"/>
  </Svg>
);

export const EyeOffIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/>
    <Line x1="1" y1="1" x2="23" y2="23"/>
  </Svg>
);

export const CameraIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/>
    <Circle cx="12" cy="13" r="4"/>
  </Svg>
);

export const FileTextIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
    <Polyline points="14 2 14 8 20 8"/>
    <Line x1="16" y1="13" x2="8" y2="13"/><Line x1="16" y1="17" x2="8" y2="17"/>
    <Polyline points="10 9 9 9 8 9"/>
  </Svg>
);

export const WrenchIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/>
  </Svg>
);

export const UserIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
    <Circle cx="12" cy="7" r="4"/>
  </Svg>
);

export const ShieldIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  </Svg>
);

export const DownloadIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
    <Polyline points="7 10 12 15 17 10"/><Line x1="12" y1="15" x2="12" y2="3"/>
  </Svg>
);

export const PrinterIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Polyline points="6 9 6 2 18 2 18 9"/>
    <Path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
    <Rect x="6" y="14" width="12" height="8"/>
  </Svg>
);

export const XIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Line x1="18" y1="6" x2="6" y2="18"/><Line x1="6" y1="6" x2="18" y2="18"/>
  </Svg>
);

export const PhoneIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.1 11a19.79 19.79 0 01-3.07-8.67A2 2 0 012.18 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.16 6.16l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
  </Svg>
);

export const MapPinIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
    <Circle cx="12" cy="10" r="3"/>
  </Svg>
);

export const StarIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
  </Svg>
);

export const ClockIcon = ({ size, color, style }) => (
  <Svg width={size||24} height={size||24} viewBox="0 0 24 24" fill="none" stroke={color||'#0F172A'} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={style}>
    <Circle cx="12" cy="12" r="10"/>
    <Polyline points="12 6 12 12 16 14"/>
  </Svg>
);
