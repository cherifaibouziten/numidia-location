import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ActivityIndicator, Modal, Animated, ScrollView, Pressable, Platform
} from 'react-native';
import { colors, shadow, radius, spacing, typography } from '../services/theme';
import { haptics } from '../utils/haptics';

// ─── Button ──────────────────────────────────────────────────────────────────
export function Button({ title, onPress, variant = 'primary', size = 'md', icon, loading, disabled, style, haptic = true }) {
  const variants = {
    primary: { bg: colors.primary, text: '#fff', border: colors.primary },
    secondary: { bg: colors.bgSecondary, text: colors.text, border: colors.border },
    danger: { bg: colors.danger, text: '#fff', border: colors.danger },
    ghost: { bg: 'transparent', text: colors.primary, border: 'transparent' },
    outline: { bg: 'transparent', text: colors.primary, border: colors.primary },
  };
  const sizes = { sm: { h: 36, px: 14, fs: 13 }, md: { h: 46, px: 20, fs: 15 }, lg: { h: 54, px: 24, fs: 16 } };
  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;

  const handlePress = () => {
    if (haptic) haptics.light();
    onPress?.();
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      disabled={disabled || loading}
      activeOpacity={0.75}
      style={[{
        height: s.h, paddingHorizontal: s.px,
        backgroundColor: disabled ? colors.bgSecondary : v.bg,
        borderColor: disabled ? colors.border : v.border,
        borderWidth: 1, borderRadius: radius.md,
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
        opacity: disabled ? 0.6 : 1,
      }, variant === 'primary' && !disabled && shadow.sm, style]}
    >
      {loading ? <ActivityIndicator size="small" color={v.text} />
        : <>
          {icon}
          <Text style={{ color: disabled ? colors.textMuted : v.text, fontSize: s.fs, fontWeight: '600' }}>
            {title}
          </Text>
        </>
      }
    </TouchableOpacity>
  );
}

// ─── Input ───────────────────────────────────────────────────────────────────
export function Input({
  label, placeholder, value, onChangeText, error,
  secureTextEntry, keyboardType, multiline, numberOfLines = 1,
  leftIcon, rightElement, editable = true, style, inputStyle,
  required, hint
}) {
  const [focused, setFocused] = useState(false);
  const [showSecure, setShowSecure] = useState(false);

  return (
    <View style={[{ marginBottom: 16 }, style]}>
      {label && (
        <View style={{ flexDirection: 'row', marginBottom: 6 }}>
          <Text style={{ fontSize: 13, fontWeight: '600', color: colors.textSub }}>
            {label}
          </Text>
          {required && <Text style={{ color: colors.danger, marginLeft: 2 }}>*</Text>}
        </View>
      )}
      <View style={{
        flexDirection: 'row', alignItems: multiline ? 'flex-start' : 'center',
        backgroundColor: editable ? colors.white : colors.bgSecondary,
        borderWidth: 1.5,
        borderColor: error ? colors.danger : focused ? colors.primary : colors.border,
        borderRadius: radius.md, paddingHorizontal: 14,
        minHeight: multiline ? 80 : 48,
        ...(focused && !error ? { ...shadow.sm } : {}),
      }}>
        {leftIcon && <View style={{ marginRight: 10, marginTop: multiline ? 14 : 0 }}>{leftIcon}</View>}
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.textDisabled}
          secureTextEntry={secureTextEntry && !showSecure}
          keyboardType={keyboardType}
          multiline={multiline}
          numberOfLines={multiline ? numberOfLines : 1}
          editable={editable}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={[{
            flex: 1,
            fontSize: 15,
            color: editable ? colors.text : colors.textSub,
            paddingVertical: multiline ? 12 : 0,
            textAlignVertical: multiline ? 'top' : 'center',
          }, inputStyle]}
        />
        {secureTextEntry && (
          <TouchableOpacity onPress={() => setShowSecure(p => !p)} style={{ padding: 4 }}>
            <Text style={{ color: colors.textMuted, fontSize: 13 }}>{showSecure ? 'Masquer' : 'Voir'}</Text>
          </TouchableOpacity>
        )}
        {rightElement}
      </View>
      {error && <Text style={{ color: colors.danger, fontSize: 12, marginTop: 4 }}>{error}</Text>}
      {hint && !error && <Text style={{ color: colors.textMuted, fontSize: 12, marginTop: 4 }}>{hint}</Text>}
    </View>
  );
}

// ─── Card ────────────────────────────────────────────────────────────────────
export function Card({ children, style, onPress, padding = true }) {
  const content = (
    <View style={[styles.card, padding && { padding: spacing.lg }, style]}>
      {children}
    </View>
  );
  if (onPress) return <TouchableOpacity onPress={onPress} activeOpacity={0.85}>{content}</TouchableOpacity>;
  return content;
}

// ─── StatusBadge ─────────────────────────────────────────────────────────────
export function StatusBadge({ status, config }) {
  const s = config?.[status];
  if (!s) return null;
  return (
    <View style={{ backgroundColor: s.bg, borderColor: s.border, borderWidth: 1, borderRadius: radius.full, paddingHorizontal: 10, paddingVertical: 4 }}>
      <Text style={{ color: s.color, fontSize: 12, fontWeight: '600' }}>{s.label}</Text>
    </View>
  );
}

// ─── Avatar ──────────────────────────────────────────────────────────────────
export function Avatar({ name, size = 44, uri, style }) {
  const initials = name?.split(' ').map(p => p[0]).join('').slice(0, 2).toUpperCase() || 'NU';
  const bg = ['#DBEAFE', '#EDE9FE', '#DCFCE7', '#FEF3C7', '#FCE7F3'];
  const tc = ['#1D4ED8', '#6D28D9', '#15803D', '#B45309', '#BE185D'];
  const idx = name ? name.charCodeAt(0) % 5 : 0;
  return (
    <View style={[{ width: size, height: size, borderRadius: size / 2, backgroundColor: bg[idx], alignItems: 'center', justifyContent: 'center' }, style]}>
      <Text style={{ color: tc[idx], fontSize: size * 0.35, fontWeight: '700' }}>{initials}</Text>
    </View>
  );
}

// ─── SkeletonLoader ───────────────────────────────────────────────────────────
export function Skeleton({ width, height = 16, borderRadius = 8, style }) {
  const anim = useRef(new Animated.Value(0.4)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(anim, { toValue: 1, duration: 800, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0.4, duration: 800, useNativeDriver: true }),
      ])
    ).start();
  }, []);
  return (
    <Animated.View style={[{
      width, height, borderRadius, backgroundColor: colors.bgSecondary, opacity: anim,
    }, style]} />
  );
}

export function SkeletonCard() {
  return (
    <Card style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <Skeleton width={64} height={64} borderRadius={12} />
        <View style={{ flex: 1, gap: 8 }}>
          <Skeleton width="60%" height={16} />
          <Skeleton width="40%" height={12} />
          <Skeleton width="80%" height={12} />
        </View>
      </View>
    </Card>
  );
}

// ─── ConfirmModal ─────────────────────────────────────────────────────────────
export function ConfirmModal({ visible, title, message, confirmText = 'Confirmer', cancelText = 'Annuler', onConfirm, onCancel, danger = false }) {
  return (
    <Modal transparent visible={visible} animationType="fade" onRequestClose={onCancel}>
      <View style={styles.overlay}>
        <View style={styles.confirmBox}>
          <Text style={[typography.h4, { marginBottom: 8 }]}>{title}</Text>
          <Text style={[typography.body, { color: colors.textSub, marginBottom: 24 }]}>{message}</Text>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Button title={cancelText} onPress={onCancel} variant="secondary" style={{ flex: 1 }} />
            <Button title={confirmText} onPress={onConfirm} variant={danger ? 'danger' : 'primary'} style={{ flex: 1 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ─── BottomSheet Modal ────────────────────────────────────────────────────────
export function SheetModal({ visible, onClose, title, children, snapHeight = '75%' }) {
  return (
    <Modal transparent visible={visible} animationType="slide" onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable style={[styles.sheet, { maxHeight: snapHeight }]} onPress={() => {}}>
          <View style={styles.sheetHandle} />
          <View style={styles.sheetHeader}>
            <Text style={typography.h4}>{title}</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Text style={{ fontSize: 20, color: colors.textMuted }}>✕</Text>
            </TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            {children}
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// ─── EmptyState ───────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, subtitle, action }) {
  return (
    <View style={styles.empty}>
      <View style={styles.emptyIcon}>{icon}</View>
      <Text style={[typography.h4, { textAlign: 'center', marginTop: 16 }]}>{title}</Text>
      {subtitle && <Text style={[typography.body, { color: colors.textSub, textAlign: 'center', marginTop: 6 }]}>{subtitle}</Text>}
      {action && <View style={{ marginTop: 20 }}>{action}</View>}
    </View>
  );
}

// ─── SectionHeader ────────────────────────────────────────────────────────────
export function SectionHeader({ title, action, actionLabel }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
      <Text style={typography.h4}>{title}</Text>
      {action && (
        <TouchableOpacity onPress={action}>
          <Text style={{ color: colors.primary, fontSize: 13, fontWeight: '600' }}>{actionLabel || 'Voir tout'}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// ─── SelectField ─────────────────────────────────────────────────────────────
export function SelectField({ label, value, options, onChange, style }) {
  const [open, setOpen] = useState(false);
  const selected = options?.find(o => o.value === value);
  return (
    <View style={[{ marginBottom: 16 }, style]}>
      {label && <Text style={{ fontSize: 13, fontWeight: '600', color: colors.textSub, marginBottom: 6 }}>{label}</Text>}
      <TouchableOpacity
        onPress={() => setOpen(true)}
        style={{ height: 48, backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.border, borderRadius: radius.md, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
      >
        <Text style={{ color: selected ? colors.text : colors.textDisabled, fontSize: 15 }}>
          {selected?.label || 'Sélectionner...'}
        </Text>
        <Text style={{ color: colors.textMuted }}>▾</Text>
      </TouchableOpacity>
      <Modal transparent visible={open} animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.overlay} onPress={() => setOpen(false)}>
          <View style={styles.selectBox}>
            <Text style={[typography.h4, { marginBottom: 12 }]}>{label}</Text>
            {options?.map(opt => (
              <TouchableOpacity
                key={opt.value}
                onPress={() => { onChange(opt.value); setOpen(false); }}
                style={[styles.selectOption, opt.value === value && { backgroundColor: colors.primaryLight }]}
              >
                <Text style={{ color: opt.value === value ? colors.primary : colors.text, fontWeight: opt.value === value ? '600' : '400', fontSize: 15 }}>
                  {opt.label}
                </Text>
                {opt.value === value && <Text style={{ color: colors.primary }}>✓</Text>}
              </TouchableOpacity>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

// ─── Divider ─────────────────────────────────────────────────────────────────
export function Divider({ style }) {
  return <View style={[{ height: 1, backgroundColor: colors.border, marginVertical: 12 }, style]} />;
}

// ─── InfoRow ─────────────────────────────────────────────────────────────────
export function InfoRow({ label, value, icon }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-start', paddingVertical: 8, gap: 12 }}>
      {icon && <View style={{ width: 20, alignItems: 'center', marginTop: 1 }}>{icon}</View>}
      <Text style={{ fontSize: 13, color: colors.textSub, width: 110 }}>{label}</Text>
      <Text style={{ flex: 1, fontSize: 14, color: colors.text, fontWeight: '500' }}>{value || '—'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.bgCard,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadow.sm,
  },
  overlay: {
    flex: 1, backgroundColor: 'rgba(15,23,42,0.5)',
    justifyContent: 'flex-end',
  },
  confirmBox: {
    backgroundColor: colors.white, borderRadius: radius.xl,
    padding: spacing.xl, margin: spacing.xl,
    ...shadow.lg,
  },
  sheet: {
    backgroundColor: colors.white,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    paddingHorizontal: spacing.xl, paddingBottom: 40,
    ...shadow.lg,
  },
  sheetHandle: {
    width: 40, height: 4, borderRadius: 2,
    backgroundColor: colors.border, alignSelf: 'center', marginTop: 12, marginBottom: 8,
  },
  sheetHeader: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: colors.border, marginBottom: 16,
  },
  closeBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  empty: {
    alignItems: 'center', padding: spacing.xxl, paddingTop: 48,
  },
  emptyIcon: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: colors.bgSecondary,
    alignItems: 'center', justifyContent: 'center',
  },
  selectBox: {
    backgroundColor: colors.white, margin: spacing.xl,
    borderRadius: radius.xl, padding: spacing.xl, ...shadow.lg,
  },
  selectOption: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: 14, paddingHorizontal: 12, borderRadius: radius.md, marginBottom: 2,
  },
});
