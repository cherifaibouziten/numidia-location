import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography, shadow } from '../../services/theme';
import { Card, Skeleton, SectionHeader } from '../../components/UI';
import api from '../../services/api';

const { width } = Dimensions.get('window');

export default function StatsScreen() {
  const [stats, setStats] = useState(null);
  const [mensuel, setMensuel] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, m] = await Promise.all([api.get('/stats'), api.get('/finance/mensuel')]);
      setStats(s);
      setMensuel(Array.isArray(m) ? m : []);
    } catch (e) { console.warn(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const maxRev = mensuel.length ? Math.max(...mensuel.map(m => m.revenus), 1) : 1;
  const totalRevenue = mensuel.reduce((sum, m) => sum + m.revenus, 0);
  const totalReservations = mensuel.reduce((sum, m) => sum + m.reservations, 0);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <Text style={typography.h3}>Statistiques</Text>
      </View>
      <ScrollView contentContainerStyle={{ padding: spacing.lg }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}>

        {/* KPI cards */}
        <View style={styles.kpiGrid}>
          <KPI label="Revenus annuels" value={`${totalRevenue.toLocaleString()} DA`} color={colors.primary} loading={loading} />
          <KPI label="Réservations" value={totalReservations} color={colors.success} loading={loading} />
          <KPI label="Taux occupation" value={`${stats?.tauxOccupation || 0}%`} color={colors.purple} loading={loading} />
          <KPI label="Véhicules" value={stats?.totalVehicules || 0} color={colors.warning} loading={loading} />
        </View>

        {/* Revenue chart */}
        <SectionHeader title="Revenus par mois" />
        <Card style={{ marginBottom: 20 }}>
          {loading ? <Skeleton width="100%" height={160} /> : (
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 160, gap: 4 }}>
              {mensuel.map((m, i) => (
                <View key={i} style={{ flex: 1, alignItems: 'center' }}>
                  <Text style={{ fontSize: 8, color: colors.textMuted, marginBottom: 2 }}>
                    {m.revenus > 0 ? `${Math.round(m.revenus / 1000)}k` : ''}
                  </Text>
                  <View style={{
                    width: '70%', height: Math.max(2, (m.revenus / maxRev) * 120),
                    backgroundColor: i === new Date().getMonth() ? colors.primary : colors.primaryMid,
                    borderTopLeftRadius: 4, borderTopRightRadius: 4,
                  }} />
                  <Text style={{ fontSize: 9, color: colors.textMuted, marginTop: 4 }}>{m.mois}</Text>
                </View>
              ))}
            </View>
          )}
        </Card>

        {/* Reservations chart */}
        <SectionHeader title="Réservations par mois" />
        <Card style={{ marginBottom: 20 }}>
          {loading ? <Skeleton width="100%" height={120} /> : (
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 120, gap: 4 }}>
              {mensuel.map((m, i) => {
                const maxRes = Math.max(...mensuel.map(x => x.reservations), 1);
                return (
                  <View key={i} style={{ flex: 1, alignItems: 'center' }}>
                    <View style={{
                      width: '70%', height: Math.max(2, (m.reservations / maxRes) * 90),
                      backgroundColor: colors.success, borderTopLeftRadius: 4, borderTopRightRadius: 4,
                    }} />
                    <Text style={{ fontSize: 9, color: colors.textMuted, marginTop: 4 }}>{m.mois}</Text>
                  </View>
                );
              })}
            </View>
          )}
        </Card>

        {/* Fleet status */}
        <SectionHeader title="État de la flotte" />
        <Card style={{ marginBottom: 40 }}>
          {loading ? <Skeleton width="100%" height={100} /> : (
            <>
              <StatusBar label="Disponibles" value={stats?.disponibles || 0} total={stats?.totalVehicules || 1} color={colors.success} />
              <StatusBar label="Louées" value={stats?.louées || 0} total={stats?.totalVehicules || 1} color={colors.primary} />
              <StatusBar label="Maintenance" value={stats?.maintenance || 0} total={stats?.totalVehicules || 1} color={colors.warning} />
            </>
          )}
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function KPI({ label, value, color, loading }) {
  if (loading) return <Skeleton width={(width - 44) / 2} height={88} borderRadius={12} style={{ marginBottom: 12 }} />;
  return (
    <View style={[styles.kpi, { borderLeftColor: color }]}>
      <Text style={[styles.kpiValue, { color }]}>{value}</Text>
      <Text style={styles.kpiLabel}>{label}</Text>
    </View>
  );
}

function StatusBar({ label, value, total, color }) {
  const pct = total > 0 ? (value / total) * 100 : 0;
  return (
    <View style={{ marginBottom: 14 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
        <Text style={typography.bodySmall}>{label}</Text>
        <Text style={{ fontSize: 13, fontWeight: '600', color }}>{value}</Text>
      </View>
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${pct}%`, backgroundColor: color }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: spacing.lg, paddingVertical: 14,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  kpiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  kpi: {
    width: (width - 44) / 2, backgroundColor: colors.white,
    borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border,
    borderLeftWidth: 4, padding: 16, ...shadow.sm,
  },
  kpiValue: { fontSize: 20, fontWeight: '700' },
  kpiLabel: { fontSize: 12, color: colors.textSub, marginTop: 4 },
  track: { height: 8, backgroundColor: colors.bgSecondary, borderRadius: 4, overflow: 'hidden' },
  fill: { height: 8, borderRadius: 4 },
});
