import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, Dimensions
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, shadow, radius, spacing, typography } from '../../services/theme';
import { Card, SkeletonCard, Skeleton, SectionHeader, StatusBadge } from '../../components/UI';
import { STATUT_RES } from '../../services/theme';
import { BellIcon, CarIcon, CalendarIcon, UsersIcon, WrenchIcon } from '../../components/Icons';
import { useAuth } from '../../context/AuthContext';
import { Avatar } from '../../components/UI';
import api from '../../services/api';

const { width } = Dimensions.get('window');

function StatCard({ label, value, color, icon, sublabel }) {
  return (
    <View style={[statStyles.card, { borderLeftColor: color }]}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <View style={{ flex: 1 }}>
          <Text style={statStyles.value}>{value}</Text>
          <Text style={statStyles.label}>{label}</Text>
          {sublabel && <Text style={statStyles.sub}>{sublabel}</Text>}
        </View>
        <View style={[statStyles.iconWrap, { backgroundColor: color + '18' }]}>
          {icon}
        </View>
      </View>
    </View>
  );
}

export default function DashboardScreen({ navigation }) {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [reservations, setReservations] = useState([]);
  const [mensuel, setMensuel] = useState([]);
  const [notifCount, setNotifCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, r, m, n] = await Promise.all([
        api.get('/stats'),
        api.get('/reservations?statut=en_cours'),
        api.get('/finance/mensuel'),
        api.get('/notifications/count'),
      ]);
      setStats(s);
      setReservations(Array.isArray(r) ? r.slice(0, 5) : []);
      setMensuel(Array.isArray(m) ? m : []);
      setNotifCount(n.count || 0);
    } catch (e) {
      console.warn(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const maxRev = mensuel.length ? Math.max(...mensuel.map(m => m.revenus), 1) : 1;
  const fullName = `${user?.nom || ''} ${user?.prenom || ''}`.trim();

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.greeting}>Bonjour,</Text>
            <Text style={styles.name}>{user?.nom || 'Administrateur'}</Text>
          </View>
          <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
            <TouchableOpacity style={styles.notifBtn} onPress={() => navigation.navigate('Notifications')}>
              <BellIcon size={22} color={colors.text} />
              {notifCount > 0 && (
                <View style={styles.badge}><Text style={styles.badgeTxt}>{notifCount}</Text></View>
              )}
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
              <Avatar name={fullName} size={40} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={{ paddingHorizontal: spacing.lg }}>
          {/* Stats grid */}
          {loading ? (
            <View style={styles.statsGrid}>
              {[...Array(4)].map((_, i) => <Skeleton key={i} width={(width - 56) / 2} height={100} borderRadius={12} style={{ marginBottom: 12 }} />)}
            </View>
          ) : (
            <View style={styles.statsGrid}>
              <StatCard label="Véhicules" value={stats?.totalVehicules || 0}
                color={colors.primary} sublabel={`${stats?.disponibles || 0} disponibles`}
                icon={<CarIcon size={20} color={colors.primary} />} />
              <StatCard label="Réservations" value={stats?.reservationsActives || 0}
                color={colors.success} sublabel="En cours"
                icon={<CalendarIcon size={20} color={colors.success} />} />
              <StatCard label="Clients" value={stats?.totalClients || 0}
                color={colors.purple} sublabel="Total enregistrés"
                icon={<UsersIcon size={20} color={colors.purple} />} />
              <StatCard label="Revenus/mois" value={`${(stats?.revenusMois || 0).toLocaleString()} DA`}
                color={colors.warning} sublabel={`Taux: ${stats?.tauxOccupation || 0}%`}
                icon={<WrenchIcon size={20} color={colors.warning} />} />
            </View>
          )}

          {/* Monthly chart */}
          <SectionHeader title="Revenus mensuels" />
          <Card style={{ marginBottom: 24 }}>
            {loading ? <Skeleton width="100%" height={120} /> : (
              <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 120, gap: 4 }}>
                {mensuel.map((m, i) => (
                  <View key={i} style={{ flex: 1, alignItems: 'center' }}>
                    <View style={{
                      width: '80%', height: Math.max(4, (m.revenus / maxRev) * 90),
                      backgroundColor: i === new Date().getMonth() ? colors.primary : colors.primaryMid,
                      borderRadius: 4,
                    }} />
                    <Text style={{ fontSize: 9, color: colors.textMuted, marginTop: 4 }}>{m.mois}</Text>
                  </View>
                ))}
              </View>
            )}
          </Card>

          {/* Active reservations */}
          <SectionHeader title="Réservations actives"
            action={() => navigation.navigate('Réservations')} actionLabel="Voir tout" />
          {loading ? (
            <>{[...Array(3)].map((_, i) => <SkeletonCard key={i} />)}</>
          ) : reservations.length === 0 ? (
            <Card style={{ alignItems: 'center', padding: 24, marginBottom: 24 }}>
              <Text style={{ color: colors.textMuted }}>Aucune réservation active</Text>
            </Card>
          ) : (
            reservations.map(res => (
              <TouchableOpacity key={res._id}
                onPress={() => navigation.navigate('ReservationDetail', { id: res._id })}
                activeOpacity={0.8}
              >
                <Card style={{ marginBottom: 10 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <View style={{ flex: 1 }}>
                      <Text style={typography.h4}>
                        {res.client?.nom} {res.client?.prenom}
                      </Text>
                      <Text style={typography.bodySmall}>
                        {res.vehicule?.marque} {res.vehicule?.modele} · {res.vehicule?.immatriculation}
                      </Text>
                      <Text style={[typography.caption, { marginTop: 4 }]}>N° {res.numero}</Text>
                    </View>
                    <StatusBadge status={res.statut} config={STATUT_RES} />
                  </View>
                </Card>
              </TouchableOpacity>
            ))
          )}
          <View style={{ height: 24 }} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center',
    padding: spacing.lg, paddingTop: 8, paddingBottom: 16,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
    marginBottom: 16,
  },
  greeting: { fontSize: 13, color: colors.textSub },
  name: { fontSize: 20, fontWeight: '700', color: colors.text },
  notifBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.bgSecondary, alignItems: 'center', justifyContent: 'center' },
  badge: {
    position: 'absolute', top: -2, right: -2,
    width: 18, height: 18, borderRadius: 9,
    backgroundColor: colors.danger, alignItems: 'center', justifyContent: 'center',
  },
  badgeTxt: { color: '#fff', fontSize: 10, fontWeight: '700' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
});

const statStyles = StyleSheet.create({
  card: {
    width: (width - 56) / 2,
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    borderLeftWidth: 4,
    padding: 14,
    ...shadow.sm,
  },
  value: { fontSize: 22, fontWeight: '700', color: colors.text },
  label: { fontSize: 12, color: colors.textSub, marginTop: 2 },
  sub: { fontSize: 11, color: colors.textMuted, marginTop: 2 },
  iconWrap: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
});
