import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography } from '../../services/theme';
import { Card, SkeletonCard, EmptyState } from '../../components/UI';
import { ChevronLeftIcon, BellIcon, CheckCircleIcon, InfoIcon, AlertTriangleIcon, XCircleIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

const TYPE_ICONS = {
  success: { Icon: CheckCircleIcon, color: colors.success },
  info: { Icon: InfoIcon, color: colors.primary },
  warning: { Icon: AlertTriangleIcon, color: colors.warning },
  error: { Icon: XCircleIcon, color: colors.danger },
};

export default function NotificationsScreen({ navigation }) {
  const [notifs, setNotifs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const { show } = useToast();

  const load = useCallback(async () => {
    try {
      const data = await api.get('/notifications');
      setNotifs(Array.isArray(data) ? data : []);
    } catch (e) { console.warn(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const markAllRead = async () => {
    try { await api.put('/notifications/read-all'); show('Toutes marquées comme lues', 'success'); load(); }
    catch (err) { show(err.message, 'error'); }
  };

  const renderItem = ({ item }) => {
    const t = TYPE_ICONS[item.type] || TYPE_ICONS.info;
    return (
      <Card style={[{ marginBottom: 10, flexDirection: 'row', gap: 12 }, !item.lu && { borderLeftWidth: 3, borderLeftColor: t.color }]}>
        <View style={[styles.iconWrap, { backgroundColor: t.color + '18' }]}>
          <t.Icon size={18} color={t.color} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={typography.h4}>{item.titre}</Text>
          <Text style={[typography.bodySmall, { marginTop: 2 }]}>{item.message}</Text>
          <Text style={[typography.caption, { marginTop: 4 }]}>
            {new Date(item.createdAt).toLocaleDateString('fr-DZ')}
          </Text>
        </View>
        {!item.lu && <View style={styles.unreadDot} />}
      </Card>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>Notifications</Text>
        <TouchableOpacity onPress={markAllRead} style={styles.btn}>
          <CheckCircleIcon size={20} color={colors.primary} />
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={{ paddingHorizontal: spacing.lg, marginTop: 12 }}>
          {[...Array(4)].map((_, i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <FlatList
          data={notifs}
          keyExtractor={i => i._id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: spacing.lg }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={
            <EmptyState
              icon={<BellIcon size={36} color={colors.textMuted} />}
              title="Aucune notification"
              subtitle="Vous êtes à jour !"
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  iconWrap: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary, alignSelf: 'center' },
});
