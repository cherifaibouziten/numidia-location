import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Image, RefreshControl, ScrollView
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, shadow, radius, spacing, typography, STATUT_VEH, CAR_PLACEHOLDER } from '../../services/theme';
import { Card, SkeletonCard, StatusBadge, EmptyState, Button } from '../../components/UI';
import { SearchIcon, FilterIcon, PlusIcon, CarIcon } from '../../components/Icons';
import { useAuth } from '../../context/AuthContext';
import api, { BASE_URL } from '../../services/api';

const CATEGORIES = ['Tous', 'Citadine', 'Berline', 'SUV', 'Luxe', 'Utilitaire', '4x4'];

export default function VehiclesScreen({ navigation }) {
  const { isAdmin } = useAuth();
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('Tous');
  const [statutFilter, setStatutFilter] = useState('');

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (category !== 'Tous') params.append('categorie', category);
      if (statutFilter) params.append('statut', statutFilter);
      const data = await api.get(`/vehicules?${params}`);
      setVehicles(data.vehicles || data || []);
    } catch (e) {
      console.warn(e.message);
    } finally {
      setLoading(false);
    }
  }, [search, category, statutFilter]);

  useEffect(() => { load(); }, [load]);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const renderItem = ({ item }) => {
    const photoUri = item.photo ? `${BASE_URL}${item.photo}` : CAR_PLACEHOLDER;
    return (
      <TouchableOpacity onPress={() => navigation.navigate('VehicleDetail', { id: item._id })} activeOpacity={0.85}>
        <Card style={styles.card}>
          <Image source={{ uri: photoUri }} style={styles.photo} resizeMode="cover" />
          <View style={styles.info}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <View style={{ flex: 1 }}>
                <Text style={typography.h4}>{item.marque} {item.modele}</Text>
                <Text style={[typography.bodySmall, { marginTop: 2 }]}>{item.immatriculation}</Text>
              </View>
              <StatusBadge status={item.statut} config={STATUT_VEH} />
            </View>
            <View style={styles.tags}>
              <Tag label={item.categorie} />
              <Tag label={item.carburant} />
              <Tag label={item.transmission} />
              <Text style={styles.price}>{item.prixParJour?.toLocaleString()} DA/j</Text>
            </View>
          </View>
        </Card>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={typography.h3}>Véhicules</Text>
        {isAdmin && (
          <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('VehicleForm', {})}>
            <PlusIcon size={20} color="#fff" />
          </TouchableOpacity>
        )}
      </View>

      {/* Search bar */}
      <View style={styles.searchWrap}>
        <SearchIcon size={18} color={colors.textMuted} style={{ marginRight: 8 }} />
        <TextInput
          value={search} onChangeText={setSearch}
          placeholder="Rechercher marque, modèle, immat..."
          placeholderTextColor={colors.textDisabled}
          style={styles.searchInput}
        />
      </View>

      {/* Category filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterRow} contentContainerStyle={{ paddingHorizontal: spacing.lg }}>
        {CATEGORIES.map(cat => (
          <TouchableOpacity key={cat} onPress={() => setCategory(cat)}
            style={[styles.chip, category === cat && styles.chipActive]}>
            <Text style={[styles.chipText, category === cat && styles.chipTextActive]}>{cat}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* List */}
      {loading ? (
        <View style={{ paddingHorizontal: spacing.lg, marginTop: 8 }}>
          {[...Array(4)].map((_, i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <FlatList
          data={vehicles}
          keyExtractor={i => i._id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: spacing.lg }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={
            <EmptyState
              icon={<CarIcon size={36} color={colors.textMuted} />}
              title="Aucun véhicule trouvé"
              subtitle="Ajoutez votre premier véhicule ou modifiez vos filtres"
              action={isAdmin && <Button title="Ajouter un véhicule" onPress={() => navigation.navigate('VehicleForm', {})} />}
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

function Tag({ label }) {
  return (
    <View style={{ backgroundColor: colors.bgSecondary, borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 3 }}>
      <Text style={{ fontSize: 11, color: colors.textSub, fontWeight: '500' }}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 14,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  addBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
  },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, marginHorizontal: spacing.lg, marginTop: 12,
    paddingHorizontal: 14, height: 44,
  },
  searchInput: { flex: 1, fontSize: 15, color: colors.text },
  filterRow: { marginTop: 12, marginBottom: 4 },
  chip: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: radius.full,
    borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white,
    marginRight: 8,
  },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontSize: 13, color: colors.textSub, fontWeight: '500' },
  chipTextActive: { color: '#fff' },
  card: { flexDirection: 'row', marginBottom: 12, overflow: 'hidden', padding: 0 },
  photo: { width: 100, height: 100, borderTopLeftRadius: radius.lg, borderBottomLeftRadius: radius.lg },
  info: { flex: 1, padding: 12 },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8, alignItems: 'center' },
  price: { fontSize: 13, fontWeight: '700', color: colors.primary, marginLeft: 'auto' },
});
