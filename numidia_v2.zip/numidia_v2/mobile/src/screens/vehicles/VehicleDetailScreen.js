import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography, STATUT_VEH, CAR_PLACEHOLDER } from '../../services/theme';
import { Card, StatusBadge, Button, ConfirmModal, InfoRow, Divider } from '../../components/UI';
import { ChevronLeftIcon, EditIcon, TrashIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import api, { BASE_URL } from '../../services/api';

export default function VehicleDetailScreen({ navigation, route }) {
  const { id } = route.params;
  const { isAdmin } = useAuth();
  const { show } = useToast();
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [delModal, setDelModal] = useState(false);

  useEffect(() => {
    api.get(`/vehicules/${id}`).then(v => { setVehicle(v); setLoading(false); }).catch(() => setLoading(false));
  }, [id]);

  const handleDelete = async () => {
    try {
      await api.delete(`/vehicules/${id}`);
      show('Véhicule supprimé', 'success');
      navigation.goBack();
    } catch (err) {
      show(err.message, 'error');
    }
  };

  if (loading) return <View style={{ flex: 1, backgroundColor: colors.bg }} />;
  if (!vehicle) return <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}><Text>Véhicule introuvable</Text></View>;

  const photoUri = vehicle.photo ? `${BASE_URL}${vehicle.photo}` : CAR_PLACEHOLDER;
  const statut = STATUT_VEH[vehicle.statut];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4} numberOfLines={1}>{vehicle.marque} {vehicle.modele}</Text>
        {isAdmin ? (
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('VehicleForm', { id, data: vehicle })}>
              <EditIcon size={20} color={colors.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.btn} onPress={() => setDelModal(true)}>
              <TrashIcon size={20} color={colors.danger} />
            </TouchableOpacity>
          </View>
        ) : <View style={{ width: 40 }} />}
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <Image source={{ uri: photoUri }} style={styles.photo} resizeMode="cover" />

        <View style={{ padding: spacing.lg }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
            <View>
              <Text style={typography.h2}>{vehicle.marque} {vehicle.modele}</Text>
              <Text style={[typography.bodySmall, { marginTop: 2 }]}>{vehicle.immatriculation} · {vehicle.annee}</Text>
            </View>
            <StatusBadge status={vehicle.statut} config={STATUT_VEH} />
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.price}>{vehicle.prixParJour?.toLocaleString()} DA</Text>
            <Text style={{ color: colors.textSub, fontSize: 14 }}>/jour</Text>
          </View>

          <Card style={{ marginBottom: 16 }}>
            <Text style={[typography.label, { marginBottom: 12 }]}>Caractéristiques</Text>
            <InfoRow label="Catégorie" value={vehicle.categorie} />
            <Divider />
            <InfoRow label="Carburant" value={vehicle.carburant} />
            <Divider />
            <InfoRow label="Transmission" value={vehicle.transmission} />
            <Divider />
            <InfoRow label="Couleur" value={vehicle.couleur} />
            <Divider />
            <InfoRow label="Kilométrage" value={vehicle.kilometrage ? `${vehicle.kilometrage.toLocaleString()} km` : '—'} />
          </Card>

          {(vehicle.numeroSerie || vehicle.assurance) && (
            <Card style={{ marginBottom: 16 }}>
              <Text style={[typography.label, { marginBottom: 12 }]}>Documents & Technique</Text>
              {vehicle.numeroSerie && <><InfoRow label="N° Châssis" value={vehicle.numeroSerie} /><Divider /></>}
              {vehicle.assurance && <InfoRow label="Assurance" value={vehicle.assurance} />}
            </Card>
          )}

          {vehicle.notes ? (
            <Card style={{ marginBottom: 16 }}>
              <Text style={typography.label}>Notes</Text>
              <Text style={[typography.body, { color: colors.textSub, marginTop: 8 }]}>{vehicle.notes}</Text>
            </Card>
          ) : null}

          {isAdmin && (
            <Button title="Créer une réservation" onPress={() => navigation.navigate('ReservationForm', { vehiculeId: id })} style={{ marginBottom: 24 }} />
          )}
        </View>
      </ScrollView>

      <ConfirmModal
        visible={delModal}
        title="Supprimer ce véhicule"
        message={`Êtes-vous sûr de vouloir supprimer ${vehicle.marque} ${vehicle.modele} ? Cette action est irréversible.`}
        confirmText="Supprimer"
        onConfirm={handleDelete}
        onCancel={() => setDelModal(false)}
        danger
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  photo: { width: '100%', height: 240 },
  priceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 4, marginBottom: 20 },
  price: { fontSize: 28, fontWeight: '700', color: colors.primary },
});
