import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Image, Alert, KeyboardAvoidingView, Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { colors, radius, spacing, typography, shadow } from '../../services/theme';
import { Input, Button, SelectField, Card } from '../../components/UI';
import { CameraIcon, XIcon, ChevronLeftIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import api, { BASE_URL } from '../../services/api';

const CATEGORIES = ['Citadine', 'Berline', 'SUV', 'Luxe', 'Utilitaire', '4x4', 'Cabriolet'];
const CARBURANTS = ['Essence', 'Diesel', 'Électrique', 'Hybride', 'GPL'];
const TRANSMISSIONS = ['Manuelle', 'Automatique'];
const STATUTS = ['disponible', 'louée', 'maintenance', 'réservée', 'hors_service'];

export default function VehicleFormScreen({ navigation, route }) {
  const { id, data: initial } = route.params || {};
  const isEdit = !!id;
  const { show } = useToast();
  const [loading, setLoading] = useState(false);
  const [photo, setPhoto] = useState(null); // local URI
  const [existingPhoto, setExistingPhoto] = useState('');
  const [form, setForm] = useState({
    marque: '', modele: '', immatriculation: '', annee: '',
    couleur: '', categorie: 'Berline', carburant: 'Essence',
    transmission: 'Manuelle', kilometrage: '', prixParJour: '',
    statut: 'disponible', numeroSerie: '', assurance: '', notes: '',
  });

  useEffect(() => {
    if (initial) {
      setForm({ ...initial, annee: String(initial.annee || ''), kilometrage: String(initial.kilometrage || ''), prixParJour: String(initial.prixParJour || '') });
      if (initial.photo) setExistingPhoto(`${BASE_URL}${initial.photo}`);
    } else if (id) {
      api.get(`/vehicules/${id}`).then(v => {
        setForm({ ...v, annee: String(v.annee || ''), kilometrage: String(v.kilometrage || ''), prixParJour: String(v.prixParJour || '') });
        if (v.photo) setExistingPhoto(`${BASE_URL}${v.photo}`);
      }).catch(() => {});
    }
  }, [id]);

  const set = (k) => (v) => setForm(p => ({ ...p, [k]: v }));

  const pickImage = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) { show('Permission photos requise', 'warning'); return; }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, aspect: [16, 10], quality: 0.8,
    });
    if (!result.canceled && result.assets?.[0]) {
      setPhoto(result.assets[0]);
    }
  };

  const takePhoto = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) { show('Permission caméra requise', 'warning'); return; }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true, aspect: [16, 10], quality: 0.8,
    });
    if (!result.canceled && result.assets?.[0]) {
      setPhoto(result.assets[0]);
    }
  };

  const validate = () => {
    if (!form.marque.trim()) { show('La marque est requise', 'warning'); return false; }
    if (!form.modele.trim()) { show('Le modèle est requis', 'warning'); return false; }
    if (!form.immatriculation.trim()) { show("L'immatriculation est requise", 'warning'); return false; }
    if (!form.annee || isNaN(parseInt(form.annee))) { show("L'année est requise", 'warning'); return false; }
    if (!form.prixParJour || isNaN(parseFloat(form.prixParJour))) { show('Le prix par jour est requis', 'warning'); return false; }
    return true;
  };

  const submit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => { if (v !== undefined && v !== null) fd.append(k, String(v)); });
      if (photo) {
        fd.append('photo', {
          uri: photo.uri,
          name: `vehicle.${photo.uri.split('.').pop()}`,
          type: `image/${photo.uri.split('.').pop()}`,
        });
      }
      if (isEdit) await api.putForm(`/vehicules/${id}`, fd);
      else await api.postForm('/vehicules', fd);
      show(isEdit ? 'Véhicule modifié' : 'Véhicule créé', 'success');
      navigation.goBack();
    } catch (err) {
      show(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const displayPhoto = photo?.uri || existingPhoto;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>{isEdit ? 'Modifier le véhicule' : 'Nouveau véhicule'}</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: spacing.lg }} keyboardShouldPersistTaps="handled">

          {/* Photo picker */}
          <Card style={{ marginBottom: 20, padding: 0, overflow: 'hidden' }}>
            {displayPhoto ? (
              <View>
                <Image source={{ uri: displayPhoto }} style={styles.photoPreview} resizeMode="cover" />
                <TouchableOpacity style={styles.changePhoto} onPress={pickImage}>
                  <Text style={{ color: '#fff', fontSize: 13, fontWeight: '600' }}>Changer la photo</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.photoPlaceholder}>
                <CameraIcon size={40} color={colors.textMuted} />
                <Text style={[typography.body, { color: colors.textSub, marginTop: 8 }]}>Ajouter une photo</Text>
                <View style={{ flexDirection: 'row', gap: 12, marginTop: 16 }}>
                  <Button title="Galerie" onPress={pickImage} variant="outline" size="sm" style={{ flex: 1 }} />
                  <Button title="Caméra" onPress={takePhoto} variant="outline" size="sm" style={{ flex: 1 }} />
                </View>
              </View>
            )}
          </Card>

          <Text style={[typography.label, { marginBottom: 12 }]}>Informations du véhicule</Text>

          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Input label="Marque" placeholder="Dacia, Toyota..." value={form.marque} onChangeText={set('marque')} required style={{ flex: 1 }} />
            <Input label="Modèle" placeholder="Logan, Corolla..." value={form.modele} onChangeText={set('modele')} required style={{ flex: 1 }} />
          </View>

          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Input label="Immatriculation" placeholder="1234-06-A" value={form.immatriculation} onChangeText={set('immatriculation')} style={{ flex: 1 }} required />
            <Input label="Année" placeholder="2023" value={form.annee} onChangeText={set('annee')} keyboardType="numeric" style={{ flex: 1 }} required />
          </View>

          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Input label="Couleur" placeholder="Blanc, Noir..." value={form.couleur} onChangeText={set('couleur')} style={{ flex: 1 }} />
            <Input label="Kilométrage" placeholder="45000" value={form.kilometrage} onChangeText={set('kilometrage')} keyboardType="numeric" style={{ flex: 1 }} />
          </View>

          <SelectField label="Catégorie" value={form.categorie} onChange={set('categorie')}
            options={CATEGORIES.map(c => ({ label: c, value: c }))} />
          <SelectField label="Carburant" value={form.carburant} onChange={set('carburant')}
            options={CARBURANTS.map(c => ({ label: c, value: c }))} />
          <SelectField label="Transmission" value={form.transmission} onChange={set('transmission')}
            options={TRANSMISSIONS.map(c => ({ label: c, value: c }))} />
          <SelectField label="Statut" value={form.statut} onChange={set('statut')}
            options={STATUTS.map(c => ({ label: c, value: c }))} />

          <Input label="Prix par jour (DA)" placeholder="3500" value={form.prixParJour} onChangeText={set('prixParJour')} keyboardType="numeric" required />

          <Text style={[typography.label, { marginBottom: 12 }]}>Informations techniques</Text>
          <Input label="N° Châssis / Série" placeholder="VIN/numéro de série" value={form.numeroSerie} onChangeText={set('numeroSerie')} />
          <Input label="Assurance" placeholder="Compagnie / N° police" value={form.assurance} onChangeText={set('assurance')} />
          <Input label="Notes" placeholder="Remarques..." value={form.notes} onChangeText={set('notes')} multiline numberOfLines={3} />

          <Button title={isEdit ? 'Enregistrer les modifications' : 'Ajouter le véhicule'} onPress={submit} loading={loading} size="lg" style={{ marginTop: 8, marginBottom: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  photoPreview: { width: '100%', height: 200 },
  changePhoto: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: 'rgba(0,0,0,0.5)', padding: 10, alignItems: 'center',
  },
  photoPlaceholder: {
    height: 180, alignItems: 'center', justifyContent: 'center',
    backgroundColor: colors.bgSecondary,
  },
});
