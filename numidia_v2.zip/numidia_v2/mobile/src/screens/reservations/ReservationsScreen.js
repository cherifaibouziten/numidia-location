import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, RefreshControl, ScrollView
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography, STATUT_RES } from '../../services/theme';
import { Card, SkeletonCard, StatusBadge, EmptyState, Button } from '../../components/UI';
import { SearchIcon, PlusIcon, CalendarIcon } from '../../components/Icons';
import { formatDate } from '../../components/DatePicker';
import api from '../../services/api';

const FILTERS = [
  { label: 'Toutes', value: '' },
  { label: 'Confirmées', value: 'confirmée' },
  { label: 'En cours', value: 'en_cours' },
  { label: 'Terminées', value: 'terminée' },
  { label: 'Annulées', value: 'annulée' },
];

export default function ReservationsScreen({ navigation }) {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('');

  const load = useCallback(async () => {
    try {
      const params = filter ? `?statut=${filter}` : '';
      const data = await api.get(`/reservations${params}`);
      setReservations(Array.isArray(data) ? data : []);
    } catch (e) {
      console.warn(e.message);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const filtered = reservations.filter(r => {
    if (!search) return true;
    const q = search.toLowerCase();
    return r.client?.nom?.toLowerCase().includes(q)
      || r.client?.prenom?.toLowerCase().includes(q)
      || r.vehicule?.immatriculation?.toLowerCase().includes(q)
      || r.numero?.toLowerCase().includes(q);
  });

  const renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => navigation.navigate('ReservationDetail', { id: item._id })} activeOpacity={0.85}>
      <Card style={{ marginBottom: 12 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
          <View style={{ flex: 1 }}>
            <Text style={typography.h4}>{item.client?.nom} {item.client?.prenom}</Text>
            <Text style={[typography.caption, { marginTop: 2 }]}>N° {item.numero}</Text>
          </View>
          <StatusBadge status={item.statut} config={STATUT_RES} />
        </View>
        <View style={styles.row}>
          <Text style={typography.bodySmall}>{item.vehicule?.marque} {item.vehicule?.modele}</Text>
          <Text style={[typography.bodySmall, { color: colors.textMuted }]}>{item.vehicule?.immatriculation}</Text>
        </View>
        <View style={[styles.row, { marginTop: 4 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <CalendarIcon size={14} color={colors.textMuted} />
            <Text style={typography.caption}>
              {formatDate(item.dateDebut)} → {formatDate(item.dateFin)}
            </Text>
          </View>
          <Text style={{ fontSize: 14, fontWeight: '700', color: colors.primary }}>
            {item.prixTotal?.toLocaleString()} DA
          </Text>
        </View>
      </Card>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <Text style={typography.h3}>Réservations</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('ReservationForm', {})}>
          <PlusIcon size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchWrap}>
        <SearchIcon size={18} color={colors.textMuted} style={{ marginRight: 8 }} />
        <TextInput value={search} onChangeText={setSearch}
          placeholder="Rechercher client, N°, immat..."
          placeholderTextColor={colors.textDisabled} style={styles.searchInput} />
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 12, marginBottom: 4, maxHeight: 44 }} contentContainerStyle={{ paddingHorizontal: spacing.lg }}>
        {FILTERS.map(f => (
          <TouchableOpacity key={f.value} onPress={() => setFilter(f.value)}
            style={[styles.chip, filter === f.value && styles.chipActive]}>
            <Text style={[styles.chipText, filter === f.value && styles.chipTextActive]}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {loading ? (
        <View style={{ paddingHorizontal: spacing.lg, marginTop: 8 }}>
          {[...Array(4)].map((_, i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={i => i._id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: spacing.lg }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={
            <EmptyState
              icon={<CalendarIcon size={36} color={colors.textMuted} />}
              title="Aucune réservation"
              subtitle="Créez votre première réservation"
              action={<Button title="Nouvelle réservation" onPress={() => navigation.navigate('ReservationForm', {})} />}
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 14,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  addBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.md,
    marginHorizontal: spacing.lg, marginTop: 12, paddingHorizontal: 14, height: 44,
  },
  searchInput: { flex: 1, fontSize: 15, color: colors.text },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: radius.full, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white, marginRight: 8 },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { fontSize: 13, color: colors.textSub, fontWeight: '500' },
  chipTextActive: { color: '#fff' },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
});
