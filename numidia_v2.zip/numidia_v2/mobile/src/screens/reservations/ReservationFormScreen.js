import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  KeyboardAvoidingView, Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography } from '../../services/theme';
import { Input, Button, SelectField, Card, Divider } from '../../components/UI';
import { DatePicker, formatDate } from '../../components/DatePicker';
import { ChevronLeftIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

const PAIEMENTS = ['Espèces', 'Virement', 'Chèque', 'CCP'];

export default function ReservationFormScreen({ navigation, route }) {
  const { vehiculeId } = route.params || {};
  const { show } = useToast();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [vehicles, setVehicles] = useState([]);
  const [clients, setClients] = useState([]);

  const [form, setForm] = useState({
    client: '', vehicule: vehiculeId || '',
    dateDebut: null, dateFin: null,
    prixParJour: 0, nombreJours: 0, prixTotal: 0,
    caution: '', versement: '', methodePaiement: 'Espèces',
    kmDepart: '', notes: '',
  });

  // Load clients once
  useEffect(() => {
    api.get('/clients').then(c => setClients(c || [])).catch(() => {});
  }, []);

  // Load vehicles available for the chosen interval. Before both dates are
  // picked, show all bookable cars (excluding maintenance / hors_service).
  // A car reserved for another period stays available here — that's the fix.
  useEffect(() => {
    const qs = (form.dateDebut && form.dateFin)
      ? `?dateDebut=${new Date(form.dateDebut).toISOString()}&dateFin=${new Date(form.dateFin).toISOString()}`
      : '';
    api.get(`/vehicules/disponibles${qs}`)
      .then(v => setVehicles(v.vehicles || v || []))
      .catch(() => {});
  }, [form.dateDebut, form.dateFin]);

  const set = (k) => (v) => setForm(p => ({ ...p, [k]: v }));

  // Auto-calculate price
  useEffect(() => {
    if (form.dateDebut && form.dateFin && form.vehicule) {
      const veh = vehicles.find(v => v._id === form.vehicule);
      if (veh) {
        const days = Math.max(1, Math.ceil((new Date(form.dateFin) - new Date(form.dateDebut)) / (1000 * 60 * 60 * 24)));
        const total = days * veh.prixParJour;
        setForm(p => ({ ...p, prixParJour: veh.prixParJour, nombreJours: days, prixTotal: total }));
      }
    }
  }, [form.dateDebut, form.dateFin, form.vehicule, vehicles]);

  const reste = (form.prixTotal || 0) - (parseFloat(form.versement) || 0);

  const validateStep1 = () => {
    if (!form.client) { show('Sélectionnez un client', 'warning'); return false; }
    if (!form.vehicule) { show('Sélectionnez un véhicule', 'warning'); return false; }
    if (!form.dateDebut) { show('Sélectionnez la date de début', 'warning'); return false; }
    if (!form.dateFin) { show('Sélectionnez la date de fin', 'warning'); return false; }
    if (new Date(form.dateFin) <= new Date(form.dateDebut)) { show('La date de fin doit être après le début', 'warning'); return false; }
    return true;
  };

  const submit = async () => {
    setLoading(true);
    try {
      const payload = {
        client: form.client,
        vehicule: form.vehicule,
        dateDebut: form.dateDebut,
        dateFin: form.dateFin,
        prixParJour: form.prixParJour,
        nombreJours: form.nombreJours,
        prixTotal: form.prixTotal,
        caution: parseFloat(form.caution) || 0,
        versement: parseFloat(form.versement) || 0,
        reste: reste,
        methodePaiement: form.methodePaiement,
        kmDepart: parseFloat(form.kmDepart) || 0,
        notes: form.notes,
      };
      const created = await api.post('/reservations', payload);
      show('Réservation créée avec succès', 'success');
      navigation.replace('ReservationDetail', { id: created._id });
    } catch (err) {
      show(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => step === 1 ? navigation.goBack() : setStep(1)} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>Nouvelle réservation</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Step indicator */}
      <View style={styles.steps}>
        <View style={styles.stepRow}>
          <View style={[styles.dot, step >= 1 && styles.dotActive]}><Text style={[styles.dotTxt, step >= 1 && { color: '#fff' }]}>1</Text></View>
          <View style={[styles.line, step >= 2 && { backgroundColor: colors.primary }]} />
          <View style={[styles.dot, step >= 2 && styles.dotActive]}><Text style={[styles.dotTxt, step >= 2 && { color: '#fff' }]}>2</Text></View>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
          <Text style={styles.stepLabel}>Détails</Text>
          <Text style={styles.stepLabel}>Paiement</Text>
        </View>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: spacing.lg }} keyboardShouldPersistTaps="handled">
          {step === 1 ? (
            <>
              <SelectField label="Client" value={form.client} onChange={set('client')}
                options={clients.map(c => ({ label: `${c.nom} ${c.prenom} — ${c.telephone}`, value: c._id }))} />
              <TouchableOpacity onPress={() => navigation.navigate('ClientForm', {})}>
                <Text style={{ color: colors.primary, fontSize: 13, marginBottom: 16, marginTop: -8 }}>+ Nouveau client</Text>
              </TouchableOpacity>

              <SelectField label="Véhicule" value={form.vehicule} onChange={set('vehicule')}
                options={vehicles.map(v => ({ label: `${v.marque} ${v.modele} — ${v.immatriculation} (${v.prixParJour} DA/j)`, value: v._id }))} />

              <DatePicker label="Date de début" value={form.dateDebut} onChange={set('dateDebut')} minDate={new Date()} required />
              <DatePicker label="Date de fin" value={form.dateFin} onChange={set('dateFin')} minDate={form.dateDebut || new Date()} required />

              {form.prixTotal > 0 && (
                <Card style={{ marginBottom: 16, backgroundColor: colors.primaryLight, borderColor: colors.primaryMid }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text style={typography.body}>{form.nombreJours} jour(s) × {form.prixParJour?.toLocaleString()} DA</Text>
                    <Text style={[typography.h4, { color: colors.primary }]}>{form.prixTotal?.toLocaleString()} DA</Text>
                  </View>
                </Card>
              )}

              <Input label="Km de départ" value={form.kmDepart} onChangeText={set('kmDepart')} keyboardType="numeric" placeholder="Kilométrage actuel" />

              <Button title="Continuer" onPress={() => { if (validateStep1()) setStep(2); }} size="lg" style={{ marginTop: 8 }} />
            </>
          ) : (
            <>
              <Card style={{ marginBottom: 16 }}>
                <Text style={[typography.label, { marginBottom: 8 }]}>Récapitulatif</Text>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 }}>
                  <Text style={typography.bodySmall}>Durée</Text>
                  <Text style={typography.body}>{form.nombreJours} jour(s)</Text>
                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 }}>
                  <Text style={typography.bodySmall}>Prix total</Text>
                  <Text style={[typography.h4, { color: colors.primary }]}>{form.prixTotal?.toLocaleString()} DA</Text>
                </View>
              </Card>

              <Input label="Caution (DA)" value={form.caution} onChangeText={set('caution')} keyboardType="numeric" placeholder="Montant de la caution" />
              <Input label="Versement / Acompte (DA)" value={form.versement} onChangeText={set('versement')} keyboardType="numeric" placeholder="Montant versé" hint={`Reste à payer : ${reste.toLocaleString()} DA`} />

              <SelectField label="Méthode de paiement" value={form.methodePaiement} onChange={set('methodePaiement')}
                options={PAIEMENTS.map(p => ({ label: p, value: p }))} />

              <Input label="Notes" value={form.notes} onChangeText={set('notes')} multiline numberOfLines={3} placeholder="Remarques..." />

              <Button title="Créer la réservation" onPress={submit} loading={loading} size="lg" style={{ marginTop: 8, marginBottom: 40 }} />
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  steps: { paddingHorizontal: 60, paddingVertical: 16, backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border },
  stepRow: { flexDirection: 'row', alignItems: 'center' },
  dot: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.bgSecondary, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border },
  dotActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  dotTxt: { fontSize: 13, fontWeight: '700', color: colors.textMuted },
  line: { flex: 1, height: 2, backgroundColor: colors.border, marginHorizontal: 8 },
  stepLabel: { fontSize: 12, color: colors.textSub },
});
