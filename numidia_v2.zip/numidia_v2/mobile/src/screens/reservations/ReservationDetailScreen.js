import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography, STATUT_RES } from '../../services/theme';
import { Card, StatusBadge, Button, ConfirmModal, InfoRow, Divider, SelectField } from '../../components/UI';
import { ChevronLeftIcon, TrashIcon, FileTextIcon } from '../../components/Icons';
import { formatDate } from '../../components/DatePicker';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

const STATUTS = ['confirmée', 'en_cours', 'terminée', 'annulée', 'en_retard'];

export default function ReservationDetailScreen({ navigation, route }) {
  const { id } = route.params;
  const { show } = useToast();
  const [res, setRes] = useState(null);
  const [loading, setLoading] = useState(true);
  const [delModal, setDelModal] = useState(false);

  const load = () => api.get(`/reservations/${id}`).then(r => { setRes(r); setLoading(false); }).catch(() => setLoading(false));
  useEffect(() => { load(); }, [id]);

  const changeStatus = async (statut) => {
    try {
      await api.put(`/reservations/${id}`, { statut });
      show('Statut mis à jour', 'success');
      load();
    } catch (err) { show(err.message, 'error'); }
  };

  const handleDelete = async () => {
    try {
      await api.delete(`/reservations/${id}`);
      show('Réservation supprimée', 'success');
      navigation.goBack();
    } catch (err) { show(err.message, 'error'); }
  };

  if (loading) return <View style={{ flex: 1, backgroundColor: colors.bg }} />;
  if (!res) return <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}><Text>Introuvable</Text></View>;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>{res.numero}</Text>
        <TouchableOpacity style={styles.btn} onPress={() => setDelModal(true)}>
          <TrashIcon size={20} color={colors.danger} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.lg }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <Text style={typography.h2}>{res.prixTotal?.toLocaleString()} DA</Text>
          <StatusBadge status={res.statut} config={STATUT_RES} />
        </View>

        <Card style={{ marginBottom: 16 }}>
          <Text style={[typography.label, { marginBottom: 12 }]}>Client</Text>
          <InfoRow label="Nom" value={`${res.client?.nom || ''} ${res.client?.prenom || ''}`} />
          <Divider />
          <InfoRow label="Téléphone" value={res.client?.telephone} />
          {res.client?.permisNumero && <><Divider /><InfoRow label="N° Permis" value={res.client.permisNumero} /></>}
        </Card>

        <Card style={{ marginBottom: 16 }}>
          <Text style={[typography.label, { marginBottom: 12 }]}>Véhicule</Text>
          <InfoRow label="Modèle" value={`${res.vehicule?.marque || ''} ${res.vehicule?.modele || ''}`} />
          <Divider />
          <InfoRow label="Immatriculation" value={res.vehicule?.immatriculation} />
        </Card>

        <Card style={{ marginBottom: 16 }}>
          <Text style={[typography.label, { marginBottom: 12 }]}>Détails de la location</Text>
          <InfoRow label="Date début" value={formatDate(res.dateDebut)} />
          <Divider />
          <InfoRow label="Date fin" value={formatDate(res.dateFin)} />
          <Divider />
          <InfoRow label="Durée" value={`${res.nombreJours} jour(s)`} />
          <Divider />
          <InfoRow label="Prix/jour" value={`${res.prixParJour?.toLocaleString()} DA`} />
        </Card>

        <Card style={{ marginBottom: 16 }}>
          <Text style={[typography.label, { marginBottom: 12 }]}>Paiement</Text>
          <InfoRow label="Total" value={`${res.prixTotal?.toLocaleString()} DA`} />
          <Divider />
          <InfoRow label="Versement" value={`${(res.versement || 0).toLocaleString()} DA`} />
          <Divider />
          <InfoRow label="Reste" value={`${(res.reste || 0).toLocaleString()} DA`} />
          <Divider />
          <InfoRow label="Caution" value={`${(res.caution || 0).toLocaleString()} DA`} />
          <Divider />
          <InfoRow label="Méthode" value={res.methodePaiement} />
        </Card>

        <SelectField label="Changer le statut" value={res.statut} onChange={changeStatus}
          options={STATUTS.map(s => ({ label: STATUT_RES[s]?.label || s, value: s }))} />

        <Button
          title="Générer le contrat"
          icon={<FileTextIcon size={18} color="#fff" />}
          onPress={() => navigation.navigate('Contract', { reservationId: id })}
          style={{ marginBottom: 40 }}
        />
      </ScrollView>

      <ConfirmModal
        visible={delModal}
        title="Supprimer cette réservation"
        message={`Supprimer la réservation ${res.numero} ? Cette action est irréversible.`}
        confirmText="Supprimer"
        onConfirm={handleDelete}
        onCancel={() => setDelModal(false)}
        danger
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
});
