import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography } from '../../services/theme';
import { Card, SkeletonCard, EmptyState, Button, Avatar, ConfirmModal } from '../../components/UI';
import { ChevronLeftIcon, UsersIcon, CheckCircleIcon, XCircleIcon, ShieldIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const ROLE_LABEL = {
  admin_principal: 'Admin principal',
  admin: 'Administrateur',
  employe: 'Employé',
  client: 'Client',
};
const STATUT_LABEL = {
  actif: 'Actif',
  suspendu: 'Suspendu',
  en_attente_activation: 'En attente',
};
const STATUT_COLOR = {
  actif: colors.success,
  suspendu: colors.danger,
  en_attente_activation: colors.warning,
};

export default function AdminUsersScreen({ navigation }) {
  const { isAdminPrincipal } = useAuth();
  const [tab, setTab] = useState(0); // 0=à activer, 1=demandes admin, 2=tous
  const [pending, setPending] = useState([]);
  const [requests, setRequests] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const { show } = useToast();
  const [confirm, setConfirm] = useState(null); // {title, message, danger, onConfirm}

  const load = useCallback(async () => {
    try {
      const [p, r, u] = await Promise.all([
        api.get('/users/pending'),
        api.get('/users/promotion-requests'),
        api.get('/users'),
      ]);
      setPending(Array.isArray(p) ? p : []);
      setRequests(Array.isArray(r) ? r : []);
      setUsers(Array.isArray(u) ? u : []);
    } catch (e) { console.warn(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const act = async (fn, okMsg) => {
    try { await fn(); show(okMsg, 'success'); load(); }
    catch (err) { show(err.message, 'error'); }
    finally { setConfirm(null); }
  };

  const activate = (u) => act(() => api.put(`/users/${u._id}/activate`), 'Compte activé');
  const suspend = (u) => setConfirm({
    title: 'Suspendre le compte', message: `Suspendre ${u.nom} ${u.prenom} ?`, danger: true,
    onConfirm: () => act(() => api.put(`/users/${u._id}/suspend`), 'Compte suspendu'),
  });
  const reactivate = (u) => act(() => api.put(`/users/${u._id}/reactivate`), 'Compte réactivé');
  const promote = (u) => setConfirm({
    title: 'Promouvoir en admin', message: `Promouvoir ${u.nom} ${u.prenom} au rôle administrateur ?`,
    onConfirm: () => act(() => api.put(`/users/${u._id}/promote`), 'Employé promu administrateur'),
  });
  const rejectPromo = (u) => act(() => api.put(`/users/${u._id}/reject-promotion`), 'Demande rejetée');
  const remove = (u) => setConfirm({
    title: 'Supprimer le compte', message: `Supprimer définitivement ${u.nom} ${u.prenom} ?`, danger: true,
    onConfirm: () => act(() => api.delete(`/users/${u._id}`), 'Utilisateur supprimé'),
  });

  // Pending activation card
  const renderPending = ({ item }) => (
    <Card style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 }}>
        <Avatar name={`${item.nom} ${item.prenom}`} size={44} />
        <View style={{ flex: 1 }}>
          <Text style={typography.h4}>{item.nom} {item.prenom}</Text>
          <Text style={typography.bodySmall}>{item.email}</Text>
          <Text style={typography.caption}>Employé · email {item.isVerified ? 'vérifié' : 'non vérifié'}</Text>
        </View>
      </View>
      <Button title="Activer le compte" onPress={() => activate(item)}
        icon={<CheckCircleIcon size={16} color="#fff" />} size="sm" disabled={!item.isVerified} />
      {!item.isVerified && <Text style={[typography.caption, { marginTop: 6 }]}>En attente de vérification email par l'employé.</Text>}
    </Card>
  );

  // Promotion request card
  const renderRequest = ({ item }) => (
    <Card style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 }}>
        <Avatar name={`${item.nom} ${item.prenom}`} size={44} />
        <View style={{ flex: 1 }}>
          <Text style={typography.h4}>{item.nom} {item.prenom}</Text>
          <Text style={typography.bodySmall}>{item.email}</Text>
        </View>
      </View>
      {isAdminPrincipal ? (
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button title="Promouvoir" onPress={() => promote(item)} icon={<ShieldIcon size={16} color="#fff" />} style={{ flex: 1 }} size="sm" />
          <Button title="Rejeter" onPress={() => rejectPromo(item)} variant="danger" style={{ flex: 1 }} size="sm" />
        </View>
      ) : (
        <Text style={typography.caption}>Seul l'administrateur principal peut promouvoir.</Text>
      )}
    </Card>
  );

  // All users card
  const renderUser = ({ item }) => (
    <Card style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Avatar name={`${item.nom} ${item.prenom}`} size={44} />
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Text style={typography.h4}>{item.nom} {item.prenom}</Text>
            {(item.role === 'admin' || item.role === 'admin_principal') && <ShieldIcon size={14} color={colors.primary} />}
          </View>
          <Text style={typography.bodySmall}>{item.email}</Text>
          <View style={{ flexDirection: 'row', gap: 6, marginTop: 4 }}>
            <View style={[styles.tag, { backgroundColor: colors.primaryLight }]}>
              <Text style={{ fontSize: 10, fontWeight: '700', color: colors.primary }}>{ROLE_LABEL[item.role] || item.role}</Text>
            </View>
            <View style={[styles.tag, { backgroundColor: (STATUT_COLOR[item.statut] || colors.textMuted) + '22' }]}>
              <Text style={{ fontSize: 10, fontWeight: '700', color: STATUT_COLOR[item.statut] || colors.textMuted }}>
                {STATUT_LABEL[item.statut] || item.statut}
              </Text>
            </View>
          </View>
        </View>
      </View>
      {item.role !== 'admin_principal' && (
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
          {item.statut === 'en_attente_activation' && item.isVerified && (
            <Button title="Activer" onPress={() => activate(item)} size="sm" style={{ flex: 1, minWidth: 90 }} />
          )}
          {item.statut === 'actif' && (
            <Button title="Suspendre" onPress={() => suspend(item)} variant="secondary" size="sm" style={{ flex: 1, minWidth: 90 }} />
          )}
          {item.statut === 'suspendu' && (
            <Button title="Réactiver" onPress={() => reactivate(item)} size="sm" style={{ flex: 1, minWidth: 90 }} />
          )}
          {isAdminPrincipal && item.role === 'employe' && (
            <Button title="Promouvoir" onPress={() => promote(item)} variant="outline" size="sm" style={{ flex: 1, minWidth: 90 }} />
          )}
          <Button title="Suppr." onPress={() => remove(item)} variant="danger" size="sm" style={{ flex: 1, minWidth: 70 }} />
        </View>
      )}
    </Card>
  );

  const TABS = [
    { label: `À activer${pending.length ? ` (${pending.length})` : ''}`, data: pending, render: renderPending, empty: 'Aucun employé en attente' },
    { label: `Demandes${requests.length ? ` (${requests.length})` : ''}`, data: requests, render: renderRequest, empty: 'Aucune demande de promotion' },
    { label: `Tous (${users.length})`, data: users, render: renderUser, empty: 'Aucun utilisateur' },
  ];
  const current = TABS[tab];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>Gérer les utilisateurs</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.tabRow}>
        {TABS.map((t, i) => (
          <TouchableOpacity key={i} style={[styles.tab, tab === i && styles.tabActive]} onPress={() => setTab(i)}>
            <Text style={[styles.tabText, tab === i && styles.tabTextActive]} numberOfLines={1}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? (
        <View style={{ paddingHorizontal: spacing.lg, marginTop: 12 }}>
          {[...Array(4)].map((_, i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <FlatList
          data={current.data}
          keyExtractor={i => i._id}
          renderItem={current.render}
          contentContainerStyle={{ padding: spacing.lg }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={
            <EmptyState
              icon={<UsersIcon size={36} color={colors.textMuted} />}
              title={current.empty}
            />
          }
        />
      )}

      <ConfirmModal
        visible={!!confirm}
        title={confirm?.title || ''}
        message={confirm?.message || ''}
        confirmText="Confirmer"
        danger={confirm?.danger}
        onConfirm={confirm?.onConfirm}
        onCancel={() => setConfirm(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  tabRow: { flexDirection: 'row', backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border },
  tab: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  tabActive: { borderBottomWidth: 2, borderBottomColor: colors.primary },
  tabText: { fontSize: 13, color: colors.textSub, fontWeight: '500' },
  tabTextActive: { color: colors.primary, fontWeight: '600' },
  tag: { borderRadius: radius.sm, paddingHorizontal: 6, paddingVertical: 2 },
});
