import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, typography } from '../../services/theme';
import { Input, Button, Avatar } from '../../components/UI';
import { ChevronLeftIcon } from '../../components/Icons';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

export default function ProfileScreen({ navigation }) {
  const { user, refreshUser } = useAuth();
  const { show } = useToast();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    nom: user?.nom || '', prenom: user?.prenom || '', phone: user?.phone || '',
  });
  const set = (k) => (v) => setForm(p => ({ ...p, [k]: v }));
  const fullName = `${form.nom} ${form.prenom}`.trim();

  const validatePhone = (phone) => !phone || /^(\+213|0)(5|6|7)\d{8}$/.test(phone.replace(/\s/g, ''));

  const save = async () => {
    if (!form.nom.trim()) { show('Le nom est requis', 'warning'); return; }
    if (!validatePhone(form.phone)) { show('Téléphone invalide', 'error'); return; }
    setLoading(true);
    try {
      await api.put('/auth/profile', form);
      await refreshUser();
      show('Profil mis à jour', 'success');
      navigation.goBack();
    } catch (err) { show(err.message, 'error'); }
    finally { setLoading(false); }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>Mon profil</Text>
        <View style={{ width: 40 }} />
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: spacing.lg }}>
          <View style={{ alignItems: 'center', marginBottom: 24 }}>
            <Avatar name={fullName} size={88} />
            <Text style={[typography.caption, { marginTop: 12 }]}>{user?.email}</Text>
            <View style={styles.roleBadge}>
              <Text style={{ fontSize: 11, fontWeight: '700', color: user?.role === 'admin' ? colors.primary : colors.textSub }}>
                {user?.role === 'admin' ? 'ADMINISTRATEUR' : 'UTILISATEUR'}
              </Text>
            </View>
          </View>

          <Input label="Nom" value={form.nom} onChangeText={set('nom')} required />
          <Input label="Prénom" value={form.prenom} onChangeText={set('prenom')} />
          <Input label="Téléphone" value={form.phone} onChangeText={set('phone')} keyboardType="phone-pad" placeholder="+213XXXXXXXXX" />
          <Input label="Email" value={user?.email} editable={false} />

          <Button title="Enregistrer" onPress={save} loading={loading} size="lg" style={{ marginTop: 8 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  roleBadge: { backgroundColor: colors.primaryLight, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4, marginTop: 8 },
});
