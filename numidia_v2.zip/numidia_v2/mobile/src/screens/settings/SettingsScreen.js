import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography, shadow } from '../../services/theme';
import { Card, Avatar, ConfirmModal, Button } from '../../components/UI';
import {
  UserIcon, ShieldIcon, BellIcon, WrenchIcon, UsersIcon,
  LogOutIcon, ChevronRightIcon, FileTextIcon, CalendarIcon
} from '../../components/Icons';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

function MenuItem({ icon, label, sublabel, onPress, danger, badge }) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.7} style={styles.menuItem}>
      <View style={[styles.menuIcon, { backgroundColor: danger ? colors.dangerLight : colors.primaryLight }]}>
        {icon}
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[typography.body, { fontWeight: '600', color: danger ? colors.danger : colors.text }]}>{label}</Text>
        {sublabel && <Text style={typography.caption}>{sublabel}</Text>}
      </View>
      {badge && <View style={styles.badge}><Text style={styles.badgeTxt}>{badge}</Text></View>}
      <ChevronRightIcon size={20} color={colors.textMuted} />
    </TouchableOpacity>
  );
}

export default function SettingsScreen({ navigation }) {
  const { user, logout, isAdmin, isEmploye, isClient, refreshUser } = useAuth();
  const { show } = useToast();
  const [logoutModal, setLogoutModal] = useState(false);
  const [adminReqModal, setAdminReqModal] = useState(false);
  const fullName = `${user?.nom || ''} ${user?.prenom || ''}`.trim();

  const requestAdmin = async () => {
    setAdminReqModal(false);
    try {
      await api.post('/auth/request-admin', {});
      await refreshUser();
      show('Demande envoyée aux administrateurs', 'success');
    } catch (err) { show(err.message, 'error'); }
  };

  const reqStatus = user?.promotionStatus;
  const ROLE_LABEL = {
    admin_principal: 'ADMINISTRATEUR PRINCIPAL',
    admin: 'ADMINISTRATEUR',
    employe: 'EMPLOYÉ',
    client: 'CLIENT',
  };
  const roleLabel = ROLE_LABEL[user?.role] || 'UTILISATEUR';

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <Text style={typography.h3}>Paramètres</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.lg }}>
        {/* Profile card */}
        <Card style={{ marginBottom: 20, flexDirection: 'row', alignItems: 'center', gap: 14 }} onPress={() => navigation.navigate('Profile')}>
          <Avatar name={fullName} size={56} />
          <View style={{ flex: 1 }}>
            <Text style={typography.h4}>{fullName || 'Utilisateur'}</Text>
            <Text style={typography.bodySmall}>{user?.email}</Text>
            <View style={[styles.roleBadge, { backgroundColor: isAdmin ? colors.primaryLight : colors.bgSecondary }]}>
              <Text style={{ fontSize: 11, fontWeight: '700', color: isAdmin ? colors.primary : colors.textSub }}>
                {roleLabel}
              </Text>
            </View>
          </View>
          <ChevronRightIcon size={20} color={colors.textMuted} />
        </Card>

        {/* Account section */}
        <Text style={[typography.label, { marginBottom: 10, marginLeft: 4 }]}>Compte</Text>
        <Card style={{ marginBottom: 20, padding: 0 }}>
          <MenuItem icon={<UserIcon size={20} color={colors.primary} />} label="Mon profil"
            sublabel="Modifier vos informations" onPress={() => navigation.navigate('Profile')} />
        </Card>

        {/* Admin section (admins only) */}
        {isAdmin && (
          <>
            <Text style={[typography.label, { marginBottom: 10, marginLeft: 4 }]}>Administration</Text>
            <Card style={{ marginBottom: 20, padding: 0 }}>
              <MenuItem icon={<UsersIcon size={20} color={colors.primary} />} label="Gérer les utilisateurs"
                sublabel="Comptes & demandes admin" onPress={() => navigation.navigate('AdminUsers')} />
              <View style={styles.sep} />
              <MenuItem icon={<WrenchIcon size={20} color={colors.primary} />} label="Maintenance"
                sublabel="Entretien des véhicules" onPress={() => navigation.navigate('Maintenance')} />
              <View style={styles.sep} />
              <MenuItem icon={<BellIcon size={20} color={colors.primary} />} label="Notifications"
                onPress={() => navigation.navigate('Notifications')} />
            </Card>
          </>
        )}

        {/* User: request admin */}
        {/* Employé : demander le rôle admin */}
        {isEmploye && (
          <>
            <Text style={[typography.label, { marginBottom: 10, marginLeft: 4 }]}>Privilèges</Text>
            <Card style={{ marginBottom: 20 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                <View style={[styles.menuIcon, { backgroundColor: colors.primaryLight, marginRight: 0 }]}>
                  <ShieldIcon size={20} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[typography.body, { fontWeight: '600' }]}>Devenir administrateur</Text>
                  <Text style={typography.caption}>
                    {reqStatus === 'pending' ? 'Demande en attente d\'approbation'
                      : reqStatus === 'rejected' ? 'Demande précédente rejetée'
                      : 'Accédez à toutes les fonctionnalités'}
                  </Text>
                </View>
              </View>
              {reqStatus === 'pending' ? (
                <View style={styles.pendingBadge}>
                  <Text style={{ color: colors.warning, fontWeight: '600', fontSize: 13 }}>En attente d'approbation</Text>
                </View>
              ) : (
                <Button title="Demander le rôle admin" onPress={() => setAdminReqModal(true)} variant="outline" />
              )}
            </Card>
          </>
        )}

        {/* Logout */}
        <Card style={{ padding: 0, marginBottom: 24 }}>
          <MenuItem icon={<LogOutIcon size={20} color={colors.danger} />} label="Se déconnecter"
            danger onPress={() => setLogoutModal(true)} />
        </Card>

        <Text style={{ textAlign: 'center', color: colors.textMuted, fontSize: 12 }}>NUMIDIA Cars & Immo v2.0</Text>
      </ScrollView>

      <ConfirmModal
        visible={logoutModal}
        title="Se déconnecter"
        message="Voulez-vous vraiment vous déconnecter ?"
        confirmText="Déconnexion"
        onConfirm={() => { setLogoutModal(false); logout(); }}
        onCancel={() => setLogoutModal(false)}
        danger
      />

      <ConfirmModal
        visible={adminReqModal}
        title="Demande de rôle admin"
        message="Votre demande sera envoyée aux administrateurs pour approbation. Continuer ?"
        confirmText="Envoyer"
        onConfirm={requestAdmin}
        onCancel={() => setAdminReqModal(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: spacing.lg, paddingVertical: 14,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  menuIcon: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  sep: { height: 1, backgroundColor: colors.border, marginLeft: 66 },
  roleBadge: { alignSelf: 'flex-start', borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 3, marginTop: 6 },
  badge: { backgroundColor: colors.danger, borderRadius: 10, minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, marginRight: 8 },
  badgeTxt: { color: '#fff', fontSize: 11, fontWeight: '700' },
  pendingBadge: { backgroundColor: colors.warningLight, borderRadius: radius.md, padding: 12, alignItems: 'center' },
});
