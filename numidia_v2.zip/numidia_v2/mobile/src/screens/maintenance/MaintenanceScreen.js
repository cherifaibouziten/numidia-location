import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography } from '../../services/theme';
import { Card, SkeletonCard, EmptyState, Button, SheetModal, Input, SelectField } from '../../components/UI';
import { DatePicker, formatDate } from '../../components/DatePicker';
import { ChevronLeftIcon, WrenchIcon, PlusIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

const TYPES = ['Vidange', 'Pneus', 'Freins', 'Révision', 'Carrosserie', 'Electricité', 'Autre'];
const STATUTS = ['planifié', 'en_cours', 'terminé'];

export default function MaintenanceScreen({ navigation }) {
  const [items, setItems] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modal, setModal] = useState(false);
  const { show } = useToast();
  const [form, setForm] = useState({ vehicule: '', type: 'Vidange', description: '', cout: '', date: new Date(), kmActuel: '', garage: '', statut: 'planifié' });

  const load = useCallback(async () => {
    try {
      const [m, v] = await Promise.all([api.get('/maintenance'), api.get('/vehicules')]);
      setItems(Array.isArray(m) ? m : []);
      setVehicles(v.vehicles || v || []);
    } catch (e) { console.warn(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const set = (k) => (val) => setForm(p => ({ ...p, [k]: val }));

  const submit = async () => {
    if (!form.vehicule) { show('Sélectionnez un véhicule', 'warning'); return; }
    try {
      await api.post('/maintenance', { ...form, cout: parseFloat(form.cout) || 0, kmActuel: parseFloat(form.kmActuel) || 0 });
      show('Maintenance ajoutée', 'success');
      setModal(false);
      setForm({ vehicule: '', type: 'Vidange', description: '', cout: '', date: new Date(), kmActuel: '', garage: '', statut: 'planifié' });
      load();
    } catch (err) { show(err.message, 'error'); }
  };

  const STATUT_COLORS = { planifié: colors.warning, en_cours: colors.primary, terminé: colors.success };

  const renderItem = ({ item }) => (
    <Card style={{ marginBottom: 10 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <View style={{ flex: 1 }}>
          <Text style={typography.h4}>{item.type}</Text>
          <Text style={typography.bodySmall}>{item.vehicule?.marque} {item.vehicule?.modele} · {item.vehicule?.immatriculation}</Text>
          {item.description ? <Text style={[typography.caption, { marginTop: 4 }]}>{item.description}</Text> : null}
          <Text style={[typography.caption, { marginTop: 4 }]}>{formatDate(item.date)} · {item.cout?.toLocaleString()} DA</Text>
        </View>
        <View style={[styles.badge, { backgroundColor: (STATUT_COLORS[item.statut] || colors.textMuted) + '18' }]}>
          <Text style={{ color: STATUT_COLORS[item.statut] || colors.textMuted, fontSize: 12, fontWeight: '600' }}>{item.statut}</Text>
        </View>
      </View>
    </Card>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>Maintenance</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => setModal(true)}>
          <PlusIcon size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={{ paddingHorizontal: spacing.lg, marginTop: 12 }}>
          {[...Array(4)].map((_, i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={i => i._id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: spacing.lg }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={
            <EmptyState
              icon={<WrenchIcon size={36} color={colors.textMuted} />}
              title="Aucune maintenance"
              subtitle="Planifiez l'entretien de vos véhicules"
              action={<Button title="Ajouter" onPress={() => setModal(true)} />}
            />
          }
        />
      )}

      <SheetModal visible={modal} onClose={() => setModal(false)} title="Nouvelle maintenance">
        <SelectField label="Véhicule" value={form.vehicule} onChange={set('vehicule')}
          options={vehicles.map(v => ({ label: `${v.marque} ${v.modele} — ${v.immatriculation}`, value: v._id }))} />
        <SelectField label="Type" value={form.type} onChange={set('type')}
          options={TYPES.map(t => ({ label: t, value: t }))} />
        <Input label="Description" value={form.description} onChangeText={set('description')} multiline numberOfLines={2} />
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Input label="Coût (DA)" value={form.cout} onChangeText={set('cout')} keyboardType="numeric" style={{ flex: 1 }} />
          <Input label="Km actuel" value={form.kmActuel} onChangeText={set('kmActuel')} keyboardType="numeric" style={{ flex: 1 }} />
        </View>
        <DatePicker label="Date" value={form.date} onChange={set('date')} />
        <Input label="Garage" value={form.garage} onChangeText={set('garage')} />
        <SelectField label="Statut" value={form.statut} onChange={set('statut')}
          options={STATUTS.map(s => ({ label: s, value: s }))} />
        <Button title="Enregistrer" onPress={submit} size="lg" style={{ marginTop: 8 }} />
      </SheetModal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  addBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  badge: { borderRadius: radius.full, paddingHorizontal: 10, paddingVertical: 4 },
});
