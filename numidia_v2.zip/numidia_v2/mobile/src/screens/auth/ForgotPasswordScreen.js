export { ForgotPasswordScreen as default } from './AuthScreens';
