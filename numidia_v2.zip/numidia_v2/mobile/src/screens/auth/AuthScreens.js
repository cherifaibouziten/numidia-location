// ============================================================
// AUTH SCREENS — Welcome, Login, Register, VerifyEmail
// ============================================================
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  KeyboardAvoidingView, Platform, Image, Dimensions
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography, shadow } from '../../services/theme';
import { Button, Input, Card } from '../../components/UI';
import { MailIcon, LockIcon, UserIcon, PhoneIcon, CarIcon } from '../../components/Icons';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

const { width } = Dimensions.get('window');

// ─── Welcome ─────────────────────────────────────────────────────────────────
export function WelcomeScreen({ navigation }) {
  return (
    <View style={[welcomeStyles.container]}>
      <View style={welcomeStyles.hero}>
        <View style={welcomeStyles.logoWrap}>
          <CarIcon size={48} color={colors.primary} />
        </View>
        <Text style={welcomeStyles.brand}>NUMIDIA</Text>
        <Text style={welcomeStyles.sub}>Cars & Immo</Text>
        <Text style={welcomeStyles.tagline}>Gestion professionnelle de votre flotte automobile</Text>
      </View>
      <View style={welcomeStyles.actions}>
        <Button title="Se connecter" onPress={() => navigation.navigate('Login')} variant="primary" size="lg" style={{ marginBottom: 12 }} />
        <Button title="Créer un compte" onPress={() => navigation.navigate('Register')} variant="outline" size="lg" />
      </View>
    </View>
  );
}

const welcomeStyles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.white, padding: spacing.xl, justifyContent: 'space-between' },
  hero: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  logoWrap: {
    width: 100, height: 100, borderRadius: 30,
    backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center',
    marginBottom: 24, ...shadow.md,
  },
  brand: { fontSize: 42, fontWeight: '800', color: colors.text, letterSpacing: -2 },
  sub: { fontSize: 18, color: colors.primary, fontWeight: '600', letterSpacing: 3, marginBottom: 24 },
  tagline: { fontSize: 16, color: colors.textSub, textAlign: 'center', lineHeight: 24, paddingHorizontal: 20 },
  actions: { paddingBottom: spacing.xxl },
});

// ─── Login ────────────────────────────────────────────────────────────────────
export function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const { login } = useAuth();
  const { show } = useToast();

  const validate = () => {
    const e = {};
    if (!email) e.email = 'Email requis';
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = 'Email invalide';
    if (!password) e.password = 'Mot de passe requis';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await login(email.trim(), password);
      show('Connexion réussie', 'success');
    } catch (err) {
      if (err.message?.includes('vérifier')) {
        show(err.message, 'warning', 5000);
        navigation.navigate('VerifyEmail', { email });
      } else {
        show(err.message || 'Erreur de connexion', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={authStyles.scroll} keyboardShouldPersistTaps="handled">
          <TouchableOpacity onPress={() => navigation.goBack()} style={authStyles.back}>
            <Text style={{ color: colors.primary, fontSize: 15 }}>← Retour</Text>
          </TouchableOpacity>
          <Text style={[typography.h2, { marginBottom: 8 }]}>Connexion</Text>
          <Text style={[typography.body, { color: colors.textSub, marginBottom: 32 }]}>
            Bienvenue sur NUMIDIA Cars & Immo
          </Text>

          <Input label="Email" placeholder="votre@email.com" value={email}
            onChangeText={setEmail} keyboardType="email-address" error={errors.email}
            leftIcon={<MailIcon size={18} color={colors.textMuted} />} required />

          <Input label="Mot de passe" placeholder="••••••••" value={password}
            onChangeText={setPassword} secureTextEntry error={errors.password}
            leftIcon={<LockIcon size={18} color={colors.textMuted} />} required />

          <Button title="Se connecter" onPress={handleLogin} loading={loading} size="lg" style={{ marginTop: 8 }} />

          <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')} style={{ alignSelf: 'center', marginTop: 16 }}>
            <Text style={{ color: colors.primary, fontWeight: '600' }}>Mot de passe oublié ?</Text>
          </TouchableOpacity>

          <View style={authStyles.footer}>
            <Text style={{ color: colors.textSub }}>Pas encore de compte ? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
              <Text style={{ color: colors.primary, fontWeight: '600' }}>S'inscrire</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─── Register ─────────────────────────────────────────────────────────────────
export function RegisterScreen({ navigation }) {
  const [form, setForm] = useState({ nom: '', prenom: '', email: '', motDePasse: '', phone: '' });
  const [compte, setCompte] = useState('client'); // 'client' | 'employe'
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const { register } = useAuth();
  const { show } = useToast();

  const set = (k) => (v) => setForm(p => ({ ...p, [k]: v }));

  const validatePhone = (phone) => {
    // Accept: +213XXXXXXXXX or 0XXXXXXXXX (Algerian format)
    const clean = phone.replace(/\s/g, '');
    return /^(\+213|0)(5|6|7)\d{8}$/.test(clean);
  };

  const validate = () => {
    const e = {};
    if (!form.nom.trim()) e.nom = 'Nom requis';
    if (!form.email.trim()) e.email = 'Email requis';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Email invalide';
    if (!form.motDePasse) e.motDePasse = 'Mot de passe requis';
    else if (form.motDePasse.length < 6) e.motDePasse = 'Minimum 6 caractères';
    if (form.phone && !validatePhone(form.phone)) e.phone = 'Format: +213XXXXXXXXX ou 0XXXXXXXXX';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegister = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await register({ ...form, telephone: form.phone, compte });
      show(
        compte === 'employe'
          ? 'Compte employé créé ! Vérifiez votre email, puis attendez l\'activation.'
          : 'Compte créé ! Vérifiez votre email.',
        'success', 5000
      );
      navigation.navigate('VerifyEmail', { email: form.email });
    } catch (err) {
      show(err.message || 'Erreur lors de la création', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={authStyles.scroll} keyboardShouldPersistTaps="handled">
          <TouchableOpacity onPress={() => navigation.goBack()} style={authStyles.back}>
            <Text style={{ color: colors.primary, fontSize: 15 }}>← Retour</Text>
          </TouchableOpacity>
          <Text style={[typography.h2, { marginBottom: 8 }]}>Créer un compte</Text>
          <Text style={[typography.body, { color: colors.textSub, marginBottom: 24 }]}>
            Rejoignez NUMIDIA Cars & Immo
          </Text>

          {/* Type de compte */}
          <Text style={{ fontSize: 13, fontWeight: '600', color: colors.textSub, marginBottom: 8 }}>Type de compte</Text>
          <View style={authStyles.segment}>
            <TouchableOpacity
              style={[authStyles.segmentBtn, compte === 'client' && authStyles.segmentBtnActive]}
              onPress={() => setCompte('client')}>
              <Text style={[authStyles.segmentTxt, compte === 'client' && authStyles.segmentTxtActive]}>Client</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[authStyles.segmentBtn, compte === 'employe' && authStyles.segmentBtnActive]}
              onPress={() => setCompte('employe')}>
              <Text style={[authStyles.segmentTxt, compte === 'employe' && authStyles.segmentTxtActive]}>Employé</Text>
            </TouchableOpacity>
          </View>
          {compte === 'employe' && (
            <Text style={{ fontSize: 12, color: colors.textMuted, marginBottom: 16 }}>
              Un compte employé doit être activé par un administrateur après la vérification de l'email.
            </Text>
          )}

          <Input label="Nom" placeholder="Votre nom" value={form.nom}
            onChangeText={set('nom')} error={errors.nom}
            leftIcon={<UserIcon size={18} color={colors.textMuted} />} required />

          <Input label="Prénom" placeholder="Votre prénom" value={form.prenom}
            onChangeText={set('prenom')}
            leftIcon={<UserIcon size={18} color={colors.textMuted} />} />

          <Input label="Email" placeholder="votre@email.com" value={form.email}
            onChangeText={set('email')} keyboardType="email-address" error={errors.email}
            leftIcon={<MailIcon size={18} color={colors.textMuted} />} required />

          <Input label="Téléphone" placeholder="+213XXXXXXXXX" value={form.phone}
            onChangeText={set('phone')} keyboardType="phone-pad" error={errors.phone}
            hint="Format algérien: +213 ou 0 suivi de 9 chiffres"
            leftIcon={<PhoneIcon size={18} color={colors.textMuted} />} />

          <Input label="Mot de passe" placeholder="Minimum 6 caractères" value={form.motDePasse}
            onChangeText={set('motDePasse')} secureTextEntry error={errors.motDePasse}
            leftIcon={<LockIcon size={18} color={colors.textMuted} />} required />

          <Button title="Créer mon compte" onPress={handleRegister} loading={loading} size="lg" style={{ marginTop: 8 }} />

          <View style={authStyles.footer}>
            <Text style={{ color: colors.textSub }}>Déjà un compte ? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={{ color: colors.primary, fontWeight: '600' }}>Se connecter</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ─── VerifyEmail ──────────────────────────────────────────────────────────────
export function VerifyEmailScreen({ navigation, route }) {
  const email = route.params?.email || '';
  const [loading, setLoading] = useState(false);
  const { show } = useToast();

  const resend = async () => {
    setLoading(true);
    try {
      const data = await api.post('/auth/resend-verification', { email });
      show(data.message || 'Email renvoyé', 'success');
    } catch (err) {
      show(err.message || 'Erreur réseau', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl }}>
        <View style={{ width: 100, height: 100, borderRadius: 50, backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
          <MailIcon size={48} color={colors.primary} />
        </View>
        <Text style={[typography.h2, { textAlign: 'center', marginBottom: 12 }]}>Vérifiez votre email</Text>
        <Text style={[typography.body, { color: colors.textSub, textAlign: 'center', lineHeight: 24 }]}>
          Nous avons envoyé un email de vérification à{'\n'}
          <Text style={{ color: colors.primary, fontWeight: '600' }}>{email}</Text>
        </Text>
        <Text style={[typography.bodySmall, { textAlign: 'center', marginTop: 16, marginBottom: 32 }]}>
          Cliquez sur le lien dans l'email pour activer votre compte. Vérifiez aussi vos spams.
        </Text>
        <Button title="Renvoyer l'email" onPress={resend} loading={loading} variant="outline" style={{ width: '100%', marginBottom: 12 }} />
        <Button title="Retour à la connexion" onPress={() => navigation.navigate('Login')} variant="ghost" style={{ width: '100%' }} />
      </View>
    </SafeAreaView>
  );
}

// ─── ForgotPassword ───────────────────────────────────────────────────────────
export function ForgotPasswordScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const { show } = useToast();

  const submit = async () => {
    if (!/\S+@\S+\.\S+/.test(email)) { show('Email invalide', 'warning'); return; }
    setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email: email.trim() });
      setSent(true);
      show('Email envoyé si le compte existe', 'success');
    } catch (err) {
      show(err.message || 'Erreur', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
      <ScrollView contentContainerStyle={authStyles.scroll} keyboardShouldPersistTaps="handled">
        <TouchableOpacity onPress={() => navigation.goBack()} style={authStyles.back}>
          <Text style={{ color: colors.primary, fontSize: 15 }}>← Retour</Text>
        </TouchableOpacity>
        <Text style={[typography.h2, { marginBottom: 8 }]}>Mot de passe oublié</Text>
        <Text style={[typography.body, { color: colors.textSub, marginBottom: 32 }]}>
          Entrez votre email pour recevoir un lien de réinitialisation.
        </Text>

        {sent ? (
          <View style={{ alignItems: 'center', marginTop: 20 }}>
            <View style={{ width: 80, height: 80, borderRadius: 40, backgroundColor: colors.successLight, alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
              <MailIcon size={36} color={colors.success} />
            </View>
            <Text style={[typography.body, { textAlign: 'center', color: colors.textSub }]}>
              Si un compte existe pour {'\n'}<Text style={{ color: colors.primary, fontWeight: '600' }}>{email}</Text>,{'\n'}un lien de réinitialisation a été envoyé.
            </Text>
            <Button title="Retour à la connexion" onPress={() => navigation.navigate('Login')} variant="outline" style={{ marginTop: 24, width: '100%' }} />
          </View>
        ) : (
          <>
            <Input label="Email" placeholder="votre@email.com" value={email}
              onChangeText={setEmail} keyboardType="email-address"
              leftIcon={<MailIcon size={18} color={colors.textMuted} />} required />
            <Button title="Envoyer le lien" onPress={submit} loading={loading} size="lg" style={{ marginTop: 8 }} />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const authStyles = StyleSheet.create({
  scroll: { flexGrow: 1, padding: spacing.xl, paddingTop: spacing.lg },
  back: { paddingVertical: 12, marginBottom: 24 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 24, paddingBottom: 20 },
  segment: { flexDirection: 'row', backgroundColor: colors.bgSecondary, borderRadius: radius.md, padding: 4, marginBottom: 12 },
  segmentBtn: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: radius.sm },
  segmentBtnActive: { backgroundColor: colors.white, ...shadow.sm },
  segmentTxt: { fontSize: 14, fontWeight: '600', color: colors.textMuted },
  segmentTxtActive: { color: colors.primary },
});
