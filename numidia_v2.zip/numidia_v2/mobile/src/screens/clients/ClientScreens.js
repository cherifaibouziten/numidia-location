// ============================================================
// CLIENTS — List + Form
// ============================================================
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, RefreshControl, ScrollView, KeyboardAvoidingView, Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography } from '../../services/theme';
import { Card, SkeletonCard, EmptyState, Button, Input, Avatar, ConfirmModal, SelectField } from '../../components/UI';
import { DatePicker, formatDate } from '../../components/DatePicker';
import { SearchIcon, PlusIcon, UsersIcon, ChevronLeftIcon, TrashIcon, PhoneIcon, ShieldIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

// ─── Clients List ─────────────────────────────────────────────────────────────
export function ClientsScreen({ navigation }) {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    try {
      const data = await api.get(`/clients${search ? `?search=${search}` : ''}`);
      setClients(Array.isArray(data) ? data : []);
    } catch (e) { console.warn(e.message); }
    finally { setLoading(false); }
  }, [search]);

  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [load]);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => navigation.navigate('ClientForm', { id: item._id, data: item })} activeOpacity={0.85}>
      <Card style={{ marginBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Avatar name={`${item.nom} ${item.prenom}`} size={48} />
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Text style={typography.h4}>{item.nom} {item.prenom}</Text>
            {item.blacklist && (
              <View style={styles.blacklistBadge}>
                <Text style={{ color: colors.danger, fontSize: 10, fontWeight: '700' }}>BLACKLIST</Text>
              </View>
            )}
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 }}>
            <PhoneIcon size={12} color={colors.textMuted} />
            <Text style={typography.bodySmall}>{item.telephone}</Text>
          </View>
        </View>
      </Card>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <Text style={typography.h3}>Clients</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('ClientForm', {})}>
          <PlusIcon size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchWrap}>
        <SearchIcon size={18} color={colors.textMuted} style={{ marginRight: 8 }} />
        <TextInput value={search} onChangeText={setSearch}
          placeholder="Rechercher nom, téléphone, permis..."
          placeholderTextColor={colors.textDisabled} style={styles.searchInput} />
      </View>

      {loading ? (
        <View style={{ paddingHorizontal: spacing.lg, marginTop: 12 }}>
          {[...Array(5)].map((_, i) => <SkeletonCard key={i} />)}
        </View>
      ) : (
        <FlatList
          data={clients}
          keyExtractor={i => i._id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: spacing.lg }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
          ListEmptyComponent={
            <EmptyState
              icon={<UsersIcon size={36} color={colors.textMuted} />}
              title="Aucun client"
              subtitle="Ajoutez votre premier client"
              action={<Button title="Ajouter un client" onPress={() => navigation.navigate('ClientForm', {})} />}
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

// ─── Client Form ──────────────────────────────────────────────────────────────
export function ClientFormScreen({ navigation, route }) {
  const { id, data: initial } = route.params || {};
  const isEdit = !!id;
  const { show } = useToast();
  const [loading, setLoading] = useState(false);
  const [delModal, setDelModal] = useState(false);
  const [form, setForm] = useState({
    nom: '', prenom: '', telephone: '', email: '', adresse: '', wilaya: '',
    dateNaissance: null, lieuNaissance: '', permisNumero: '', permisExpire: null,
    permisDelivreAPC: '', numeroCIN: '', sejour: '', blacklist: false, blacklistRaison: '', notes: '',
  });

  useEffect(() => {
    if (initial) {
      setForm({
        ...initial,
        dateNaissance: initial.dateNaissance || null,
        permisExpire: initial.permisExpire || null,
      });
    }
  }, []);

  const set = (k) => (v) => setForm(p => ({ ...p, [k]: v }));

  const validatePhone = (phone) => {
    const clean = phone.replace(/\s/g, '');
    return /^(\+213|0)(5|6|7)\d{8}$/.test(clean);
  };

  const submit = async () => {
    if (!form.nom.trim()) { show('Le nom est requis', 'warning'); return; }
    if (!form.prenom.trim()) { show('Le prénom est requis', 'warning'); return; }
    if (!form.telephone.trim()) { show('Le téléphone est requis', 'warning'); return; }
    if (!validatePhone(form.telephone)) { show('Téléphone invalide (+213XXXXXXXXX ou 0XXXXXXXXX)', 'error'); return; }

    setLoading(true);
    try {
      if (isEdit) await api.put(`/clients/${id}`, form);
      else await api.post('/clients', form);
      show(isEdit ? 'Client modifié' : 'Client ajouté', 'success');
      navigation.goBack();
    } catch (err) { show(err.message, 'error'); }
    finally { setLoading(false); }
  };

  const handleDelete = async () => {
    try {
      await api.delete(`/clients/${id}`);
      show('Client supprimé', 'success');
      navigation.goBack();
    } catch (err) { show(err.message, 'error'); }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.iconBtn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={typography.h4}>{isEdit ? 'Modifier le client' : 'Nouveau client'}</Text>
        {isEdit ? (
          <TouchableOpacity onPress={() => setDelModal(true)} style={styles.iconBtn}>
            <TrashIcon size={20} color={colors.danger} />
          </TouchableOpacity>
        ) : <View style={{ width: 40 }} />}
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: spacing.lg }} keyboardShouldPersistTaps="handled">
          <Text style={[typography.label, { marginBottom: 12 }]}>Identité</Text>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Input label="Nom" value={form.nom} onChangeText={set('nom')} required style={{ flex: 1 }} />
            <Input label="Prénom" value={form.prenom} onChangeText={set('prenom')} required style={{ flex: 1 }} />
          </View>
          <Input label="Téléphone" value={form.telephone} onChangeText={set('telephone')} keyboardType="phone-pad"
            placeholder="+213XXXXXXXXX" hint="Format algérien requis" required />
          <Input label="Email" value={form.email} onChangeText={set('email')} keyboardType="email-address" />
          <Input label="Adresse" value={form.adresse} onChangeText={set('adresse')} />
          <Input label="Wilaya" value={form.wilaya} onChangeText={set('wilaya')} placeholder="Sétif, Bejaïa..." />
          <DatePicker label="Date de naissance" value={form.dateNaissance} onChange={set('dateNaissance')} />
          <Input label="Lieu de naissance" value={form.lieuNaissance} onChangeText={set('lieuNaissance')} />

          <Text style={[typography.label, { marginBottom: 12, marginTop: 8 }]}>Permis & Documents</Text>
          <Input label="N° Permis" value={form.permisNumero} onChangeText={set('permisNumero')} />
          <DatePicker label="Permis expire le" value={form.permisExpire} onChange={set('permisExpire')} />
          <Input label="Délivré par APC" value={form.permisDelivreAPC} onChangeText={set('permisDelivreAPC')} />
          <Input label="N° CIN" value={form.numeroCIN} onChangeText={set('numeroCIN')} />
          <Input label="Séjour" value={form.sejour} onChangeText={set('sejour')} />

          {/* Blacklist toggle */}
          <TouchableOpacity onPress={() => set('blacklist')(!form.blacklist)}
            style={[styles.blacklistToggle, form.blacklist && { backgroundColor: colors.dangerLight, borderColor: colors.dangerBorder }]}>
            <ShieldIcon size={20} color={form.blacklist ? colors.danger : colors.textMuted} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={{ fontSize: 15, fontWeight: '600', color: form.blacklist ? colors.danger : colors.text }}>Liste noire</Text>
              <Text style={typography.caption}>Bloquer ce client</Text>
            </View>
            <View style={[styles.switch, form.blacklist && { backgroundColor: colors.danger }]}>
              <View style={[styles.switchKnob, form.blacklist && { transform: [{ translateX: 18 }] }]} />
            </View>
          </TouchableOpacity>
          {form.blacklist && (
            <Input label="Raison" value={form.blacklistRaison} onChangeText={set('blacklistRaison')} multiline numberOfLines={2} />
          )}

          <Input label="Notes" value={form.notes} onChangeText={set('notes')} multiline numberOfLines={3} />

          <Button title={isEdit ? 'Enregistrer' : 'Ajouter le client'} onPress={submit} loading={loading} size="lg" style={{ marginTop: 8, marginBottom: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>

      <ConfirmModal
        visible={delModal}
        title="Supprimer ce client"
        message={`Supprimer ${form.nom} ${form.prenom} ? Cette action est irréversible.`}
        confirmText="Supprimer"
        onConfirm={handleDelete}
        onCancel={() => setDelModal(false)}
        danger
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: 14,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  iconBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  addBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.md,
    marginHorizontal: spacing.lg, marginTop: 12, paddingHorizontal: 14, height: 44,
  },
  searchInput: { flex: 1, fontSize: 15, color: colors.text },
  blacklistBadge: { backgroundColor: colors.dangerLight, borderRadius: radius.sm, paddingHorizontal: 6, paddingVertical: 2 },
  blacklistToggle: {
    flexDirection: 'row', alignItems: 'center', padding: 14,
    borderWidth: 1.5, borderColor: colors.border, borderRadius: radius.md,
    backgroundColor: colors.white, marginBottom: 16,
  },
  switch: { width: 44, height: 26, borderRadius: 13, backgroundColor: colors.border, padding: 3, justifyContent: 'center' },
  switchKnob: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#fff' },
});
