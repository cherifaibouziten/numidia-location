/**
 * ContractScreen
 * Loads a reservation's data and populates all variable fields
 * from the Numidia contract template (Arabic/French bilingual).
 * Export: PDF (print-ready) or share as docx data.
 */
import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Share, Alert, Linking
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radius, spacing, typography } from '../../services/theme';
import { Input, Button, Card, Divider, SheetModal } from '../../components/UI';
import { ChevronLeftIcon, DownloadIcon, PrinterIcon, FileTextIcon } from '../../components/Icons';
import { useToast } from '../../context/ToastContext';
import api, { BASE_URL } from '../../services/api';

// All editable fields extracted from the contract template
const DEFAULT_FIELDS = {
  // Header
  contratNumero: '',
  // Driver 1
  d1Nom: '', d1Adresse: '', d1Sejour: '', d1Phone: '',
  d1Naissance: '', d1Permis: '', d1PermisExpire: '', d1APC: '',
  // Driver 2 (optional)
  d2Nom: '', d2Adresse: '', d2Sejour: '', d2Phone: '',
  d2Naissance: '', d2Permis: '', d2PermisExpire: '', d2APC: '',
  // Car
  carMarque: '', carImmat: '', carChassis: '', carCouleur: '',
  carEnergie: '', carAssurance: '', carControleTech: '', carVidange: '',
  // Rental terms
  prixJour: '', nombreJours: '', total: '', versement: '', reste: '',
  kmDepart: '', kmRetour: '',
  dateDepart: '', dateRetour: '',
  remarques: '* 300 Km par jour * 25 Da pour chaque Km',
  // Accessories checklist
  lavageEntretient: false, roueSecours: false, crick: false,
  trianglePanne: false, poste: false, salon: false,
  longeLeveur: false, klaxon: false, carburant: false, barres: false,
};

export default function ContractScreen({ navigation, route }) {
  const { reservationId } = route.params || {};
  const { show } = useToast();
  const [fields, setFields] = useState(DEFAULT_FIELDS);
  const [loading, setLoading] = useState(!!reservationId);
  const [tab, setTab] = useState(0); // 0=Chauffeur1, 1=Chauffeur2, 2=Voiture, 3=Termes

  // Load reservation data to pre-fill form
  useEffect(() => {
    if (!reservationId) return;
    api.get(`/reservations/${reservationId}`).then(res => {
      const c = res.client || {};
      const v = res.vehicule || {};
      setFields(prev => ({
        ...prev,
        contratNumero: res.numero || '',
        d1Nom: `${c.nom || ''} ${c.prenom || ''}`.trim(),
        d1Adresse: c.adresse || '',
        d1Sejour: c.sejour || '',
        d1Phone: c.telephone || '',
        d1Naissance: c.dateNaissance ? new Date(c.dateNaissance).toLocaleDateString('fr-DZ') : '',
        d1Permis: c.permisNumero || '',
        d1PermisExpire: c.permisExpire ? new Date(c.permisExpire).toLocaleDateString('fr-DZ') : '',
        d1APC: c.permisDelivreAPC || '',
        carMarque: `${v.marque || ''} ${v.modele || ''}`.trim(),
        carImmat: v.immatriculation || '',
        carChassis: v.numeroSerie || '',
        carCouleur: v.couleur || '',
        carEnergie: v.carburant || '',
        carAssurance: v.assurance || '',
        prixJour: String(res.prixParJour || ''),
        nombreJours: String(res.nombreJours || ''),
        total: String(res.prixTotal || ''),
        versement: String(res.versement || ''),
        reste: String(res.reste || ''),
        kmDepart: String(res.kmDepart || ''),
        dateDepart: res.dateDebut ? new Date(res.dateDebut).toLocaleDateString('fr-DZ') : '',
        dateRetour: res.dateFin ? new Date(res.dateFin).toLocaleDateString('fr-DZ') : '',
        ...((res.accessoires) || {}),
      }));
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [reservationId]);

  const set = (k) => (v) => setFields(p => ({ ...p, [k]: v }));
  const toggle = (k) => () => setFields(p => ({ ...p, [k]: !p[k] }));
  const [exporting, setExporting] = useState(false);
  const [exportModal, setExportModal] = useState(false);

  // Export via backend (docx or print-ready PDF), preserving template structure
  const exportContract = async (format) => {
    setExporting(true);
    try {
      const { url } = await api.post('/contract/generate', { fields, format });
      const fullUrl = `${BASE_URL}${url}`;
      setExportModal(false);
      // Open the generated file (browser / viewer handles download + print)
      const ok = await Linking.canOpenURL(fullUrl);
      if (ok) {
        await Linking.openURL(fullUrl);
        show(`Contrat ${format.toUpperCase()} généré`, 'success');
      } else {
        await Share.share({ message: fullUrl, title: `Contrat ${fields.contratNumero}` });
      }
    } catch (err) {
      show(err.message || 'Erreur de génération', 'error');
    } finally {
      setExporting(false);
    }
  };

  // Quick text share fallback (no server needed)
  const shareText = () => {
    const text = `CONTRAT DE LOCATION N°: ${fields.contratNumero}
CHAUFFEUR: ${fields.d1Nom} | Tél: ${fields.d1Phone}
VÉHICULE: ${fields.carMarque} (${fields.carImmat})
TARIF: ${fields.total} DA (${fields.nombreJours} jours)
DATES: ${fields.dateDepart} → ${fields.dateRetour}`;
    Share.share({ message: text, title: `Contrat ${fields.contratNumero}` });
  };

  const TABS = ['Chauffeur 1', 'Chauffeur 2', 'Voiture', 'Termes'];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.btn}>
          <ChevronLeftIcon size={24} color={colors.text} />
        </TouchableOpacity>
        <View style={{ flex: 1, marginLeft: 8 }}>
          <Text style={typography.h4}>Contrat de location</Text>
          {fields.contratNumero ? <Text style={typography.caption}>N° {fields.contratNumero}</Text> : null}
        </View>
        <TouchableOpacity style={[styles.btn, { backgroundColor: colors.primaryLight }]} onPress={() => setExportModal(true)}>
          <DownloadIcon size={20} color={colors.primary} />
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabRow} contentContainerStyle={{ paddingHorizontal: spacing.lg }}>
        {TABS.map((t, i) => (
          <TouchableOpacity key={t} onPress={() => setTab(i)} style={[styles.tabBtn, tab === i && styles.tabBtnActive]}>
            <Text style={[styles.tabText, tab === i && styles.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView contentContainerStyle={{ padding: spacing.lg }} keyboardShouldPersistTaps="handled">
        {/* Contract number */}
        <Input label="N° Contrat" value={fields.contratNumero} onChangeText={set('contratNumero')} placeholder="RES-00001" style={{ marginBottom: 8 }} />

        {tab === 0 && (
          <>
            <Text style={[typography.label, { marginBottom: 12 }]}>Premier chauffeur</Text>
            <Input label="Nom et prénom(s)" value={fields.d1Nom} onChangeText={set('d1Nom')} placeholder="Nom Prénom" required />
            <Input label="Adresse" value={fields.d1Adresse} onChangeText={set('d1Adresse')} placeholder="Adresse complète" />
            <Input label="Séjour" value={fields.d1Sejour} onChangeText={set('d1Sejour')} placeholder="Lieu de séjour" />
            <Input label="N° de téléphone" value={fields.d1Phone} onChangeText={set('d1Phone')} keyboardType="phone-pad" placeholder="+213XXXXXXXXX" />
            <Input label="Né(e) le" value={fields.d1Naissance} onChangeText={set('d1Naissance')} placeholder="JJ/MM/AAAA" />
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Input label="N° Permis" value={fields.d1Permis} onChangeText={set('d1Permis')} placeholder="Numéro de permis" style={{ flex: 1 }} />
              <Input label="Expire le" value={fields.d1PermisExpire} onChangeText={set('d1PermisExpire')} placeholder="JJ/MM/AAAA" style={{ flex: 1 }} />
            </View>
            <Input label="Délivré par APC" value={fields.d1APC} onChangeText={set('d1APC')} placeholder="Nom de l'APC" />
          </>
        )}

        {tab === 1 && (
          <>
            <Text style={[typography.label, { marginBottom: 12 }]}>Deuxième chauffeur (optionnel)</Text>
            <Input label="Nom et prénom(s)" value={fields.d2Nom} onChangeText={set('d2Nom')} placeholder="Nom Prénom" />
            <Input label="Adresse" value={fields.d2Adresse} onChangeText={set('d2Adresse')} placeholder="Adresse complète" />
            <Input label="Séjour" value={fields.d2Sejour} onChangeText={set('d2Sejour')} placeholder="Lieu de séjour" />
            <Input label="N° de téléphone" value={fields.d2Phone} onChangeText={set('d2Phone')} keyboardType="phone-pad" />
            <Input label="Né(e) le" value={fields.d2Naissance} onChangeText={set('d2Naissance')} placeholder="JJ/MM/AAAA" />
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Input label="N° Permis" value={fields.d2Permis} onChangeText={set('d2Permis')} style={{ flex: 1 }} />
              <Input label="Expire le" value={fields.d2PermisExpire} onChangeText={set('d2PermisExpire')} placeholder="JJ/MM/AAAA" style={{ flex: 1 }} />
            </View>
            <Input label="Délivré par APC" value={fields.d2APC} onChangeText={set('d2APC')} />
          </>
        )}

        {tab === 2 && (
          <>
            <Text style={[typography.label, { marginBottom: 12 }]}>Informations sur la voiture</Text>
            <Input label="Marque / Modèle" value={fields.carMarque} onChangeText={set('carMarque')} placeholder="Dacia Logan" required />
            <Input label="Immatriculation" value={fields.carImmat} onChangeText={set('carImmat')} placeholder="1234-06-A" required />
            <Input label="N° Châssis" value={fields.carChassis} onChangeText={set('carChassis')} placeholder="Numéro de châssis" />
            <Input label="Couleur" value={fields.carCouleur} onChangeText={set('carCouleur')} />
            <Input label="Énergie" value={fields.carEnergie} onChangeText={set('carEnergie')} placeholder="Essence, Diesel..." />
            <Input label="Assurance" value={fields.carAssurance} onChangeText={set('carAssurance')} />
            <Input label="Contrôle technique" value={fields.carControleTech} onChangeText={set('carControleTech')} placeholder="Date ou N°" />
            <Input label="Vidange (km)" value={fields.carVidange} onChangeText={set('carVidange')} keyboardType="numeric" />
          </>
        )}

        {tab === 3 && (
          <>
            <Text style={[typography.label, { marginBottom: 12 }]}>Tarification</Text>
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Input label="Prix/jour (DA)" value={fields.prixJour} onChangeText={set('prixJour')} keyboardType="numeric" style={{ flex: 1 }} />
              <Input label="Nb. jours" value={fields.nombreJours} onChangeText={set('nombreJours')} keyboardType="numeric" style={{ flex: 1 }} />
            </View>
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Input label="Total (DA)" value={fields.total} onChangeText={set('total')} keyboardType="numeric" style={{ flex: 1 }} />
              <Input label="Versement (DA)" value={fields.versement} onChangeText={set('versement')} keyboardType="numeric" style={{ flex: 1 }} />
            </View>
            <Input label="Reste à payer (DA)" value={fields.reste} onChangeText={set('reste')} keyboardType="numeric" />

            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Input label="Date départ" value={fields.dateDepart} onChangeText={set('dateDepart')} placeholder="JJ/MM/AAAA" style={{ flex: 1 }} />
              <Input label="Date retour" value={fields.dateRetour} onChangeText={set('dateRetour')} placeholder="JJ/MM/AAAA" style={{ flex: 1 }} />
            </View>

            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Input label="Km départ" value={fields.kmDepart} onChangeText={set('kmDepart')} keyboardType="numeric" style={{ flex: 1 }} />
              <Input label="Km retour" value={fields.kmRetour} onChangeText={set('kmRetour')} keyboardType="numeric" style={{ flex: 1 }} />
            </View>

            <Text style={[typography.label, { marginBottom: 12, marginTop: 4 }]}>Accessoires</Text>
            <Card style={{ marginBottom: 16 }}>
              {[
                ['lavageEntretient', 'Lavage / Entretien'],
                ['roueSecours', 'Roue de secours'],
                ['crick', 'Cric'],
                ['trianglePanne', 'Triangle de panne'],
                ['poste', 'Poste radio'],
                ['salon', 'Salon'],
                ['longeLeveur', 'Longe-leveur'],
                ['klaxon', 'Klaxon'],
                ['carburant', 'Carburant plein'],
                ['barres', 'Barres de toit'],
              ].map(([key, label]) => (
                <TouchableOpacity key={key} onPress={toggle(key)}
                  style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.borderLight }}>
                  <View style={[styles.checkbox, fields[key] && { backgroundColor: colors.primary, borderColor: colors.primary }]}>
                    {fields[key] && <Text style={{ color: '#fff', fontSize: 12, fontWeight: '700' }}>✓</Text>}
                  </View>
                  <Text style={[typography.body, { marginLeft: 12 }]}>{label}</Text>
                </TouchableOpacity>
              ))}
            </Card>

            <Input label="Remarques" value={fields.remarques} onChangeText={set('remarques')} multiline numberOfLines={3} />
          </>
        )}

        <Divider style={{ marginVertical: 20 }} />
        <Button
          title="Exporter le contrat"
          onPress={() => setExportModal(true)}
          icon={<DownloadIcon size={18} color="#fff" />}
          size="lg"
          style={{ marginBottom: 40 }}
        />
      </ScrollView>

      {/* Export options modal */}
      <SheetModal visible={exportModal} onClose={() => setExportModal(false)} title="Exporter le contrat" snapHeight="50%">
        <Text style={[typography.body, { color: colors.textSub, marginBottom: 20 }]}>
          Choisissez le format d'export. Le document conserve la mise en forme et les conditions générales du modèle officiel.
        </Text>
        <Button
          title="Télécharger en Word (.docx)"
          onPress={() => exportContract('docx')}
          loading={exporting}
          icon={<FileTextIcon size={18} color="#fff" />}
          size="lg"
          style={{ marginBottom: 12 }}
        />
        <Button
          title="Télécharger en PDF (impression)"
          onPress={() => exportContract('pdf')}
          loading={exporting}
          variant="outline"
          icon={<PrinterIcon size={18} color={colors.primary} />}
          size="lg"
          style={{ marginBottom: 12 }}
        />
        <Button
          title="Partager un résumé texte"
          onPress={shareText}
          variant="ghost"
          size="lg"
        />
      </SheetModal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: 12,
    backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  btn: { width: 40, height: 40, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  tabRow: { backgroundColor: colors.white, borderBottomWidth: 1, borderBottomColor: colors.border, maxHeight: 52 },
  tabBtn: { paddingHorizontal: 16, paddingVertical: 14, marginRight: 4 },
  tabBtnActive: { borderBottomWidth: 2, borderBottomColor: colors.primary },
  tabText: { fontSize: 14, color: colors.textSub, fontWeight: '500' },
  tabTextActive: { color: colors.primary, fontWeight: '600' },
  checkbox: {
    width: 22, height: 22, borderRadius: 6, borderWidth: 1.5,
    borderColor: colors.border, alignItems: 'center', justifyContent: 'center',
  },
});
