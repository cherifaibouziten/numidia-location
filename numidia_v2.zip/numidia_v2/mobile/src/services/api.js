import AsyncStorage from '@react-native-async-storage/async-storage';

// Update this to your local IP when running locally
export const BASE_URL = 'http://192.168.1.100:5000';

const request = async (method, endpoint, body = null, isFormData = false) => {
  const token = await AsyncStorage.getItem('numidia_token');
  const headers = { Authorization: token ? `Bearer ${token}` : '' };
  if (!isFormData) headers['Content-Type'] = 'application/json';

  const config = {
    method: method.toUpperCase(),
    headers,
    ...(body && { body: isFormData ? body : JSON.stringify(body) }),
  };

  const res = await fetch(`${BASE_URL}/api${endpoint}`, config);
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || `Erreur ${res.status}`);
  return data;
};

const api = {
  get: (endpoint) => request('GET', endpoint),
  post: (endpoint, body) => request('POST', endpoint, body),
  put: (endpoint, body) => request('PUT', endpoint, body),
  delete: (endpoint) => request('DELETE', endpoint),
  postForm: (endpoint, formData) => request('POST', endpoint, formData, true),
  putForm: (endpoint, formData) => request('PUT', endpoint, formData, true),
};

export default api;
