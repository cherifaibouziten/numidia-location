// ============================================================
// NUMIDIA v2 — Light Mode Design System
// ============================================================

export const colors = {
  // Primary palette
  primary: '#2563EB',
  primaryLight: '#EFF6FF',
  primaryMid: '#93C5FD',
  primaryDark: '#1D4ED8',

  // Accent
  accent: '#0EA5E9',
  accentLight: '#E0F2FE',

  // Success
  success: '#10B981',
  successLight: '#ECFDF5',
  successBorder: '#6EE7B7',

  // Warning
  warning: '#F59E0B',
  warningLight: '#FFFBEB',
  warningBorder: '#FCD34D',

  // Danger
  danger: '#EF4444',
  dangerLight: '#FEF2F2',
  dangerBorder: '#FCA5A5',

  // Purple
  purple: '#8B5CF6',
  purpleLight: '#F5F3FF',

  // Neutrals
  white: '#FFFFFF',
  bg: '#F8FAFC',
  bgSecondary: '#F1F5F9',
  bgCard: '#FFFFFF',
  border: '#E2E8F0',
  borderLight: '#F1F5F9',

  // Text
  text: '#0F172A',
  textSub: '#475569',
  textMuted: '#94A3B8',
  textDisabled: '#CBD5E1',

  // Tab bar
  tabBar: '#FFFFFF',
  tabActive: '#2563EB',
  tabInactive: '#94A3B8',
};

export const shadow = {
  sm: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 3,
    elevation: 2,
  },
  md: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
  },
  lg: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 8,
  },
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const typography = {
  h1: { fontSize: 28, fontWeight: '700', color: colors.text, letterSpacing: -0.5 },
  h2: { fontSize: 22, fontWeight: '700', color: colors.text, letterSpacing: -0.3 },
  h3: { fontSize: 18, fontWeight: '600', color: colors.text },
  h4: { fontSize: 16, fontWeight: '600', color: colors.text },
  body: { fontSize: 15, fontWeight: '400', color: colors.text, lineHeight: 22 },
  bodySmall: { fontSize: 13, fontWeight: '400', color: colors.textSub, lineHeight: 18 },
  caption: { fontSize: 12, fontWeight: '400', color: colors.textMuted },
  label: { fontSize: 13, fontWeight: '600', color: colors.textSub, textTransform: 'uppercase', letterSpacing: 0.5 },
  button: { fontSize: 15, fontWeight: '600' },
};

// Status configs for vehicles
export const STATUT_VEH = {
  disponible: { label: 'Disponible', color: colors.success, bg: colors.successLight, border: colors.successBorder },
  'louée': { label: 'Louée', color: colors.primary, bg: colors.primaryLight, border: colors.primaryMid },
  maintenance: { label: 'Maintenance', color: colors.warning, bg: colors.warningLight, border: colors.warningBorder },
  réservée: { label: 'Réservée', color: colors.purple, bg: colors.purpleLight, border: '#C4B5FD' },
  hors_service: { label: 'Hors service', color: colors.danger, bg: colors.dangerLight, border: colors.dangerBorder },
};

// Status configs for reservations
export const STATUT_RES = {
  confirmée: { label: 'Confirmée', color: colors.success, bg: colors.successLight, border: colors.successBorder },
  en_cours: { label: 'En cours', color: colors.primary, bg: colors.primaryLight, border: colors.primaryMid },
  terminée: { label: 'Terminée', color: colors.textSub, bg: colors.bgSecondary, border: colors.border },
  annulée: { label: 'Annulée', color: colors.danger, bg: colors.dangerLight, border: colors.dangerBorder },
  en_retard: { label: 'En retard', color: colors.warning, bg: colors.warningLight, border: colors.warningBorder },
};

export const CAR_PLACEHOLDER = 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=400&q=80';
